-- BAI THUC HANH ORACLE BUOI 1

-- XOA BANG (de chay lai khong loi) =====
DROP TABLE s_inventory CASCADE CONSTRAINTS;
DROP TABLE s_item CASCADE CONSTRAINTS;
DROP TABLE s_ord CASCADE CONSTRAINTS;
DROP TABLE s_product CASCADE CONSTRAINTS;
DROP TABLE s_longtext CASCADE CONSTRAINTS;
DROP TABLE s_image CASCADE CONSTRAINTS;
DROP TABLE s_customer CASCADE CONSTRAINTS;
DROP TABLE s_emp CASCADE CONSTRAINTS;
DROP TABLE s_dept CASCADE CONSTRAINTS;
DROP TABLE s_title CASCADE CONSTRAINTS;
DROP TABLE s_warehouse CASCADE CONSTRAINTS;
DROP TABLE s_region CASCADE CONSTRAINTS;

-- TAO BANG
CREATE TABLE s_region (
    id NUMBER PRIMARY KEY,
    name VARCHAR2(50)
);

CREATE TABLE s_warehouse (
    id NUMBER PRIMARY KEY,
    region_id NUMBER,
    address VARCHAR2(100),
    city VARCHAR2(50),
    state VARCHAR2(50),
    country VARCHAR2(50),
    zip_code VARCHAR2(20),
    phone VARCHAR2(20),
    manager_id NUMBER
);

CREATE TABLE s_title (
    title VARCHAR2(50) PRIMARY KEY
);

CREATE TABLE s_dept (
    id NUMBER PRIMARY KEY,
    name VARCHAR2(50),
    region_id NUMBER
);

CREATE TABLE s_emp (
    id NUMBER PRIMARY KEY,
    last_name VARCHAR2(50),
    first_name VARCHAR2(50),
    userid VARCHAR2(20),
    start_date DATE,
    comments VARCHAR2(200),
    manager_id NUMBER,
    title VARCHAR2(50),
    dept_id NUMBER,
    salary NUMBER,
    commission_pct NUMBER
);

CREATE TABLE s_customer (
    id NUMBER PRIMARY KEY,
    name VARCHAR2(100),
    phone VARCHAR2(20),
    address VARCHAR2(100),
    city VARCHAR2(50),
    state VARCHAR2(50),
    country VARCHAR2(50),
    zip_code VARCHAR2(20),
    credit_rating VARCHAR2(20),
    sales_rep_id NUMBER,
    region_id NUMBER,
    comments VARCHAR2(200)
);

CREATE TABLE s_image (
    id NUMBER PRIMARY KEY,
    format VARCHAR2(50),
    use_filename VARCHAR2(50),
    filename VARCHAR2(100),
    image BLOB
);

CREATE TABLE s_longtext (
    id NUMBER PRIMARY KEY,
    use_filename VARCHAR2(50),
    filename VARCHAR2(100),
    text CLOB
);

CREATE TABLE s_product (
    id NUMBER PRIMARY KEY,
    name VARCHAR2(100),
    short_desc VARCHAR2(200),
    longtext_id NUMBER,
    image_id NUMBER,
    suggested_whlsl_price NUMBER,
    whlsl_units NUMBER
);

CREATE TABLE s_ord (
    id NUMBER PRIMARY KEY,
    customer_id NUMBER,
    date_ordered DATE,
    date_shipped DATE,
    sales_rep_id NUMBER,
    total NUMBER,
    payment_type VARCHAR2(50),
    order_filled VARCHAR2(10)
);

CREATE TABLE s_item (
    ord_id NUMBER,
    item_id NUMBER,
    product_id NUMBER,
    price NUMBER,
    quantity NUMBER,
    quantity_shipped NUMBER,
    PRIMARY KEY (ord_id, item_id)
);

CREATE TABLE s_inventory (
    product_id NUMBER,
    warehouse_id NUMBER,
    amount_in_stock NUMBER,
    reorder_point NUMBER,
    max_in_stock NUMBER,
    out_of_stock_explanation VARCHAR2(200),
    restock_date DATE,
    PRIMARY KEY (product_id, warehouse_id)
);

-- INSERT DATA

-- s_region (20 nuoc)
INSERT INTO s_region VALUES (1, 'Vietnam');
INSERT INTO s_region VALUES (2, 'Thailand');
INSERT INTO s_region VALUES (3, 'Singapore');
INSERT INTO s_region VALUES (4, 'Malaysia');
INSERT INTO s_region VALUES (5, 'Indonesia');
INSERT INTO s_region VALUES (6, 'Philippines');
INSERT INTO s_region VALUES (7, 'Laos');
INSERT INTO s_region VALUES (8, 'Cambodia');
INSERT INTO s_region VALUES (9, 'China');
INSERT INTO s_region VALUES (10, 'Japan');
INSERT INTO s_region VALUES (11, 'South Korea');
INSERT INTO s_region VALUES (12, 'India');
INSERT INTO s_region VALUES (13, 'Australia');
INSERT INTO s_region VALUES (14, 'USA');
INSERT INTO s_region VALUES (15, 'Canada');
INSERT INTO s_region VALUES (16, 'UK');
INSERT INTO s_region VALUES (17, 'France');
INSERT INTO s_region VALUES (18, 'Germany');
INSERT INTO s_region VALUES (19, 'Italy');
INSERT INTO s_region VALUES (20, 'Spain');

--s_title
INSERT INTO s_title VALUES ('Manager');
INSERT INTO s_title VALUES ('Staff');
INSERT INTO s_title VALUES ('HR');
INSERT INTO s_title VALUES ('Director');
INSERT INTO s_title VALUES ('Engineer');
INSERT INTO s_title VALUES ('Analyst');
INSERT INTO s_title VALUES ('Consultant');
INSERT INTO s_title VALUES ('Clerk');
INSERT INTO s_title VALUES ('Supervisor');
INSERT INTO s_title VALUES ('Assistant');
INSERT INTO s_title VALUES ('Developer');
INSERT INTO s_title VALUES ('Tester');
INSERT INTO s_title VALUES ('Designer');
INSERT INTO s_title VALUES ('Admin');
INSERT INTO s_title VALUES ('Leader');
INSERT INTO s_title VALUES ('Intern');
INSERT INTO s_title VALUES ('Specialist');
INSERT INTO s_title VALUES ('Coordinator');
INSERT INTO s_title VALUES ('Officer');
INSERT INTO s_title VALUES ('Executive');

--s_warehouse
INSERT INTO s_warehouse VALUES (1,1,'Hanoi','Hanoi','HN','Vietnam','10000','1111',1);
INSERT INTO s_warehouse VALUES (2,2,'HCM','HCM','HCM','Vietnam','70000','2222',2);
INSERT INTO s_warehouse VALUES (3,3,'Bangkok','Bangkok','BK','Thailand','20000','3333',3);
INSERT INTO s_warehouse VALUES (4,4,'KL','KL','MY','Malaysia','30000','4444',4);
INSERT INTO s_warehouse VALUES (5,5,'Jakarta','Jakarta','ID','Indonesia','40000','5555',1);
INSERT INTO s_warehouse VALUES (6,6,'Manila','Manila','PH','Philippines','50000','6666',2);
INSERT INTO s_warehouse VALUES (7,7,'Vientiane','Vientiane','LA','Laos','60000','7777',3);
INSERT INTO s_warehouse VALUES (8,8,'Phnom Penh','PP','CB','Cambodia','61000','8888',4);
INSERT INTO s_warehouse VALUES (9,9,'Beijing','Beijing','CN','China','62000','9999',1);
INSERT INTO s_warehouse VALUES (10,10,'Tokyo','Tokyo','JP','Japan','63000','1010',2);
INSERT INTO s_warehouse VALUES (11,11,'Seoul','Seoul','KR','Korea','64000','1112',3);
INSERT INTO s_warehouse VALUES (12,12,'Delhi','Delhi','IN','India','65000','1313',4);
INSERT INTO s_warehouse VALUES (13,13,'Sydney','Sydney','AU','Australia','66000','1414',1);
INSERT INTO s_warehouse VALUES (14,14,'NY','NY','US','USA','67000','1515',2);
INSERT INTO s_warehouse VALUES (15,15,'Toronto','Toronto','CA','Canada','68000','1616',3);
INSERT INTO s_warehouse VALUES (16,16,'London','London','UK','UK','69000','1717',4);
INSERT INTO s_warehouse VALUES (17,17,'Paris','Paris','FR','France','70000','1818',1);
INSERT INTO s_warehouse VALUES (18,18,'Berlin','Berlin','DE','Germany','71000','1919',2);
INSERT INTO s_warehouse VALUES (19,19,'Rome','Rome','IT','Italy','72000','2020',3);
INSERT INTO s_warehouse VALUES (20,20,'Madrid','Madrid','ES','Spain','73000','2121',4);

COMMIT;

-- s_dept
INSERT INTO s_dept VALUES (10, 'IT', 1);
INSERT INTO s_dept VALUES (20, 'HR', 2);
INSERT INTO s_dept VALUES (30, 'Finance', 3);
INSERT INTO s_dept VALUES (40, 'Marketing', 4);
INSERT INTO s_dept VALUES (50, 'Sales', 5);
INSERT INTO s_dept VALUES (60, 'Logistics', 6);
INSERT INTO s_dept VALUES (70, 'Support', 7);
INSERT INTO s_dept VALUES (80, 'RAndD', 8);
INSERT INTO s_dept VALUES (90, 'QA', 9);
INSERT INTO s_dept VALUES (100, 'Security', 10);
INSERT INTO s_dept VALUES (110, 'Legal', 11);
INSERT INTO s_dept VALUES (120, 'Admin', 12);
INSERT INTO s_dept VALUES (130, 'Training', 13);
INSERT INTO s_dept VALUES (140, 'Planning', 14);
INSERT INTO s_dept VALUES (150, 'Design', 15);
INSERT INTO s_dept VALUES (160, 'Media', 16);
INSERT INTO s_dept VALUES (170, 'Operations', 17);
INSERT INTO s_dept VALUES (180, 'Procurement', 18);
INSERT INTO s_dept VALUES (190, 'Audit', 19);
INSERT INTO s_dept VALUES (200, 'Strategy', 20);

-- s_emp
INSERT INTO s_emp VALUES (1, 'Nguyen', 'An', 'an01',
TO_DATE('01/01/2020','DD/MM/YYYY'), NULL, NULL, 'Manager', 10, 2000, NULL);

INSERT INTO s_emp VALUES (2, 'Tran', 'Binh', 'binh02',
TO_DATE('15/03/2021','DD/MM/YYYY'), NULL, 1, 'Staff', 10, 1500, NULL);

INSERT INTO s_emp VALUES (3, 'Le', 'Cuong', 'cuong03',
TO_DATE('20/05/2022','DD/MM/YYYY'), NULL, 1, 'Staff', 20, 1400, NULL);

INSERT INTO s_emp VALUES (4, 'Pham', 'Dung', 'dung04',
TO_DATE('10/10/2020','DD/MM/YYYY'), NULL, 1, 'HR', 20, 1300, NULL);

INSERT INTO s_emp VALUES (5, 'Hoang', 'Nam', 'nam05',
TO_DATE('12/07/1999','DD/MM/YYYY'), NULL, 1, 'Staff', 30, 1200, NULL);

INSERT INTO s_emp VALUES (6, 'Vo', 'Linh', 'linh06',
TO_DATE('25/11/2000','DD/MM/YYYY'), NULL, 1, 'Staff', 40, 1100, NULL);

INSERT INTO s_emp VALUES (7, 'Do', 'Huy', 'huy07',
TO_DATE('03/03/2005','DD/MM/YYYY'), NULL, 2, 'Staff', 50, 1000, NULL);

INSERT INTO s_emp VALUES (8, 'Bui', 'Minh', 'minh08',
TO_DATE('18/09/1998','DD/MM/YYYY'), NULL, 2, 'Staff', 10, 1300, NULL);

INSERT INTO s_emp VALUES (9, 'Dang', 'Khanh', 'khanh09',
TO_DATE('07/01/2002','DD/MM/YYYY'), NULL, 3, 'Staff', 20, 1400, NULL);

INSERT INTO s_emp VALUES (10, 'Ly', 'Tien', 'tien10',
TO_DATE('22/06/2001','DD/MM/YYYY'), NULL, 3, 'Staff', 30, 1500, NULL);

INSERT INTO s_emp VALUES (11, 'Ngo', 'Thanh', 'thanh11',
TO_DATE('30/12/1997','DD/MM/YYYY'), NULL, 4, 'Staff', 40, 1200, NULL);

INSERT INTO s_emp VALUES (12, 'Truong', 'Hai', 'hai12',
TO_DATE('14/04/2003','DD/MM/YYYY'), NULL, 4, 'Staff', 50, 1100, NULL);

INSERT INTO s_emp VALUES (13, 'Mai', 'Anh', 'anh13',
TO_DATE('09/08/1996','DD/MM/YYYY'), NULL, 1, 'Staff', 10, 1300, NULL);

INSERT INTO s_emp VALUES (14, 'Nguyen', 'Long', 'long14',
TO_DATE('01/01/2004','DD/MM/YYYY'), NULL, 1, 'Staff', 20, 1250, NULL);

INSERT INTO s_emp VALUES (15, 'Tran', 'Bao', 'bao15',
TO_DATE('17/02/2006','DD/MM/YYYY'), NULL, 2, 'Staff', 30, 1350, NULL);

INSERT INTO s_emp VALUES (16, 'Le', 'Phuc', 'phuc16',
TO_DATE('11/11/1995','DD/MM/YYYY'), NULL, 2, 'Staff', 40, 1450, NULL);

INSERT INTO s_emp VALUES (17, 'Pham', 'Son', 'son17',
TO_DATE('05/05/2007','DD/MM/YYYY'), NULL, 3, 'Staff', 50, 1550, NULL);

INSERT INTO s_emp VALUES (18, 'Ho', 'Viet', 'viet18',
TO_DATE('23/03/1994','DD/MM/YYYY'), NULL, 3, 'Staff', 10, 1650, NULL);

INSERT INTO s_emp VALUES (19, 'Vu', 'Dat', 'dat19',
TO_DATE('19/09/2008','DD/MM/YYYY'), NULL, 4, 'Staff', 20, 1750, NULL);

INSERT INTO s_emp VALUES (20, 'Phan', 'Kiet', 'kiet20',
TO_DATE('27/12/1993','DD/MM/YYYY'), NULL, 4, 'Staff', 30, 1850, NULL);


-- s_customer
INSERT INTO s_customer VALUES (1, 'ABC Company', '0123456789', 'Hanoi', 'Hanoi', 'HN', 'Vietnam', '10000', 'A', 1, 1, NULL);
INSERT INTO s_customer VALUES (2, 'XYZ Corp', '0987654321', 'HCM', 'HCM', 'HCM', 'Vietnam', '70000', 'B', 2, 2, NULL);
INSERT INTO s_customer VALUES (3,'Company C','0111','Hanoi','HN','HN','Vietnam','10000','A',1,3,NULL);
INSERT INTO s_customer VALUES (4,'Company D','0222','HCM','HCM','HCM','Vietnam','70000','B',2,4,NULL);
INSERT INTO s_customer VALUES (5,'Company E','0333','Danang','DN','DN','Vietnam','50000','A',1,5,NULL);
INSERT INTO s_customer VALUES (6,'Company F','0444','Hue','HU','HU','Vietnam','54000','C',2,6,NULL);
INSERT INTO s_customer VALUES (7,'Company G','0555','CanTho','CT','CT','Vietnam','90000','A',1,7,NULL);
INSERT INTO s_customer VALUES (8,'Company H','0666','HaiPhong','HP','HP','Vietnam','18000','B',2,8,NULL);
INSERT INTO s_customer VALUES (9,'Company I','0777','QN','QN','QN','Vietnam','20000','A',1,9,NULL);
INSERT INTO s_customer VALUES (10,'Company J','0888','NT','NT','NT','Vietnam','21000','B',2,10,NULL);
INSERT INTO s_customer VALUES (11,'Company K','0999','VT','VT','VT','Vietnam','22000','A',1,11,NULL);
INSERT INTO s_customer VALUES (12,'Company L','0000','LA','LA','LA','Vietnam','23000','C',2,12,NULL);
INSERT INTO s_customer VALUES (13,'Company M','1010','BR','BR','BR','Vietnam','24000','A',1,13,NULL);
INSERT INTO s_customer VALUES (14,'Company N','1111','BD','BD','BD','Vietnam','25000','B',2,14,NULL);
INSERT INTO s_customer VALUES (15,'Company O','1212','DL','DL','DL','Vietnam','26000','A',1,15,NULL);
INSERT INTO s_customer VALUES (16,'Company P','1313','AG','AG','AG','Vietnam','27000','B',2,16,NULL);
INSERT INTO s_customer VALUES (17,'Company Q','1414','ST','ST','ST','Vietnam','28000','A',1,17,NULL);
INSERT INTO s_customer VALUES (18,'Company R','1515','TG','TG','TG','Vietnam','29000','C',2,18,NULL);
INSERT INTO s_customer VALUES (19,'Company S','1616','KG','KG','KG','Vietnam','30000','A',1,19,NULL);
INSERT INTO s_customer VALUES (20,'Company T','1717','BD','BD','BD','Vietnam','31000','B',2,20,NULL);

-- s_product
INSERT INTO s_product VALUES (1, 'Laptop', 'Gaming laptop', NULL, NULL, 1000, 10);
INSERT INTO s_product VALUES (2, 'Phone', 'Smartphone', NULL, NULL, 500, 20);
INSERT INTO s_product VALUES (3, 'Tablet', 'Android tablet', NULL, NULL, 300, 15);
INSERT INTO s_product VALUES (4, 'Mouse', 'Wireless mouse', NULL, NULL, 50, 30);
INSERT INTO s_product VALUES (5, 'Keyboard', 'Mechanical keyboard', NULL, NULL, 120, 25);
INSERT INTO s_product VALUES (6, 'Monitor', '24 inch monitor', NULL, NULL, 250, 12);
INSERT INTO s_product VALUES (7, 'Printer', 'Laser printer', NULL, NULL, 200, 8);
INSERT INTO s_product VALUES (8, 'Scanner', 'Office scanner', NULL, NULL, 150, 10);
INSERT INTO s_product VALUES (9, 'Camera', 'Digital camera', NULL, NULL, 600, 6);
INSERT INTO s_product VALUES (10, 'Speaker', 'Bluetooth speaker', NULL, NULL, 80, 20);
INSERT INTO s_product VALUES (11, 'Headphone', 'Gaming headset', NULL, NULL, 90, 18);
INSERT INTO s_product VALUES (12, 'Microphone', 'USB mic', NULL, NULL, 70, 15);
INSERT INTO s_product VALUES (13, 'Router', 'Wifi router', NULL, NULL, 110, 14);
INSERT INTO s_product VALUES (14, 'USB', 'USB 32GB', NULL, NULL, 20, 50);
INSERT INTO s_product VALUES (15, 'SSD', '512GB SSD', NULL, NULL, 150, 16);
INSERT INTO s_product VALUES (16, 'HDD', '1TB HDD', NULL, NULL, 100, 12);
INSERT INTO s_product VALUES (17, 'GPU', 'Graphics card', NULL, NULL, 700, 5);
INSERT INTO s_product VALUES (18, 'CPU', 'Processor', NULL, NULL, 400, 7);
INSERT INTO s_product VALUES (19, 'RAM', '16GB RAM', NULL, NULL, 120, 20);
INSERT INTO s_product VALUES (20, 'Mainboard', 'Motherboard', NULL, NULL, 200, 9);


-- s_ord
INSERT INTO s_ord VALUES (101, 1, TO_DATE('01/01/2024','DD/MM/YYYY'), TO_DATE('05/01/2024','DD/MM/YYYY'), 1, 2000, 'Cash', 'Y');
INSERT INTO s_ord VALUES (102, 2, TO_DATE('02/02/2024','DD/MM/YYYY'), TO_DATE('06/02/2024','DD/MM/YYYY'), 2, 1500, 'Card', 'Y');
INSERT INTO s_ord VALUES (103, 1, TO_DATE('03/03/2023','DD/MM/YYYY'), TO_DATE('07/03/2023','DD/MM/YYYY'), 1, 1200, 'Cash', 'Y');
INSERT INTO s_ord VALUES (104, 2, TO_DATE('04/04/2022','DD/MM/YYYY'), TO_DATE('08/04/2022','DD/MM/YYYY'), 2, 1800, 'Card', 'Y');
INSERT INTO s_ord VALUES (105, 3, TO_DATE('05/05/2021','DD/MM/YYYY'), TO_DATE('09/05/2021','DD/MM/YYYY'), 3, 900, 'Cash', 'Y');
INSERT INTO s_ord VALUES (106, 4, TO_DATE('06/06/2020','DD/MM/YYYY'), TO_DATE('10/06/2020','DD/MM/YYYY'), 4, 700, 'Card', 'Y');
INSERT INTO s_ord VALUES (107, 5, TO_DATE('07/07/2019','DD/MM/YYYY'), TO_DATE('11/07/2019','DD/MM/YYYY'), 1, 500, 'Cash', 'Y');
INSERT INTO s_ord VALUES (108, 6, TO_DATE('08/08/2018','DD/MM/YYYY'), TO_DATE('12/08/2018','DD/MM/YYYY'), 2, 300, 'Card', 'Y');
INSERT INTO s_ord VALUES (109, 7, TO_DATE('09/09/2017','DD/MM/YYYY'), TO_DATE('13/09/2017','DD/MM/YYYY'), 3, 200, 'Cash', 'Y');
INSERT INTO s_ord VALUES (110, 8, TO_DATE('10/10/2016','DD/MM/YYYY'), TO_DATE('14/10/2016','DD/MM/YYYY'), 4, 1000, 'Card', 'Y');
INSERT INTO s_ord VALUES (111, 9, TO_DATE('11/11/2015','DD/MM/YYYY'), TO_DATE('15/11/2015','DD/MM/YYYY'), 1, 1300, 'Cash', 'Y');
INSERT INTO s_ord VALUES (112, 10, TO_DATE('12/12/2014','DD/MM/YYYY'), TO_DATE('16/12/2014','DD/MM/YYYY'), 2, 1400, 'Card', 'Y');
INSERT INTO s_ord VALUES (113, 11, TO_DATE('01/01/2013','DD/MM/YYYY'), TO_DATE('05/01/2013','DD/MM/YYYY'), 3, 1500, 'Cash', 'Y');
INSERT INTO s_ord VALUES (114, 12, TO_DATE('02/02/2012','DD/MM/YYYY'), TO_DATE('06/02/2012','DD/MM/YYYY'), 4, 1600, 'Card', 'Y');
INSERT INTO s_ord VALUES (115, 13, TO_DATE('03/03/2011','DD/MM/YYYY'), TO_DATE('07/03/2011','DD/MM/YYYY'), 1, 1700, 'Cash', 'Y');
INSERT INTO s_ord VALUES (116, 14, TO_DATE('04/04/2010','DD/MM/YYYY'), TO_DATE('08/04/2010','DD/MM/YYYY'), 2, 1800, 'Card', 'Y');
INSERT INTO s_ord VALUES (117, 15, TO_DATE('05/05/2009','DD/MM/YYYY'), TO_DATE('09/05/2009','DD/MM/YYYY'), 3, 1900, 'Cash', 'Y');
INSERT INTO s_ord VALUES (118, 16, TO_DATE('06/06/2008','DD/MM/YYYY'), TO_DATE('10/06/2008','DD/MM/YYYY'), 4, 2000, 'Card', 'Y');
INSERT INTO s_ord VALUES (119, 17, TO_DATE('07/07/2007','DD/MM/YYYY'), TO_DATE('11/07/2007','DD/MM/YYYY'), 1, 2100, 'Cash', 'Y');
INSERT INTO s_ord VALUES (120, 18, TO_DATE('08/08/2006','DD/MM/YYYY'), TO_DATE('12/08/2006','DD/MM/YYYY'), 2, 2200, 'Card', 'Y');

-- s_item
INSERT INTO s_item VALUES (101, 1, 1, 1000, 2, 2);
INSERT INTO s_item VALUES (102, 1, 2, 500, 3, 3);
INSERT INTO s_item VALUES (103,1,3,300,2,2);
INSERT INTO s_item VALUES (104,1,4,50,5,5);
INSERT INTO s_item VALUES (105,1,5,120,2,2);
INSERT INTO s_item VALUES (106,1,6,250,1,1);
INSERT INTO s_item VALUES (107,1,7,200,1,1);
INSERT INTO s_item VALUES (108,1,8,150,2,2);
INSERT INTO s_item VALUES (109,1,9,600,1,1);
INSERT INTO s_item VALUES (110,1,10,80,3,3);
INSERT INTO s_item VALUES (111,1,11,90,2,2);
INSERT INTO s_item VALUES (112,1,12,70,4,4);
INSERT INTO s_item VALUES (113,1,13,110,2,2);
INSERT INTO s_item VALUES (114,1,14,20,10,10);
INSERT INTO s_item VALUES (115,1,15,150,2,2);
INSERT INTO s_item VALUES (116,1,16,100,3,3);
INSERT INTO s_item VALUES (117,1,17,700,1,1);
INSERT INTO s_item VALUES (118,1,18,400,1,1);
INSERT INTO s_item VALUES (119,1,19,120,3,3);
INSERT INTO s_item VALUES (120,1,20,200,2,2);

-- s_inventory
INSERT INTO s_inventory VALUES (1, 1, 50, 10, 100, NULL, SYSDATE);
INSERT INTO s_inventory VALUES (2, 1, 30, 5, 80, NULL, SYSDATE);
INSERT INTO s_inventory VALUES (3,1,40,10,90,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (4,1,60,15,100,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (5,1,70,20,120,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (6,1,80,25,130,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (7,1,90,30,140,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (8,1,100,35,150,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (9,1,110,40,160,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (10,1,120,45,170,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (11,1,130,50,180,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (12,1,140,55,190,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (13,1,150,60,200,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (14,1,160,65,210,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (15,1,170,70,220,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (16,1,180,75,230,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (17,1,190,80,240,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (18,1,200,85,250,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (19,1,210,90,260,NULL,SYSDATE);
INSERT INTO s_inventory VALUES (20,1,220,95,270,NULL,SYSDATE);

COMMIT;