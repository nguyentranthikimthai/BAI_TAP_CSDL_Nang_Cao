
CREATE TABLE Phong (
    MaPhong VARCHAR2(10) PRIMARY KEY,
    LoaiPhong VARCHAR2(50),
    TrangThai VARCHAR2(20),
    GiaTheoGio NUMBER,
    GiaTheoNgay NUMBER,
    SoNguoiToiDa NUMBER
);
CREATE TABLE KhachHang (
    MaKH VARCHAR2(10) PRIMARY KEY,
    HoTen VARCHAR2(100),
    CCCD VARCHAR2(20),
    SoDT VARCHAR2(15),
    Email VARCHAR2(100),
    QuocTich VARCHAR2(50)
);
CREATE TABLE HoaDon (
    MaHD VARCHAR2(10) PRIMARY KEY,
    MaKH VARCHAR2(10),
    MaPhong VARCHAR2(10),
    NgayNhan DATE,
    NgayTra DATE,
    SoNguoi NUMBER,
    TongTien NUMBER,
    TrangThai VARCHAR2(20),
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
    FOREIGN KEY (MaPhong) REFERENCES Phong(MaPhong)
);
CREATE TABLE ChiPhiPhuThu (
    MaCP VARCHAR2(10) PRIMARY KEY,
    MaHD VARCHAR2(10),
    MoTa VARCHAR2(200),
    SoTien NUMBER,
    ThoiGian DATE,
    FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD)
);
CREATE TABLE LichSuPhong (
    MaLS VARCHAR2(10) PRIMARY KEY,
    MaPhong VARCHAR2(10),
    MaHD VARCHAR2(10),
    NgayNhan DATE,
    NgayTra DATE,
    GhiChu VARCHAR2(200),
    FOREIGN KEY (MaPhong) REFERENCES Phong(MaPhong),
    FOREIGN KEY (MaHD) REFERENCES HoaDon(MaHD)
);

--a. Trigger INSERT bảng HoaDon — trg_DatPhong
CREATE OR REPLACE TRIGGER trg_DatPhong
BEFORE INSERT ON HoaDon
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
    v_trangthai VARCHAR2(20);
    v_succhua NUMBER;
    v_gia NUMBER;
BEGIN
    -- 1. Kiểm tra MaKH tồn tại
    SELECT COUNT(*) INTO v_dem
    FROM KhachHang
    WHERE MaKH = :NEW.MaKH;

    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'MaKH khong ton tai');
    END IF;

    -- 2. Kiểm tra MaPhong + lấy thông tin
    SELECT TrangThai, SoNguoiToiDa, GiaTheoNgay
    INTO v_trangthai, v_succhua, v_gia
    FROM Phong
    WHERE MaPhong = :NEW.MaPhong;

    -- 3. Kiểm tra trạng thái phòng
    IF v_trangthai != 'TRONG' THEN
        RAISE_APPLICATION_ERROR(-20002, 'Phong khong trong');
    END IF;

    -- 4. Kiểm tra số người
    IF :NEW.SoNguoi > v_succhua THEN
        RAISE_APPLICATION_ERROR(-20003, 'Vuot qua suc chua');
    END IF;

    -- 5. Kiểm tra ngày
    IF :NEW.NgayNhan >= :NEW.NgayTra 
       OR :NEW.NgayNhan < TRUNC(SYSDATE) THEN
        RAISE_APPLICATION_ERROR(-20004, 'Ngay khong hop le');
    END IF;

    -- 6. Tính tiền
    :NEW.TongTien := (:NEW.NgayTra - :NEW.NgayNhan) * v_gia;

    -- 7. Cập nhật phòng
    UPDATE Phong
    SET TrangThai = 'DA_THUE'
    WHERE MaPhong = :NEW.MaPhong;

END;
/
--b. Trigger UPDATE TrangThai HoaDon — trg_CapNhatTrangThaiHD
CREATE OR REPLACE TRIGGER trg_CapNhatTrangThaiHD
BEFORE UPDATE OF TrangThai ON HoaDon
FOR EACH ROW
BEGIN
    -- 1. State machine
    IF :OLD.TrangThai = 'CHO_NHAN' AND 
       :NEW.TrangThai NOT IN ('DANG_O', 'HUY') THEN
        RAISE_APPLICATION_ERROR(-20001, 'Sai chuyen trang thai');
    END IF;

    IF :OLD.TrangThai = 'DANG_O' AND 
       :NEW.TrangThai != 'DA_TRA' THEN
        RAISE_APPLICATION_ERROR(-20002, 'Sai chuyen trang thai');
    END IF;

    IF :OLD.TrangThai IN ('DA_TRA', 'HUY') THEN
        RAISE_APPLICATION_ERROR(-20003, 'Khong duoc thay doi');
    END IF;

    -- 2. Khi trả phòng
    IF :NEW.TrangThai = 'DA_TRA' THEN

        UPDATE Phong
        SET TrangThai = 'TRONG'
        WHERE MaPhong = :OLD.MaPhong;

        -- Ghi lịch sử
        INSERT INTO LichSuPhong
        VALUES (
            'LS' || TO_CHAR(SYSDATE,'HH24MISS'),
            :OLD.MaPhong,
            :OLD.MaHD,
            :OLD.NgayNhan,
            :OLD.NgayTra,
            'Tra phong'
        );

    END IF;

    -- 3. Khi hủy
    IF :NEW.TrangThai = 'HUY' THEN
        UPDATE Phong
        SET TrangThai = 'TRONG'
        WHERE MaPhong = :OLD.MaPhong;
    END IF;

END;
/
--c. Compound Trigger UPDATE ChiPhiPhuThu — trg_SuaChiPhi
CREATE OR REPLACE TRIGGER trg_SuaChiPhi
FOR INSERT OR UPDATE ON ChiPhiPhuThu
COMPOUND TRIGGER

    BEFORE STATEMENT IS
    BEGIN
        pkg_state.g_row_count := 0;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
    BEGIN
        pkg_state.g_row_count := pkg_state.g_row_count + 1;

        -- Giới hạn 5 dòng
        IF pkg_state.g_row_count > 5 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Toi da 5 chi phi');
        END IF;

        -- Kiểm tra tiền
        IF :NEW.SoTien <= 0 OR :NEW.SoTien > 50000000 THEN
            RAISE_APPLICATION_ERROR(-20002, 'So tien khong hop le');
        END IF;

    END BEFORE EACH ROW;

    AFTER STATEMENT IS
    BEGIN
        -- Cập nhật lại tổng tiền
        UPDATE HoaDon hd
        SET TongTien = TongTien + (
            SELECT NVL(SUM(SoTien),0)
            FROM ChiPhiPhuThu cp
            WHERE cp.MaHD = hd.MaHD
        );
    END AFTER STATEMENT;

END trg_SuaChiPhi;
/
--d. INSTEAD OF Trigger trên View — trg_vwPhongTrong_ins
CREATE SEQUENCE SEQ_HD START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE VIEW vw_PhongTrong AS
SELECT 
    MaPhong, 
    LoaiPhong, 
    GiaTheoNgay, 
    SoNguoiToiDa,
    NULL AS MaKH,
    NULL AS NgayNhan,
    NULL AS NgayTra,
    NULL AS SoNguoi
FROM Phong
WHERE TrangThai = 'TRONG';

CREATE OR REPLACE TRIGGER trg_vwPhongTrong_ins
INSTEAD OF INSERT ON vw_PhongTrong
FOR EACH ROW
DECLARE
    v_mahd VARCHAR2(20);
BEGIN
    -- Tạo mã hóa đơn
    v_mahd := 'HD' || TO_CHAR(SEQ_HD.NEXTVAL, 'FM0000');

    -- Insert vào HoaDon
    INSERT INTO HoaDon(
        MaHD, MaKH, MaPhong, NgayNhan, NgayTra, SoNguoi, TrangThai
    )
    VALUES (
        v_mahd,
        :NEW.MaKH,
        :NEW.MaPhong,
        :NEW.NgayNhan,
        :NEW.NgayTra,
        :NEW.SoNguoi,
        'CHO_NHAN'
    );

END;
/

