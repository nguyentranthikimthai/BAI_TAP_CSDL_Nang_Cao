CREATE TABLE HangSX (
    MaHangSX VARCHAR2(10) PRIMARY KEY,
    TenHang VARCHAR2(100),
    DiaChi VARCHAR2(200),
    SoDT VARCHAR2(15),
    Email VARCHAR2(100)
);
CREATE TABLE SanPham (
    MaSP VARCHAR2(10) PRIMARY KEY,
    MaHangSX VARCHAR2(10),
    TenSP VARCHAR2(100),
    SoLuong NUMBER,
    MauSac VARCHAR2(50),
    GiaBan NUMBER,
    DonViTinh VARCHAR2(50),
    MoTa VARCHAR2(200),
    FOREIGN KEY (MaHangSX) REFERENCES HangSX(MaHangSX)
);
CREATE TABLE NhanVien (
    MaNV VARCHAR2(10) PRIMARY KEY,
    TenNV VARCHAR2(100),
    GioiTinh VARCHAR2(10),
    DiaChi VARCHAR2(200),
    SoDT VARCHAR2(15),
    Email VARCHAR2(100),
    TenPhong VARCHAR2(50)
);
CREATE TABLE PNhap (
    SoHDN VARCHAR2(10) PRIMARY KEY,
    NgayNhap DATE,
    MaNV VARCHAR2(10),
    FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);
CREATE TABLE Nhap (
    SoHDN VARCHAR2(10),
    MaSP VARCHAR2(10),
    SoLuongN NUMBER,
    DonGiaN NUMBER,
    PRIMARY KEY (SoHDN, MaSP),
    FOREIGN KEY (SoHDN) REFERENCES PNhap(SoHDN),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);
CREATE TABLE PXuat (
    SoHDX VARCHAR2(10) PRIMARY KEY,
    NgayXuat DATE,
    MaNV VARCHAR2(10),
    FOREIGN KEY (MaNV) REFERENCES NhanVien(MaNV)
);
CREATE TABLE Xuat (
    SoHDX VARCHAR2(10),
    MaSP VARCHAR2(10),
    SoLuongX NUMBER,
    PRIMARY KEY (SoHDX, MaSP),
    FOREIGN KEY (SoHDX) REFERENCES PXuat(SoHDX),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);

--1a. Trigger INSERT bảng NHAP – trg_Nhap
CREATE OR REPLACE TRIGGER trg_Nhap
BEFORE INSERT ON Nhap
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;

    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'MaSP khong ton tai');
    END IF;

    IF :NEW.SoLuongN <= 0 OR :NEW.DonGiaN <= 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'SoLuongN va DonGiaN phai > 0');
    END IF;

    UPDATE SanPham
    SET SoLuong = SoLuong + :NEW.SoLuongN
    WHERE MaSP = :NEW.MaSP;
END;
/
-- Thực thi trigger (test):
INSERT INTO HangSX VALUES ('H1','Sony','HN','0123','a@gmail.com');
INSERT INTO SanPham VALUES ('SP1','H1','Tivi',10,'Den',1000,'Cai','Mo ta');
INSERT INTO NhanVien VALUES ('NV1','A','Nam','HN','0123','a@gmail.com','P1');
INSERT INTO PNhap VALUES ('HDN1',SYSDATE,'NV1');

INSERT INTO Nhap VALUES ('HDN1','SP1',5,100);
INSERT INTO Nhap VALUES ('HDN1','SP1',-5,100);
--1b. Trigger INSERT bảng XUAT – trg_xuat
CREATE OR REPLACE TRIGGER trg_Xuat
BEFORE INSERT ON Xuat
FOR EACH ROW
DECLARE
    v_dem NUMBER := 0;
    v_soluong NUMBER := 0;
BEGIN
    SELECT COUNT(*) INTO v_dem
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;

    IF v_dem = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'MaSP khong ton tai');
    END IF;

    -- BỔ SUNG
    IF :NEW.SoLuongX <= 0 THEN
        RAISE_APPLICATION_ERROR(-20003, 'SoLuongX phai > 0');
    END IF;

    SELECT SoLuong INTO v_soluong
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;

    IF :NEW.SoLuongX > v_soluong THEN
        RAISE_APPLICATION_ERROR(-20002, 'Khong du hang de xuat');
    END IF;

    UPDATE SanPham
    SET SoLuong = SoLuong - :NEW.SoLuongX
    WHERE MaSP = :NEW.MaSP;
END;
/
-- Thực thi trigger (test):
INSERT INTO PXuat VALUES ('HDX1',SYSDATE,'NV1');

INSERT INTO Xuat VALUES ('HDX1','SP1',5);
INSERT INTO Xuat VALUES ('HDX1','SP1',999);
INSERT INTO Xuat VALUES ('HDX1','SP1',-2);

--1c. Trigger DELETE bảng XUAT – trg_XoaXuat
CREATE OR REPLACE TRIGGER trg_XoaXuat
AFTER DELETE ON Xuat
FOR EACH ROW
BEGIN
    UPDATE SanPham
    SET SoLuong = SoLuong + :OLD.SoLuongX
    WHERE MaSP = :OLD.MaSP;
END;
/
-- Thực thi trigger (test):
DELETE FROM Xuat WHERE SoHDX='HDX1' AND MaSP='SP1';
--Phiếu 2
-- Tạo PACKAGE
CREATE OR REPLACE PACKAGE pkg_state AS
    g_row_count NUMBER := 0;
END pkg_state;
/
--2a. Trigger UPDATE bảng XUAT – trg_CapNhatXuat
CREATE OR REPLACE TRIGGER trg_CapNhatXuat
FOR UPDATE ON Xuat
COMPOUND TRIGGER

    v_soluong NUMBER;
    v_chenhlech NUMBER;

    BEFORE STATEMENT IS
    BEGIN
        pkg_state.g_row_count := 0;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
    BEGIN
        pkg_state.g_row_count := pkg_state.g_row_count + 1;

        IF pkg_state.g_row_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Chi duoc cap nhat 1 dong');
        END IF;

        v_chenhlech := :NEW.SoLuongX - :OLD.SoLuongX;

        SELECT SoLuong INTO v_soluong
        FROM SanPham
        WHERE MaSP = :NEW.MaSP;

        IF v_chenhlech > 0 AND v_chenhlech > v_soluong THEN
            RAISE_APPLICATION_ERROR(-20002, 'Khong du hang');
        END IF;

        UPDATE SanPham
        SET SoLuong = SoLuong - v_chenhlech
        WHERE MaSP = :NEW.MaSP;

    END BEFORE EACH ROW;

END trg_CapNhatXuat;
/
-- Thực thi trigger (test):
INSERT INTO Xuat VALUES ('HDX1','SP1',5);

UPDATE Xuat SET SoLuongX = 2 WHERE SoHDX='HDX1' AND MaSP='SP1';
UPDATE Xuat SET SoLuongX = 999 WHERE SoHDX='HDX1' AND MaSP='SP1';

--2b. Trigger UPDATE bảng NHAP – trg_CapNhatNhap
CREATE OR REPLACE TRIGGER trg_CapNhatNhap
FOR UPDATE ON Nhap
COMPOUND TRIGGER

    v_chenhlech NUMBER;

    BEFORE STATEMENT IS
    BEGIN
        pkg_state.g_row_count := 0;
    END BEFORE STATEMENT;

    BEFORE EACH ROW IS
    BEGIN
        pkg_state.g_row_count := pkg_state.g_row_count + 1;

        IF pkg_state.g_row_count > 1 THEN
            RAISE_APPLICATION_ERROR(-20001, 'Chi duoc cap nhat 1 dong');
        END IF;

        v_chenhlech := :NEW.SoLuongN - :OLD.SoLuongN;

        UPDATE SanPham
        SET SoLuong = SoLuong + v_chenhlech
        WHERE MaSP = :NEW.MaSP;

    END BEFORE EACH ROW;

END trg_CapNhatNhap;
/

-- Thực thi trigger (test):
UPDATE Nhap SET SoLuongN = 10 WHERE SoHDN='HDN1' AND MaSP='SP1';

--2c. Trigger DELETE bảng NHAP – trg_XoaNhap
CREATE OR REPLACE TRIGGER trg_XoaNhap
AFTER DELETE ON Nhap
FOR EACH ROW
BEGIN
    UPDATE SanPham
    SET SoLuong = SoLuong - :OLD.SoLuongN
    WHERE MaSP = :OLD.MaSP;
END;
/
-- Thực thi trigger (test):
DELETE FROM Nhap WHERE SoHDN='HDN1' AND MaSP='SP1';