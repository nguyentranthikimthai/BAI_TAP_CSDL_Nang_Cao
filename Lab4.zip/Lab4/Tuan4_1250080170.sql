SQL> SHOW USER;
USER is "KIMTHAI"
SQL> CREATE TABLE course (
  2      courseno NUMBER(8,0) PRIMARY KEY,
  3      description VARCHAR2(50),
  4      cost NUMBER(9,2),
  5      prerequisite NUMBER(8,0),
  6      createdby VARCHAR2(30) NOT NULL,
  7      createddate DATE NOT NULL,
  8      modifiedby VARCHAR2(30) NOT NULL,
  9      modifieddate DATE NOT NULL
 10  );

Table created.

SQL> CREATE TABLE class (
  2      classid NUMBER(8,0) PRIMARY KEY,
  3      courseno NUMBER(8,0) NOT NULL,
  4      classno NUMBER(3) NOT NULL,
  5      startdatetime DATE,
  6      location VARCHAR2(50),
  7      instructorid NUMBER(8,0) NOT NULL,
  8      capacity NUMBER(3),
  9      createdby VARCHAR2(30) NOT NULL,
 10      createddate DATE NOT NULL,
 11      modifiedby VARCHAR2(30) NOT NULL,
 12      modifieddate DATE NOT NULL
 13  );

Table created.

SQL> CREATE TABLE student (
  2      studentid NUMBER(8,0) PRIMARY KEY,
  3      salutation VARCHAR2(5),
  4      firstname VARCHAR2(25),
  5      lastname VARCHAR2(25) NOT NULL,
  6      address VARCHAR2(50),
  7      phone VARCHAR2(15),
  8      employer VARCHAR2(50),
  9      registrationdate DATE NOT NULL,
 10      createdby VARCHAR2(30) NOT NULL,
 11      createddate DATE NOT NULL,
 12      modifiedby VARCHAR2(30) NOT NULL,
 13      modifieddate DATE NOT NULL
 14  );

Table created.

SQL> CREATE TABLE enrollment (
  2      studentid NUMBER(8,0) NOT NULL,
  3      classid NUMBER(8,0) NOT NULL,
  4      enrolldate DATE NOT NULL,
  5      finalgrade NUMBER(3),
  6      registrationdate DATE NOT NULL,
  7      createdby VARCHAR2(30) NOT NULL,
  8      createddate DATE NOT NULL,
  9      modifiedby VARCHAR2(30) NOT NULL,
 10      modifieddate DATE NOT NULL
 11  );

Table created.

SQL> CREATE TABLE instructor (
  2      instructorid NUMBER(8,0) PRIMARY KEY,
  3      salutation VARCHAR2(5),
  4      firstname VARCHAR2(25),
  5      lastname VARCHAR2(25),
  6      address VARCHAR2(50),
  7      phone VARCHAR2(15),
  8      createdby VARCHAR2(30) NOT NULL,
  9      createddate DATE NOT NULL,
 10      modifiedby VARCHAR2(30) NOT NULL,
 11      modifieddate DATE NOT NULL
 12  );

Table created.

SQL> CREATE TABLE grade (
  2      studentid NUMBER(8,0) NOT NULL,
  3      classid NUMBER(8,0) NOT NULL,
  4      grade NUMBER(3) NOT NULL,
  5      comments VARCHAR2(2000),
  6      createdby VARCHAR2(30) NOT NULL,
  7      createddate DATE NOT NULL,
  8      modifiedby VARCHAR2(30) NOT NULL,
  9      modifieddate DATE NOT NULL
 10  );

Table created.

SQL> INSERT INTO instructor VALUES (1,NULL,'An','Nguyen','HCM','0901',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (2,NULL,'Binh','Tran','HCM','0902',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (3,NULL,'Cuong','Le','HCM','0903',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (4,NULL,'Dung','Pham','HCM','0904',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (5,NULL,'Hieu','Hoang','HCM','0905',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (6,NULL,'Khanh','Vo','HCM','0906',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (7,NULL,'Linh','Dang','HCM','0907',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (8,NULL,'Minh','Bui','HCM','0908',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (9,NULL,'Nam','Do','HCM','0909',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (10,NULL,'Phong','Ngo','HCM','0910',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (11,NULL,'Quang','Ly','HCM','0911',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (12,NULL,'Son','Vu','HCM','0912',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (13,NULL,'Tuan','Phan','HCM','0913',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (14,NULL,'Viet','Huynh','HCM','0914',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (15,NULL,'Anh','Nguyen','HCM','0915',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (16,NULL,'Bao','Tran','HCM','0916',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (17,NULL,'Chau','Le','HCM','0917',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (18,NULL,'Duc','Pham','HCM','0918',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (19,NULL,'Giang','Hoang','HCM','0919',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (20,NULL,'Hung','Vo','HCM','0920',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (1,'Co so du lieu',100,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (2,'He quan tri CSDL',150,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (3,'Java',200,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (4,'Python',180,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (5,'C++',170,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (6,'Web',160,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (7,'HTML',120,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (8,'CSS',130,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (9,'JS',140,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (10,'React',220,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (11,'Angular',210,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (12,'Vue',205,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (13,'PHP',160,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (14,'Laravel',170,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (15,'Spring',250,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (16,'AI',300,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (17,'ML',320,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (18,'DL',350,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (19,'Data',280,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (20,'BigData',400,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (1,1,1,SYSDATE,'P101',1,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (2,2,1,SYSDATE,'P102',2,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (3,3,1,SYSDATE,'P103',3,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (4,4,1,SYSDATE,'P104',4,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (5,5,1,SYSDATE,'P105',5,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (6,6,1,SYSDATE,'P106',6,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (7,7,1,SYSDATE,'P107',7,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (8,8,1,SYSDATE,'P108',8,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (9,9,1,SYSDATE,'P109',9,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (10,10,1,SYSDATE,'P110',10,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (11,11,1,SYSDATE,'P111',1,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (12,12,1,SYSDATE,'P112',2,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (13,13,1,SYSDATE,'P113',3,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (14,14,1,SYSDATE,'P114',4,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (15,15,1,SYSDATE,'P115',5,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (16,16,1,SYSDATE,'P116',6,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (17,17,1,SYSDATE,'P117',7,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (18,18,1,SYSDATE,'P118',8,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (19,19,1,SYSDATE,'P119',9,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (20,20,1,SYSDATE,'P120',10,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (101,NULL,'An','Nguyen','HCM','0901','CTY A',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (102,NULL,'Binh','Tran','HCM','0902','CTY B',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (103,NULL,'Cuong','Le','HCM','0903','CTY C',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (104,NULL,'Dung','Pham','HCM','0904','CTY D',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (105,NULL,'Hieu','Hoang','HCM','0905','CTY E',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (106,NULL,'Khanh','Vo','HCM','0906','CTY F',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (107,NULL,'Linh','Dang','HCM','0907','CTY G',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (108,NULL,'Minh','Bui','HCM','0908','CTY H',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (109,NULL,'Nam','Do','HCM','0909','CTY I',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (110,NULL,'Phong','Ngo','HCM','0910','CTY K',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (111,NULL,'Quang','Ly','HCM','0911','CTY L',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (112,NULL,'Son','Vu','HCM','0912','CTY M',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (113,NULL,'Tuan','Phan','HCM','0913','CTY N',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (114,NULL,'Viet','Huynh','HCM','0914','CTY O',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (115,NULL,'Anh','Nguyen','HCM','0915','CTY P',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (116,NULL,'Bao','Tran','HCM','0916','CTY Q',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (117,NULL,'Chau','Le','HCM','0917','CTY R',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (118,NULL,'Duc','Pham','HCM','0918','CTY S',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (119,NULL,'Giang','Hoang','HCM','0919','CTY T',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (120,NULL,'Hung','Vo','HCM','0920','CTY U',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (101,1,SYSDATE,90,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (101,2,SYSDATE,80,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (101,3,SYSDATE,70,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (102,1,SYSDATE,60,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (103,2,SYSDATE,50,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (104,3,SYSDATE,85,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (105,4,SYSDATE,75,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (106,5,SYSDATE,65,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (107,6,SYSDATE,95,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (108,7,SYSDATE,88,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (109,8,SYSDATE,77,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (110,9,SYSDATE,66,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (111,10,SYSDATE,91,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (112,11,SYSDATE,82,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (113,12,SYSDATE,73,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (114,13,SYSDATE,64,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (115,14,SYSDATE,55,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (116,15,SYSDATE,89,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (117,16,SYSDATE,78,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (118,17,SYSDATE,68,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (119,18,SYSDATE,92,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (120,19,SYSDATE,85,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (101,1,90,'Tot',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (102,2,80,'Kha',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (103,3,70,'TB',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (104,4,85,'Tot',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (105,5,75,'Kha',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (106,6,65,'TB',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (107,7,95,'XS',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (108,8,88,'Tot',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (109,9,77,'Kha',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (110,10,66,'TB',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (999,1,SYSDATE,NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (998,2,SYSDATE,NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (997,3,SYSDATE,NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (996,4,SYSDATE,NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (995,5,SYSDATE,NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> COMMIT;

Commit complete.

SQL> SET SERVEROUTPUT ON;
SQL> CREATE OR REPLACE VIEW vw_course_summary AS
  2  SELECT co.courseno,
  3  co.description,
  4  co.cost,
  5  COUNT(DISTINCT cl.classid) AS so_lop,
  6  COUNT(e.studentid) AS tong_sv
  7  FROM course co
  8  LEFT JOIN class cl ON co.courseno = cl.courseno
  9  LEFT JOIN enrollment e ON cl.classid = e.classid
 10  GROUP BY co.courseno, co.description, co.cost
 11  ORDER BY tong_sv DESC;

View created.

SQL> DROP VIEW vw_course_summary;

View dropped.

SQL> SELECT text
  2  FROM user_views
  3  WHERE view_name = 'VW_COURSE_SUMMARY';

no rows selected

SQL> SELECT object_name, status
  2  FROM user_objects
  3  WHERE object_type = 'VIEW';

no rows selected

SQL> CREATE OR REPLACE VIEW vw_course_summary AS
  2  SELECT co.courseno,
  3  co.description,
  4  co.cost,
  5  COUNT(DISTINCT cl.classid) AS so_lop,
  6  COUNT(e.studentid) AS tong_sv
  7  FROM course co
  8  LEFT JOIN class cl ON co.courseno = cl.courseno
  9  LEFT JOIN enrollment e ON cl.classid = e.classid
 10  GROUP BY co.courseno, co.description, co.cost
 11  ORDER BY tong_sv DESC;

View created.

SQL> SET SERVEROUTPUT ON;
SQL> CREATE OR REPLACE VIEW vw_course_summary AS
  2  SELECT co.courseno,
  3  co.description,
  4  co.cost,
  5  COUNT(DISTINCT cl.classid) AS so_lop,
  6  COUNT(e.studentid) AS tong_sv
  7  LEFT JOIN class cl ON co.courseno = cl.courseno
  8  LEFT JOIN enrollment e ON cl.classid = e.classid
  9  GROUP BY co.courseno, co.description, co.cost
 10  ORDER BY tong_sv DESC;
LEFT JOIN class cl ON co.courseno = cl.courseno
*
ERROR at line 7:
ORA-00923: FROM keyword not found where expected 


SQL> SET SERVEROUTPUT ON;
SQL> CREATE OR REPLACE VIEW vw_course_summary AS
  2  SELECT co.courseno,
  3  co.description,
  4  co.cost,
  5  COUNT(DISTINCT cl.classid) AS so_lop,
  6  COUNT(e.studentid) AS tong_sv
  7  FROM course co
  8  LEFT JOIN class cl ON co.courseno = cl.courseno
  9  LEFT JOIN enrollment e ON cl.classid = e.classid
 10  GROUP BY co.courseno, co.description, co.cost
 11  ORDER BY tong_sv DESC;

View created.

SQL> SELECT * FROM vw_course_summary;

  COURSENO DESCRIPTION                                              COST        
---------- -------------------------------------------------- ----------        
    SO_LOP    TONG_SV                                                           
---------- ----------                                                           
         3 Java                                                      200        
         1          3                                                           
                                                                                
         2 He quan tri CSDL                                          150        
         1          3                                                           
                                                                                
         1 Co so du lieu                                             100        
         1          3                                                           
                                                                                

  COURSENO DESCRIPTION                                              COST        
---------- -------------------------------------------------- ----------        
    SO_LOP    TONG_SV                                                           
---------- ----------                                                           
         4 Python                                                    180        
         1          2                                                           
                                                                                
         5 C++                                                       170        
         1          2                                                           
                                                                                
         9 JS                                                        140        
         1          1                                                           
                                                                                

  COURSENO DESCRIPTION                                              COST        
---------- -------------------------------------------------- ----------        
    SO_LOP    TONG_SV                                                           
---------- ----------                                                           
         8 CSS                                                       130        
         1          1                                                           
                                                                                
         7 HTML                                                      120        
         1          1                                                           
                                                                                
         6 Web                                                       160        
         1          1                                                           
                                                                                

  COURSENO DESCRIPTION                                              COST        
---------- -------------------------------------------------- ----------        
    SO_LOP    TONG_SV                                                           
---------- ----------                                                           
        10 React                                                     220        
         1          1                                                           
                                                                                
        11 Angular                                                   210        
         1          1                                                           
                                                                                
        12 Vue                                                       205        
         1          1                                                           
                                                                                

  COURSENO DESCRIPTION                                              COST        
---------- -------------------------------------------------- ----------        
    SO_LOP    TONG_SV                                                           
---------- ----------                                                           
        13 PHP                                                       160        
         1          1                                                           
                                                                                
        14 Laravel                                                   170        
         1          1                                                           
                                                                                
        15 Spring                                                    250        
         1          1                                                           
                                                                                

  COURSENO DESCRIPTION                                              COST        
---------- -------------------------------------------------- ----------        
    SO_LOP    TONG_SV                                                           
---------- ----------                                                           
        16 AI                                                        300        
         1          1                                                           
                                                                                
        17 ML                                                        320        
         1          1                                                           
                                                                                
        18 DL                                                        350        
         1          1                                                           
                                                                                

  COURSENO DESCRIPTION                                              COST        
---------- -------------------------------------------------- ----------        
    SO_LOP    TONG_SV                                                           
---------- ----------                                                           
        19 Data                                                      280        
         1          1                                                           
                                                                                
        20 BigData                                                   400        
         1          0                                                           
                                                                                

20 rows selected.

SQL> CREATE OR REPLACE VIEW vw_student_status AS
  2  SELECT s.studentid,
  3  s.firstname || ' ' || s.lastname AS ho_ten,
  4  COUNT(e.classid) AS so_lop_hoc,
  5  NVL(SUM(co.cost), 0) AS tong_hoc_phi,
  6  ROUND(AVG(e.finalgrade), 2) AS diem_tb
  7  FROM student s
  8  JOIN enrollment e ON s.studentid = e.studentid
  9  JOIN class cl ON e.classid = cl.classid
 10  JOIN course co ON cl.courseno = co.courseno
 11  GROUP BY s.studentid, s.firstname, s.lastname
 12  HAVING COUNT(e.classid) >= 1
 13  ORDER BY s.studentid;

View created.

SQL> SELECT * FROM vw_student_status;

 STUDENTID HO_TEN                                              SO_LOP_HOC       
---------- --------------------------------------------------- ----------       
TONG_HOC_PHI    DIEM_TB                                                         
------------ ----------                                                         
       101 An Nguyen                                                    3       
         450         80                                                         
                                                                                
       102 Binh Tran                                                    1       
         100         60                                                         
                                                                                
       103 Cuong Le                                                     1       
         150         50                                                         
                                                                                

 STUDENTID HO_TEN                                              SO_LOP_HOC       
---------- --------------------------------------------------- ----------       
TONG_HOC_PHI    DIEM_TB                                                         
------------ ----------                                                         
       104 Dung Pham                                                    1       
         200         85                                                         
                                                                                
       105 Hieu Hoang                                                   1       
         180         75                                                         
                                                                                
       106 Khanh Vo                                                     1       
         170         65                                                         
                                                                                

 STUDENTID HO_TEN                                              SO_LOP_HOC       
---------- --------------------------------------------------- ----------       
TONG_HOC_PHI    DIEM_TB                                                         
------------ ----------                                                         
       107 Linh Dang                                                    1       
         160         95                                                         
                                                                                
       108 Minh Bui                                                     1       
         120         88                                                         
                                                                                
       109 Nam Do                                                       1       
         130         77                                                         
                                                                                

 STUDENTID HO_TEN                                              SO_LOP_HOC       
---------- --------------------------------------------------- ----------       
TONG_HOC_PHI    DIEM_TB                                                         
------------ ----------                                                         
       110 Phong Ngo                                                    1       
         140         66                                                         
                                                                                
       111 Quang Ly                                                     1       
         220         91                                                         
                                                                                
       112 Son Vu                                                       1       
         210         82                                                         
                                                                                

 STUDENTID HO_TEN                                              SO_LOP_HOC       
---------- --------------------------------------------------- ----------       
TONG_HOC_PHI    DIEM_TB                                                         
------------ ----------                                                         
       113 Tuan Phan                                                    1       
         205         73                                                         
                                                                                
       114 Viet Huynh                                                   1       
         160         64                                                         
                                                                                
       115 Anh Nguyen                                                   1       
         170         55                                                         
                                                                                

 STUDENTID HO_TEN                                              SO_LOP_HOC       
---------- --------------------------------------------------- ----------       
TONG_HOC_PHI    DIEM_TB                                                         
------------ ----------                                                         
       116 Bao Tran                                                     1       
         250         89                                                         
                                                                                
       117 Chau Le                                                      1       
         300         78                                                         
                                                                                
       118 Duc Pham                                                     1       
         320         68                                                         
                                                                                

 STUDENTID HO_TEN                                              SO_LOP_HOC       
---------- --------------------------------------------------- ----------       
TONG_HOC_PHI    DIEM_TB                                                         
------------ ----------                                                         
       119 Giang Hoang                                                  1       
         350         92                                                         
                                                                                
       120 Hung Vo                                                      1       
         280         85                                                         
                                                                                

20 rows selected.

SQL> CREATE OR REPLACE VIEW vw_class_availability AS
  2  SELECT cl.classid,
  3  cl.courseno,
  4  co.description,
  5  i.firstname || ' ' || i.lastname AS ten_giao_vien,
  6  cl.capacity,
  7  COUNT(e.studentid) AS so_da_dk,
  8  cl.capacity - COUNT(e.studentid) AS cho_trong,
  9  CASE
 10  WHEN cl.capacity - COUNT(e.studentid) > 0 THEN 'Con cho'
 11  ELSE 'Het cho'
 12  END AS trang_thai
 13  FROM class cl
 14  JOIN course co ON cl.courseno = co.courseno
 15  JOIN instructor i ON cl.instructorid = i.instructorid
 16  LEFT JOIN enrollment e ON cl.classid = e.classid
 17  GROUP BY cl.classid, cl.courseno, co.description,
 18  i.firstname, i.lastname, cl.capacity
 19  HAVING cl.capacity - COUNT(e.studentid) > 0
 20  ORDER BY cl.classid;

View created.

SQL> SELECT * FROM vw_class_availability;

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
         1          1 Co so du lieu                                             
An Nguyen                                                   30          3       
        27 Con cho                                                              
                                                                                
         2          2 He quan tri CSDL                                          
Binh Tran                                                   30          3       
        27 Con cho                                                              

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
                                                                                
         3          3 Java                                                      
Cuong Le                                                    30          3       
        27 Con cho                                                              
                                                                                
         4          4 Python                                                    
Dung Pham                                                   30          2       

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
        28 Con cho                                                              
                                                                                
         5          5 C++                                                       
Hieu Hoang                                                  30          2       
        28 Con cho                                                              
                                                                                
         6          6 Web                                                       

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
Khanh Vo                                                    30          1       
        29 Con cho                                                              
                                                                                
         7          7 HTML                                                      
Linh Dang                                                   30          1       
        29 Con cho                                                              
                                                                                

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
         8          8 CSS                                                       
Minh Bui                                                    30          1       
        29 Con cho                                                              
                                                                                
         9          9 JS                                                        
Nam Do                                                      30          1       
        29 Con cho                                                              

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
                                                                                
        10         10 React                                                     
Phong Ngo                                                   30          1       
        29 Con cho                                                              
                                                                                
        11         11 Angular                                                   
An Nguyen                                                   30          1       

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
        29 Con cho                                                              
                                                                                
        12         12 Vue                                                       
Binh Tran                                                   30          1       
        29 Con cho                                                              
                                                                                
        13         13 PHP                                                       

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
Cuong Le                                                    30          1       
        29 Con cho                                                              
                                                                                
        14         14 Laravel                                                   
Dung Pham                                                   30          1       
        29 Con cho                                                              
                                                                                

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
        15         15 Spring                                                    
Hieu Hoang                                                  30          1       
        29 Con cho                                                              
                                                                                
        16         16 AI                                                        
Khanh Vo                                                    30          1       
        29 Con cho                                                              

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
                                                                                
        17         17 ML                                                        
Linh Dang                                                   30          1       
        29 Con cho                                                              
                                                                                
        18         18 DL                                                        
Minh Bui                                                    30          1       

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
        29 Con cho                                                              
                                                                                
        19         19 Data                                                      
Nam Do                                                      30          1       
        29 Con cho                                                              
                                                                                
        20         20 BigData                                                   

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
TEN_GIAO_VIEN                                         CAPACITY   SO_DA_DK       
--------------------------------------------------- ---------- ----------       
 CHO_TRONG TRANG_T                                                              
---------- -------                                                              
Phong Ngo                                                   30          0       
        30 Con cho                                                              
                                                                                

20 rows selected.

SQL> CREATE OR REPLACE VIEW vw_top_courses AS
  2  SELECT courseno, description, cost, tong_dk, hang
  3  FROM (
  4  SELECT co.courseno,
  5  co.description,
  6  co.cost,
  7  COUNT(e.studentid) AS tong_dk,
  8  RANK() OVER (ORDER BY COUNT(e.studentid) DESC) AS hang
  9  FROM course co
 10  LEFT JOIN class cl ON co.courseno = cl.courseno
 11  LEFT JOIN enrollment e ON cl.classid = e.classid
 12  GROUP BY co.courseno, co.description, co.cost
 13  )
 14  WHERE hang <= 5
 15  ORDER BY hang
 16  WITH READ ONLY;

View created.

SQL> SELECT * FROM vw_top_courses;

  COURSENO DESCRIPTION                                              COST        
---------- -------------------------------------------------- ----------        
   TONG_DK       HANG                                                           
---------- ----------                                                           
         1 Co so du lieu                                             100        
         3          1                                                           
                                                                                
         2 He quan tri CSDL                                          150        
         3          1                                                           
                                                                                
         3 Java                                                      200        
         3          1                                                           
                                                                                

  COURSENO DESCRIPTION                                              COST        
---------- -------------------------------------------------- ----------        
   TONG_DK       HANG                                                           
---------- ----------                                                           
         4 Python                                                    180        
         2          4                                                           
                                                                                
         5 C++                                                       170        
         2          4                                                           
                                                                                

SQL> INSERT INTO vw_top_courses (courseno, description, cost)
  2  VALUES (999, 'Test', 100);
INSERT INTO vw_top_courses (courseno, description, cost)
                            *
ERROR at line 1:
ORA-01733: virtual column not allowed here 


SQL> INSERT INTO vw_top_courses (courseno, description, cost)
  2  VALUES (999, 'Test', 100);
INSERT INTO vw_top_courses (courseno, description, cost)
                            *
ERROR at line 1:
ORA-01733: virtual column not allowed here 


SQL> CREATE OR REPLACE VIEW vw_pending_enrollment AS
  2  SELECT studentid, classid, enrolldate, finalgrade,
  3  createdby, createddate, modifiedby, modifieddate
  4  FROM enrollment
  5  WHERE finalgrade IS NULL
  6  WITH CHECK OPTION;

View created.

SQL> SELECT * FROM vw_pending_enrollment;

 STUDENTID    CLASSID ENROLLDAT FINALGRADE CREATEDBY                            
---------- ---------- --------- ---------- ------------------------------       
CREATEDDA MODIFIEDBY                     MODIFIEDD                              
--------- ------------------------------ ---------                              
       999          1 20-APR-26            KIMTHAI                              
20-APR-26 KIMTHAI                        20-APR-26                              
                                                                                
       998          2 20-APR-26            KIMTHAI                              
20-APR-26 KIMTHAI                        20-APR-26                              
                                                                                
       997          3 20-APR-26            KIMTHAI                              
20-APR-26 KIMTHAI                        20-APR-26                              
                                                                                

 STUDENTID    CLASSID ENROLLDAT FINALGRADE CREATEDBY                            
---------- ---------- --------- ---------- ------------------------------       
CREATEDDA MODIFIEDBY                     MODIFIEDD                              
--------- ------------------------------ ---------                              
       996          4 20-APR-26            KIMTHAI                              
20-APR-26 KIMTHAI                        20-APR-26                              
                                                                                
       995          5 20-APR-26            KIMTHAI                              
20-APR-26 KIMTHAI                        20-APR-26                              
                                                                                

SQL> INSERT INTO vw_pending_enrollment (studentid, classid, enrolldate, createdby, createddate, modifiedby, modifieddate)
  2  VALUES (999, 1, SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO vw_pending_enrollment (studentid, classid, enrolldate, createdby, createddate, modifiedby, modifieddate)
*
ERROR at line 1:
ORA-01400: cannot insert NULL into ("KIMTHAI"."ENROLLMENT"."REGISTRATIONDATE") 


SQL> INSERT INTO vw_pending_enrollment (
  2      studentid, classid, enrolldate, registrationdate,
  3      createdby, createddate, modifiedby, modifieddate
  4  )
  5  VALUES (
  6      999, 1, SYSDATE, SYSDATE,
  7      USER, SYSDATE, USER, SYSDATE
  8  );
    studentid, classid, enrolldate, registrationdate,
                                    *
ERROR at line 2:
ORA-00904: "REGISTRATIONDATE": invalid identifier 


SQL> CREATE OR REPLACE VIEW vw_pending_enrollment AS
  2  SELECT
  3      studentid, classid, enrolldate, finalgrade,
  4      registrationdate,
  5      createdby, createddate, modifiedby, modifieddate
  6  FROM enrollment
  7  WHERE finalgrade IS NULL
  8  WITH CHECK OPTION;

View created.

SQL> INSERT INTO vw_pending_enrollment (
  2      studentid, classid, enrolldate, finalgrade, registrationdate,
  3      createdby, createddate, modifiedby, modifieddate
  4  )
  5  VALUES (
  6      998, 1, SYSDATE, 85, SYSDATE,
  7      USER, SYSDATE, USER, SYSDATE
  8  );
INSERT INTO vw_pending_enrollment (
            *
ERROR at line 1:
ORA-01402: view WITH CHECK OPTION where-clause violation 


SQL> INSERT INTO vw_pending_enrollment (
  2      studentid, classid, enrolldate, finalgrade, registrationdate,
  3      createdby, createddate, modifiedby, modifieddate
  4  )
  5  VALUES (
  6      997, 1, SYSDATE, NULL, SYSDATE,
  7      USER, SYSDATE, USER, SYSDATE
  8  );

1 row created.

SQL> CREATE OR REPLACE VIEW vw_pending_enrollment AS
  2  SELECT studentid, classid, enrolldate, finalgrade,
  3         createdby, createddate, modifiedby, modifieddate
  4  FROM enrollment
  5  WHERE finalgrade IS NULL
  6  WITH CHECK OPTION;

View created.

SQL> INSERT INTO vw_pending_enrollment (studentid, classid, enrolldate, finalgrade, createdby, createddate, modifiedby, modifieddate)
  2  VALUES (998, 1, SYSDATE, 85, USER, SYSDATE, USER, SYSDATE);
INSERT INTO vw_pending_enrollment (studentid, classid, enrolldate, finalgrade, createdby, createddate, modifiedby, modifieddate)
*
ERROR at line 1:
ORA-01400: cannot insert NULL into ("KIMTHAI"."ENROLLMENT"."REGISTRATIONDATE") 


SQL> CREATE OR REPLACE VIEW vw_pending_enrollment AS
  2  SELECT
  3      studentid, classid, enrolldate, finalgrade,
  4      registrationdate,
  5      createdby, createddate, modifiedby, modifieddate
  6  FROM enrollment
  7  WHERE finalgrade IS NULL
  8  WITH CHECK OPTION;

View created.

SQL> INSERT INTO vw_pending_enrollment (
  2      studentid, classid, enrolldate, finalgrade,
  3      registrationdate,
  4      createdby, createddate, modifiedby, modifieddate
  5  )
  6  VALUES (
  7      998, 1, SYSDATE, 85,
  8      SYSDATE,
  9      USER, SYSDATE, USER, SYSDATE
 10  );
INSERT INTO vw_pending_enrollment (
            *
ERROR at line 1:
ORA-01402: view WITH CHECK OPTION where-clause violation 


SQL> CREATE OR REPLACE PROCEDURE enroll_student
  2  (p_studentid IN NUMBER,
  3  p_classid IN NUMBER)
  4  IS
  5  v_check NUMBER;
  6  v_capacity NUMBER;
  7  v_enrolled NUMBER;
  8  BEGIN
  9  SELECT COUNT(*) INTO v_check FROM student WHERE studentid =
 10  p_studentid;
 11  IF v_check = 0 THEN
 12  DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien ' || p_studentid || ' khong
 13  ton tai!');
 14  RETURN;
 15  END IF;
 16  SELECT COUNT(*) INTO v_check FROM class WHERE classid =
 17  p_classid;
 18  IF v_check = 0 THEN
 19  DBMS_OUTPUT.PUT_LINE('[LOI] Lop hoc ' || p_classid || ' khong ton
 20  tai!');
 21  RETURN;
 22  END IF;
 23  SELECT capacity INTO v_capacity FROM class WHERE classid =
 24  p_classid;
 25  SELECT COUNT(*) INTO v_enrolled FROM enrollment WHERE classid =
 26  p_classid;
 27  IF v_enrolled >= v_capacity THEN
 28  DBMS_OUTPUT.PUT_LINE('[LOI] Lop ' || p_classid || ' da day! ('
 29  || v_enrolled || '/' || v_capacity || ')');
 30  RETURN;
 31  END IF;
 32  SELECT COUNT(*) INTO v_check FROM enrollment
 33  WHERE studentid = p_studentid AND classid = p_classid;
 34  IF v_check > 0 THEN
 35  DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky lop nay roi!');
 36  RETURN;
 37  END IF;
 38  SELECT COUNT(*) INTO v_check FROM enrollment WHERE studentid =
 39  p_studentid;
 40  IF v_check >= 3 THEN
 41  DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky du 3 lop!');
 42  RETURN;
 43  END IF;
 44  INSERT INTO enrollment
 45  (studentid, classid, enrolldate, createdby, createddate,
 46  modifiedby, modifieddate)
 47  VALUES
 48  (p_studentid, p_classid, SYSDATE, USER, SYSDATE, USER,
 49  SYSDATE);
 50  COMMIT;
 51  DBMS_OUTPUT.PUT_LINE('[OK] Dang ky thanh cong! SV ' || p_studentid
 52  || ' -> Lop ' || p_classid);
 53  EXCEPTION
 54  WHEN OTHERS THEN
 55  ROLLBACK;
 56  DBMS_OUTPUT.PUT_LINE('[LOI HE THONG] ' || SQLERRM);
 57  END enroll_student;
 58  /

Procedure created.

SQL> BEGIN
  2  enroll_student(101, 5); -- Hop le
  3  enroll_student(999, 5); -- SV khong ton tai
  4  enroll_student(101, 999); -- Lop khong ton tai
  5  END;
  6  /
[LOI] Sinh vien da dang ky du 3 lop!                                            
[LOI] Sinh vien 999 khong
ton tai!                                              
[LOI] Lop hoc 999 khong ton
tai!                                                

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE PROCEDURE update_final_grade
  2  (p_studentid IN NUMBER,
  3  p_classid IN NUMBER,
  4  p_grade IN NUMBER)
  5  IS
  6  v_check NUMBER;
  7  v_old_grade NUMBER;
  8  BEGIN
  9  IF p_grade < 0 OR p_grade > 100 THEN
 10  DBMS_OUTPUT.PUT_LINE('[LOI] Diem khong hop le! Phai tu 0 den
 11  100.');
 12  RETURN;
 13  END IF;
 14  SELECT COUNT(*) INTO v_check FROM enrollment
 15  WHERE studentid = p_studentid AND classid = p_classid;
 16  IF v_check = 0 THEN
 17  DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien chua dang ky lop nay!');
 18  RETURN;
 19  END IF;
 20  SELECT finalgrade INTO v_old_grade FROM enrollment
 21  WHERE studentid = p_studentid AND classid = p_classid;
 22  UPDATE enrollment
 23  SET finalgrade = p_grade,
 24  modifiedby = USER, modifieddate = SYSDATE
 25  WHERE studentid = p_studentid AND classid = p_classid;
 26  MERGE INTO grade g
 27  USING (SELECT p_studentid AS sid, p_classid AS cid FROM DUAL) src
 28  ON (g.studentid = src.sid AND g.classid = src.cid)
 29  WHEN MATCHED THEN
 30  UPDATE SET g.grade = p_grade,
 31  g.modifiedby = USER, g.modifieddate = SYSDATE
 32  WHEN NOT MATCHED THEN
 33  INSERT (studentid, classid, grade, createdby, createddate,
 34  modifiedby, modifieddate)
 35  VALUES (p_studentid, p_classid, p_grade,
 36  USER, SYSDATE, USER, SYSDATE);
 37  COMMIT;
 38  DBMS_OUTPUT.PUT_LINE('[OK] Da cap nhat diem SV ' || p_studentid
 39  || ' lop ' || p_classid
 40  || ': Cu=' || NVL(TO_CHAR(v_old_grade),'NULL')
 41  || ' -> Moi=' || p_grade);
 42  EXCEPTION
 43  WHEN OTHERS THEN
 44  ROLLBACK;
 45  DBMS_OUTPUT.PUT_LINE('[LOI] ' || SQLERRM);
 46  END update_final_grade;
 47  
 48  /

Procedure created.

SQL> CREATE OR REPLACE PROCEDURE report_class_detail
  2  (p_classid IN NUMBER)
  3  IS
  4  v_check NUMBER;
  5  v_course VARCHAR2(50);
  6  v_courseno NUMBER;
  7  v_gv VARCHAR2(50);
  8  v_loc VARCHAR2(50);
  9  v_cap NUMBER;
 10  v_stt NUMBER := 0;
 11  v_tong NUMBER := 0;
 12  v_sum_d NUMBER := 0;
 13  v_co_d NUMBER := 0;
 14  v_grade_txt VARCHAR2(15);
 15  BEGIN
 16  SELECT COUNT(*) INTO v_check FROM class WHERE classid =
 17  p_classid;
 18  IF v_check = 0 THEN
 19  DBMS_OUTPUT.PUT_LINE('Lop hoc ' || p_classid || ' khong ton tai!');
 20  RETURN;
 21  END IF;
 22  SELECT co.description, co.courseno,
 23  i.firstname || ' ' || i.lastname,
 24  cl.location, cl.capacity
 25  INTO v_course, v_courseno, v_gv, v_loc, v_cap
 26  FROM class cl
 27  JOIN course co ON cl.courseno = co.courseno
 28  JOIN instructor i ON cl.instructorid = i.instructorid
 29  WHERE cl.classid = p_classid;
 30  -- In header bao cao
 31  DBMS_OUTPUT.PUT_LINE('=== BAO CAO LOP HOC: ' || p_classid || '
 32  ===');
 33  DBMS_OUTPUT.PUT_LINE('Mon hoc : ' || v_courseno || ' - ' || v_course);
 34  DBMS_OUTPUT.PUT_LINE('Giao vien: ' || v_gv);
 35  DBMS_OUTPUT.PUT_LINE('Phong hoc: ' || NVL(v_loc, 'Chua xep
 36  phong'));
 37  DBMS_OUTPUT.PUT_LINE('Suc chua : ' || v_cap || ' cho');
 38  DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));
 39  DBMS_OUTPUT.PUT_LINE('DANH SACH SINH VIEN:');
 40  DBMS_OUTPUT.PUT_LINE(RPAD('STT',4) || ' | ' || RPAD('Ho Ten',20)
 41  || ' | ' || LPAD('Diem TK',8) || ' | Xep loai');
 42  DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));
 43  FOR rec IN (
 44  SELECT s.firstname || ' ' || s.lastname AS ho_ten,
 45  e.finalgrade
 46  FROM enrollment e
 47  JOIN student s ON e.studentid = s.studentid
 48  WHERE e.classid = p_classid
 49  ORDER BY s.lastname, s.firstname
 50  ) LOOP
 51  v_stt := v_stt + 1;
 52  v_tong := v_tong + 1;
 53  -- Xep loai
 54  IF rec.finalgrade IS NULL THEN
 55  v_grade_txt := 'Chua co diem';
 56  ELSIF rec.finalgrade >= 90 THEN
 57  v_grade_txt := 'A';
 58  v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;
 59  ELSIF rec.finalgrade >= 80 THEN
 60  v_grade_txt := 'B';
 61  v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;
 62  ELSIF rec.finalgrade >= 70 THEN
 63  v_grade_txt := 'C';
 64  v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;
 65  ELSIF rec.finalgrade >= 50 THEN
 66  v_grade_txt := 'D';
 67  v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;
 68  ELSE
 69  v_grade_txt := 'F';
 70  v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;
 71  END IF;
 72  DBMS_OUTPUT.PUT_LINE(
 73  LPAD(v_stt, 3) || ' | '
 74  || RPAD(rec.ho_ten, 20) || ' | '
 75  || LPAD(NVL(TO_CHAR(rec.finalgrade),'NULL'), 7) || ' | '
 76  || v_grade_txt
 77  );
 78  END LOOP;
 79  DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));
 80  DBMS_OUTPUT.PUT_LINE('Tong so sinh vien : ' || v_tong);
 81  IF v_co_d > 0 THEN
 82  DBMS_OUTPUT.PUT_LINE('Diem trung binh lop: '
 83  || ROUND(v_sum_d / v_co_d, 2));
 84  ELSE
 85  DBMS_OUTPUT.PUT_LINE('Diem trung binh lop: Chua co diem');
 86  END IF;
 87  END report_class_detail;
 88  /

Procedure created.

SQL> BEGIN
  2  report_class_detail(1);
  3  END;
  4  /
=== BAO CAO LOP HOC: 1
===                                                      
Mon hoc : 1 - Co so du lieu                                                     
Giao vien: An Nguyen                                                            
Phong hoc: P101                                                                 
Suc chua : 30 cho                                                               
--------------------------------------------------                              
DANH SACH SINH VIEN:                                                            
STT  | Ho Ten               |  Diem TK | Xep loai                               
--------------------------------------------------                              
1 | An Nguyen            |      90 | A                                          
2 | Binh Tran            |      60 | D                                          
--------------------------------------------------                              
Tong so sinh vien : 2                                                           
Diem trung binh lop: 75                                                         

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE PROCEDURE transfer_student
  2  (p_studentid IN NUMBER,
  3  p_old_classid IN NUMBER,
  4  p_new_classid IN NUMBER)
  5  IS
  6  v_check NUMBER;
  7  v_capacity NUMBER;
  8  v_enrolled NUMBER;
  9  BEGIN
 10  SELECT COUNT(*) INTO v_check FROM enrollment
 11  WHERE studentid = p_studentid AND classid = p_old_classid;
 12  IF v_check = 0 THEN
 13  DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien khong dang hoc lop ' ||
 14  p_old_classid);
 15  RETURN;
 16  END IF;
 17  SELECT capacity INTO v_capacity FROM class WHERE classid =
 18  p_new_classid;
 19  SELECT COUNT(*) INTO v_enrolled FROM enrollment WHERE classid =
 20  p_new_classid;
 21  IF v_enrolled >= v_capacity THEN
 22  DBMS_OUTPUT.PUT_LINE('[LOI] Lop moi ' || p_new_classid || ' da
 23  day!');
 24  RETURN;
 25  END IF;
 26  SELECT COUNT(*) INTO v_check FROM enrollment
 27  WHERE studentid = p_studentid AND classid = p_new_classid;
 28  IF v_check > 0 THEN
 29  DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da o trong lop moi roi!');
 30  RETURN;
 31  END IF;
 32  SAVEPOINT sp_truoc_chuyen;
 33  DELETE FROM enrollment
 34  WHERE studentid = p_studentid AND classid = p_old_classid;
 35  SAVEPOINT sp_sau_xoa;
 36  -- Buoc 2: Them vao lop moi
 37  INSERT INTO enrollment
 38  (studentid, classid, enrolldate, createdby, createddate,
 39  modifiedby, modifieddate)
 40  VALUES
 41  (p_studentid, p_new_classid, SYSDATE, USER, SYSDATE, USER,
 42  SYSDATE);
 43  COMMIT;
 44  DBMS_OUTPUT.PUT_LINE('[OK] Da chuyen SV ' || p_studentid
 45  || ' tu lop ' || p_old_classid
 46  || ' sang lop ' || p_new_classid);
 47  EXCEPTION
 48  WHEN OTHERS THEN
 49  ROLLBACK TO sp_truoc_chuyen;
 50  DBMS_OUTPUT.PUT_LINE('[LOI] Chuyen lop that bai: ' || SQLERRM);
 51  DBMS_OUTPUT.PUT_LINE('Da rollback ve trang thai ban dau.');
 52  END transfer_student;
 53  /

Procedure created.

SQL> CREATE OR REPLACE PROCEDURE sync_grade_from_enrollment
  2  IS
  3  v_check NUMBER;
  4  v_dem_insert NUMBER := 0;
  5  v_dem_update NUMBER := 0;
  6  BEGIN
  7  FOR rec IN (
  8  SELECT studentid, classid, finalgrade
  9  FROM enrollment
 10  WHERE finalgrade IS NOT NULL
 11  ) LOOP
 12  SELECT COUNT(*) INTO v_check FROM grade
 13  WHERE studentid = rec.studentid AND classid = rec.classid;
 14  IF v_check = 0 THEN
 15  INSERT INTO grade
 16  (studentid, classid, grade, createdby, createddate,
 17  modifiedby, modifieddate)
 18  VALUES
 19  (rec.studentid, rec.classid, rec.finalgrade,
 20  USER, SYSDATE, USER, SYSDATE);
 21  v_dem_insert := v_dem_insert + 1;
 22  ELSE
 23  UPDATE grade
 24  SET grade = rec.finalgrade,
 25  modifiedby = USER, modifieddate = SYSDATE
 26  WHERE studentid = rec.studentid AND classid = rec.classid;
 27  v_dem_update := v_dem_update + 1;
 28  END IF;
 29  END LOOP;
 30  COMMIT;
 31  DBMS_OUTPUT.PUT_LINE('[OK] Dong bo hoan tat!');
 32  DBMS_OUTPUT.PUT_LINE(' So ban ghi INSERT moi : ' ||
 33  v_dem_insert);
 34  DBMS_OUTPUT.PUT_LINE(' So ban ghi UPDATE : ' ||
 35  v_dem_update);
 36  EXCEPTION
 37  WHEN OTHERS THEN
 38  ROLLBACK;
 39  DBMS_OUTPUT.PUT_LINE('[LOI] ' || SQLERRM);
 40  END sync_grade_from_enrollment;
 41  /

Procedure created.

SQL> BEGIN sync_grade_from_enrollment; END; /
  2  B
  3  
  4  /
BEGIN sync_grade_from_enrollment; END; /
                                       *
ERROR at line 1:
ORA-06550: line 1, column 40: 
PLS-00103: Encountered the symbol "/"  


SQL> BEGIN
  2  sync_grade_from_enrollment;
  3  END;
  4  /
[OK] Dong bo hoan tat!                                                          
So ban ghi INSERT moi : 21                                                      
So ban ghi UPDATE : 1                                                           

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE TRIGGER trg_check_capacity
  2  BEFORE INSERT ON enrollment
  3  FOR EACH ROW
  4  DECLARE
  5  v_capacity NUMBER;
  6  v_enrolled NUMBER;
  7  BEGIN
  8  SELECT capacity INTO v_capacity
  9  FROM class WHERE classid = :NEW.classid;
 10  SELECT COUNT(*) INTO v_enrolled
 11  FROM enrollment WHERE classid = :NEW.classid;
 12  IF v_enrolled >= v_capacity THEN
 13  RAISE_APPLICATION_ERROR(
 14  -20010,
 15  'LOI: Lop ' || :NEW.classid || ' da day! ('
 16  || v_enrolled || '/' || v_capacity || ' cho)'
 17  );
 18  END IF;
 19  END trg_check_capacity;
 20  /

Trigger created.

SQL> INSERT INTO enrollment
  2  (studentid, classid, enrolldate, createdby, createddate,
  3  modifiedby, modifieddate)
  4  VALUES (999, 1, SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO enrollment
*
ERROR at line 1:
ORA-01400: cannot insert NULL into ("KIMTHAI"."ENROLLMENT"."REGISTRATIONDATE") 


SQL> CREATE TABLE grade_audit_log (
  2  log_id NUMBER GENERATED ALWAYS AS IDENTITY,
  3  studentid NUMBER(8),
  4  classid NUMBER(8),
  5  grade_cu NUMBER(3),
  6  grade_moi NUMBER(3),
  7  nguoi_sua VARCHAR2(30),
  8  thoi_gian DATE
  9  );

Table created.

SQL> /
CREATE TABLE grade_audit_log (
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> DROP TABLE grade_audit_log;

Table dropped.

SQL> CREATE TABLE grade_audit_log (
  2  log_id NUMBER GENERATED ALWAYS AS IDENTITY,
  3  studentid NUMBER(8),
  4  classid NUMBER(8),
  5  grade_cu NUMBER(3),
  6  grade_moi NUMBER(3),
  7  nguoi_sua VARCHAR2(30),
  8  thoi_gian DATE
  9  );

Table created.

SQL> CREATE OR REPLACE TRIGGER trg_grade_audit_log
  2  AFTER UPDATE OF finalgrade ON enrollment
  3  FOR EACH ROW
  4  BEGIN
  5  IF (:OLD.finalgrade IS NULL AND :NEW.finalgrade IS NOT NULL)
  6  OR (:OLD.finalgrade IS NOT NULL AND :NEW.finalgrade IS NULL)
  7  OR (:OLD.finalgrade != :NEW.finalgrade)
  8  THEN
  9  INSERT INTO grade_audit_log
 10  (studentid, classid, grade_cu, grade_moi, nguoi_sua, thoi_gian)
 11  VALUES
 12  (:OLD.studentid, :OLD.classid, :OLD.finalgrade,
 13  :NEW.finalgrade, USER, SYSDATE);
 14  END IF;
 15  END trg_grade_audit_log;
 16  /

Trigger created.

SQL> UPDATE enrollment SET finalgrade = 85
  2  WHERE studentid = 101 AND classid = 1;

1 row updated.

SQL> COMMIT;

Commit complete.

SQL> SELECT * FROM grade_audit_log;

    LOG_ID  STUDENTID    CLASSID   GRADE_CU  GRADE_MOI                          
---------- ---------- ---------- ---------- ----------                          
NGUOI_SUA                      THOI_GIAN                                        
------------------------------ ---------                                        
         1        101          1         90         85                          
KIMTHAI                        20-APR-26                                        
                                                                                

SQL> CREATE OR REPLACE TRIGGER trg_prevent_course_delete
  2  BEFORE DELETE ON course
  3  FOR EACH ROW
  4  DECLARE
  5  v_so_lop NUMBER;
  6  BEGIN
  7  SELECT COUNT(*) INTO v_so_lop
  8  FROM class WHERE courseno = :OLD.courseno;
  9  IF v_so_lop > 0 THEN
 10  RAISE_APPLICATION_ERROR(
 11  -20020,
 12  'Khong the xoa mon hoc ' || :OLD.courseno ||
 13  ' (' || :OLD.description || ') ' ||
 14  'vi con ' || v_so_lop || ' lop hoc dang ton tai!'
 15  );
 16  END IF;
 17  END trg_prevent_course_delete;
 18  /

Trigger created.

SQL> DELETE FROM course WHERE courseno = 10;
DELETE FROM course WHERE courseno = 10
            *
ERROR at line 1:
ORA-20020: Khong the xoa mon hoc 10 (React) vi con 1 lop hoc dang ton tai! 
ORA-06512: at "KIMTHAI.TRG_PREVENT_COURSE_DELETE", line 7 
ORA-04088: error during execution of trigger 
'KIMTHAI.TRG_PREVENT_COURSE_DELETE' 


SQL> DELETE FROM course WHERE courseno = 999; -- Mon khong co lop nao
  2  ROLLBACK;
DELETE FROM course WHERE courseno = 999; -- Mon khong co lop nao
                                       *
ERROR at line 1:
ORA-00933: SQL command not properly ended 


SQL> Trigger trg_update_grade_summary - c?p nh?t b?ng th?ng k� t? d?ng
SP2-0734: unknown command beginning "Trigger tr..." - rest of line ignored.
SQL> CREATE TABLE class_grade_summary (
  2  classid NUMBER(8) PRIMARY KEY,
  3  so_sv NUMBER,
  4  diem_tb NUMBER(5,2),
  5  diem_cao_nhat NUMBER(3),
  6  diem_thap_nhat NUMBER(3),
  7  cap_nhat_luc DATE
  8  );

Table created.

SQL> /
CREATE TABLE class_grade_summary (
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> DROP TABLE class_grade_summary;

Table dropped.

SQL> CREATE TABLE class_grade_summary (
  2  classid NUMBER(8) PRIMARY KEY,
  3  so_sv NUMBER,
  4  diem_tb NUMBER(5,2),
  5  diem_cao_nhat NUMBER(3),
  6  diem_thap_nhat NUMBER(3),
  7  cap_nhat_luc DATE
  8  );

Table created.

SQL> CREATE OR REPLACE TRIGGER trg_update_grade_summary
  2  AFTER INSERT OR UPDATE OR DELETE ON enrollment
  3  FOR EACH ROW
  4  DECLARE
  5  v_classid NUMBER;
  6  v_so_sv NUMBER;
  7  v_diem_tb NUMBER;
  8  v_max_d NUMBER;
  9  v_min_d NUMBER;
 10  BEGIN
 11  IF INSERTING OR UPDATING THEN
 12  v_classid := :NEW.classid;
 13  ELSE -- DELETING
 14  v_classid := :OLD.classid;
 15  END IF;
 16  SELECT COUNT(finalgrade),
 17  ROUND(AVG(finalgrade), 2),
 18  MAX(finalgrade),
 19  MIN(finalgrade)
 20  INTO v_so_sv, v_diem_tb, v_max_d, v_min_d
 21  FROM enrollment
 22  WHERE classid = v_classid AND finalgrade IS NOT NULL;
 23  MERGE INTO class_grade_summary cgs
 24  USING (SELECT v_classid AS cid FROM DUAL) src
 25  ON (cgs.classid = src.cid)
 26  WHEN MATCHED THEN
 27  UPDATE SET
 28  so_sv = v_so_sv,
 29  diem_tb = v_diem_tb,
 30  diem_cao_nhat = v_max_d,
 31  diem_thap_nhat = v_min_d,
 32  cap_nhat_luc = SYSDATE
 33  WHEN NOT MATCHED THEN
 34  INSERT (classid, so_sv, diem_tb, diem_cao_nhat, diem_thap_nhat,
 35  cap_nhat_luc)
 36  VALUES (v_classid, v_so_sv, v_diem_tb, v_max_d, v_min_d,
 37  SYSDATE);
 38  END trg_update_grade_summary;
 39  /

Trigger created.

SQL> UPDATE enrollment SET finalgrade = 90 WHERE studentid=101 AND
  2  classid=1;
UPDATE enrollment SET finalgrade = 90 WHERE studentid=101 AND
       *
ERROR at line 1:
ORA-04091: table KIMTHAI.ENROLLMENT is mutating, trigger/function may not see 
it 
ORA-06512: at "KIMTHAI.TRG_UPDATE_GRADE_SUMMARY", line 13 
ORA-04088: error during execution of trigger 'KIMTHAI.TRG_UPDATE_GRADE_SUMMARY' 


SQL> COMMIT;

Commit complete.

SQL> SELECT * FROM class_grade_summary WHERE classid = 1;

no rows selected

SQL> CREATE OR REPLACE VIEW vw_instructor_workload AS
  2  SELECT i.instructorid,
  3  i.firstname || ' ' || i.lastname AS ho_ten,
  4  COUNT(DISTINCT cl.classid) AS so_lop,
  5  COUNT(e.studentid) AS tong_sv,
  6  ROUND(AVG(e.finalgrade), 2) AS diem_tb_chung,
  7  CASE
  8  WHEN COUNT(DISTINCT cl.classid) >= 3 THEN 'Ban nhieu'
  9  WHEN COUNT(DISTINCT cl.classid) = 2 THEN 'Binh thuong'
 10  ELSE 'Nhe nhang'
 11  END AS muc_ban
 12  FROM instructor i
 13  LEFT JOIN class cl ON i.instructorid = cl.instructorid
 14  LEFT JOIN enrollment e ON cl.classid = e.classid
 15  GROUP BY i.instructorid, i.firstname, i.lastname
 16  ORDER BY so_lop DESC;

View created.

SQL> SELECT * FROM vw_instructor_workload;

INSTRUCTORID HO_TEN                                                  SO_LOP     
------------ --------------------------------------------------- ----------     
   TONG_SV DIEM_TB_CHUNG MUC_BAN                                                
---------- ------------- -----------                                            
           1 An Nguyen                                                    2     
         5         75.67 Binh thuong                                            
                                                                                
           2 Binh Tran                                                    2     
         4         67.67 Binh thuong                                            
                                                                                
          10 Phong Ngo                                                    2     
         1            91 Binh thuong                                            
                                                                                

INSTRUCTORID HO_TEN                                                  SO_LOP     
------------ --------------------------------------------------- ----------     
   TONG_SV DIEM_TB_CHUNG MUC_BAN                                                
---------- ------------- -----------                                            
           9 Nam Do                                                       2     
         2          75.5 Binh thuong                                            
                                                                                
           8 Minh Bui                                                     2     
         2          84.5 Binh thuong                                            
                                                                                
           7 Linh Dang                                                    2     
         2            78 Binh thuong                                            
                                                                                

INSTRUCTORID HO_TEN                                                  SO_LOP     
------------ --------------------------------------------------- ----------     
   TONG_SV DIEM_TB_CHUNG MUC_BAN                                                
---------- ------------- -----------                                            
           6 Khanh Vo                                                     2     
         2          86.5 Binh thuong                                            
                                                                                
           5 Hieu Hoang                                                   2     
         3            77 Binh thuong                                            
                                                                                
           4 Dung Pham                                                    2     
         3            65 Binh thuong                                            
                                                                                

INSTRUCTORID HO_TEN                                                  SO_LOP     
------------ --------------------------------------------------- ----------     
   TONG_SV DIEM_TB_CHUNG MUC_BAN                                                
---------- ------------- -----------                                            
           3 Cuong Le                                                     2     
         4            73 Binh thuong                                            
                                                                                
          14 Viet Huynh                                                   0     
         0               Nhe nhang                                              
                                                                                
          19 Giang Hoang                                                  0     
         0               Nhe nhang                                              
                                                                                

INSTRUCTORID HO_TEN                                                  SO_LOP     
------------ --------------------------------------------------- ----------     
   TONG_SV DIEM_TB_CHUNG MUC_BAN                                                
---------- ------------- -----------                                            
          13 Tuan Phan                                                    0     
         0               Nhe nhang                                              
                                                                                
          20 Hung Vo                                                      0     
         0               Nhe nhang                                              
                                                                                
          16 Bao Tran                                                     0     
         0               Nhe nhang                                              
                                                                                

INSTRUCTORID HO_TEN                                                  SO_LOP     
------------ --------------------------------------------------- ----------     
   TONG_SV DIEM_TB_CHUNG MUC_BAN                                                
---------- ------------- -----------                                            
          17 Chau Le                                                      0     
         0               Nhe nhang                                              
                                                                                
          12 Son Vu                                                       0     
         0               Nhe nhang                                              
                                                                                
          11 Quang Ly                                                     0     
         0               Nhe nhang                                              
                                                                                

INSTRUCTORID HO_TEN                                                  SO_LOP     
------------ --------------------------------------------------- ----------     
   TONG_SV DIEM_TB_CHUNG MUC_BAN                                                
---------- ------------- -----------                                            
          15 Anh Nguyen                                                   0     
         0               Nhe nhang                                              
                                                                                
          18 Duc Pham                                                     0     
         0               Nhe nhang                                              
                                                                                

20 rows selected.

SQL> CREATE OR REPLACE PROCEDURE print_system_report
  2  IS
  3  v_so_mon NUMBER;
  4  v_so_lop NUMBER;
  5  v_so_sv NUMBER;
  6  v_so_gv NUMBER;
  7  BEGIN
  8  SELECT COUNT(*) INTO v_so_mon FROM course;
  9  SELECT COUNT(*) INTO v_so_lop FROM class;
 10  SELECT COUNT(*) INTO v_so_sv FROM student;
 11  SELECT COUNT(*) INTO v_so_gv FROM instructor;
 12  DBMS_OUTPUT.PUT_LINE('==================================
 13  ==========');
 14  DBMS_OUTPUT.PUT_LINE(' BAO CAO TOAN HE THONG QUAN LY
 15  KHOA HOC');
 16  DBMS_OUTPUT.PUT_LINE('==================================
 17  ==========');
 18  DBMS_OUTPUT.PUT_LINE('Tong so mon hoc : ' || v_so_mon);
 19  DBMS_OUTPUT.PUT_LINE('Tong so lop hoc : ' || v_so_lop);
 20  DBMS_OUTPUT.PUT_LINE('Tong so sinh vien: ' || v_so_sv);
 21  DBMS_OUTPUT.PUT_LINE('Tong so giao vien: ' || v_so_gv);
 22  DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));
 23  DBMS_OUTPUT.PUT_LINE('THONG KE GIAO VIEN:');
 24  FOR rec IN (SELECT * FROM vw_instructor_workload) LOOP
 25  DBMS_OUTPUT.PUT_LINE(
 26  ' ' || RPAD(rec.ho_ten, 25)
 27  || ' | ' || LPAD(rec.so_lop, 2) || ' lop'
 28  || ' | ' || LPAD(rec.tong_sv, 3) || ' SV'
 29  || ' | DTB: ' || NVL(TO_CHAR(rec.diem_tb_chung),'--')
 30  || ' | ' || rec.muc_ban
 31  );
 32  END LOOP;
 33  DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));
 34  DBMS_OUTPUT.PUT_LINE('TOP 3 MON HOC DUOC DANG KY
 35  NHIEU NHAT:');
 36  FOR rec IN (SELECT * FROM vw_top_courses WHERE hang <= 3) LOOP
 37  DBMS_OUTPUT.PUT_LINE(
 38  ' ' || rec.hang || '. '
 39  || RPAD(rec.description, 30)
 40  || ' - ' || rec.tong_dk || ' luot dang ky'
 41  );
 42  END LOOP;
 43  DBMS_OUTPUT.PUT_LINE('==================================
 44  ==========');
 45  END print_system_report;
 46  /

Procedure created.

SQL> SET SERVEROUTPUT ON SIZE 1000000;
SQL> BEGIN
  2  print_system_report;
  3  END;
  4  /
==================================
==========                                   
BAO CAO TOAN HE THONG QUAN LY
KHOA HOC                                          
==================================
==========                                   
Tong so mon hoc : 20                                                            
Tong so lop hoc : 20                                                            
Tong so sinh vien: 20                                                           
Tong so giao vien: 20                                                           
--------------------------------------------------                              
THONG KE GIAO VIEN:                                                             
An Nguyen                 |  2 lop |   5 SV | DTB: 75.67 | Binh thuong          
Binh Tran                 |  2 lop |   4 SV | DTB: 67.67 | Binh thuong          
Phong Ngo                 |  2 lop |   1 SV | DTB: 91 | Binh thuong             
Nam Do                    |  2 lop |   2 SV | DTB: 75.5 | Binh thuong           
Minh Bui                  |  2 lop |   2 SV | DTB: 84.5 | Binh thuong           
Linh Dang                 |  2 lop |   2 SV | DTB: 78 | Binh thuong             
Khanh Vo                  |  2 lop |   2 SV | DTB: 86.5 | Binh thuong           
Hieu Hoang                |  2 lop |   3 SV | DTB: 77 | Binh thuong             
Dung Pham                 |  2 lop |   3 SV | DTB: 65 | Binh thuong             
Cuong Le                  |  2 lop |   4 SV | DTB: 73 | Binh thuong             
Viet Huynh                |  0 lop |   0 SV | DTB: -- | Nhe nhang               
Giang Hoang               |  0 lop |   0 SV | DTB: -- | Nhe nhang               
Tuan Phan                 |  0 lop |   0 SV | DTB: -- | Nhe nhang               
Hung Vo                   |  0 lop |   0 SV | DTB: -- | Nhe nhang               
Bao Tran                  |  0 lop |   0 SV | DTB: -- | Nhe nhang               
Chau Le                   |  0 lop |   0 SV | DTB: -- | Nhe nhang               
Son Vu                    |  0 lop |   0 SV | DTB: -- | Nhe nhang               
Quang Ly                  |  0 lop |   0 SV | DTB: -- | Nhe nhang               
Anh Nguyen                |  0 lop |   0 SV | DTB: -- | Nhe nhang               
Duc Pham                  |  0 lop |   0 SV | DTB: -- | Nhe nhang               
--------------------------------------------------                              
TOP 3 MON HOC DUOC DANG KY
NHIEU NHAT:                                          
1. Co so du lieu                  - 4 luot dang ky                              
2. Java                           - 3 luot dang ky                              
2. He quan tri CSDL               - 3 luot dang ky                              
==================================
==========                                   

PL/SQL procedure successfully completed.

SQL> COMMIT;

Commit complete.

SQL> SPOOL OFF;
