CREATE TABLE regions (
    region_id NUMBER PRIMARY KEY,
    region_name VARCHAR2(50)
);

CREATE TABLE countries (
    country_id VARCHAR2(5) PRIMARY KEY,
    country_name VARCHAR2(50),
    region_id NUMBER
);

CREATE TABLE locations (
    location_id NUMBER PRIMARY KEY,
    city VARCHAR2(50),
    country_id VARCHAR2(5)
);

CREATE TABLE departments (
    department_id NUMBER PRIMARY KEY,
    department_name VARCHAR2(50),
    location_id NUMBER
);

CREATE TABLE jobs (
    job_id VARCHAR2(20) PRIMARY KEY,
    job_title VARCHAR2(50)
);

CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    last_name VARCHAR2(50),
    job_id VARCHAR2(20),
    hire_date DATE,
    salary NUMBER,
    manager_id NUMBER,
    department_id NUMBER,
    commission_pct NUMBER
);

CREATE TABLE job_history (
    employee_id NUMBER,
    start_date DATE,
    end_date DATE,
    job_id VARCHAR2(20),
    department_id NUMBER
);

INSERT INTO regions VALUES (1, 'Asia');
INSERT INTO regions VALUES (2, 'Europe');
INSERT INTO regions VALUES (3, 'America');

INSERT INTO countries VALUES ('VN', 'Vietnam', 1);
INSERT INTO countries VALUES ('JP', 'Japan', 1);
INSERT INTO countries VALUES ('US', 'USA', 3);
INSERT INTO countries VALUES ('FR', 'France', 2);

INSERT INTO locations VALUES (100, 'Hanoi', 'VN');
INSERT INTO locations VALUES (110, 'HoChiMinh', 'VN');
INSERT INTO locations VALUES (200, 'Tokyo', 'JP');
INSERT INTO locations VALUES (300, 'NewYork', 'US');
INSERT INTO locations VALUES (400, 'Paris', 'FR');

INSERT INTO departments VALUES (10, 'IT', 100);
INSERT INTO departments VALUES (20, 'Sales', 300);
INSERT INTO departments VALUES (30, 'HR', 400);
INSERT INTO departments VALUES (40, 'Finance', 200);
INSERT INTO departments VALUES (50, 'Logistics', 110);

INSERT INTO jobs VALUES ('IT_PROG', 'Programmer');
INSERT INTO jobs VALUES ('SA_REP', 'Sales Rep');
INSERT INTO jobs VALUES ('ST_CLERK', 'Stock Clerk');
INSERT INTO jobs VALUES ('HR_REP', 'HR Staff');
INSERT INTO jobs VALUES ('FI_MGR', 'Finance Manager');

INSERT INTO employees VALUES (1, 'Nguyen', 'IT_PROG', DATE '2020-01-10', 15000, NULL, 10, NULL);
INSERT INTO employees VALUES (2, 'Tran', 'SA_REP', DATE '2021-03-15', 4000, 1, 20, 0.1);
INSERT INTO employees VALUES (3, 'Le', 'ST_CLERK', DATE '2019-07-20', 7000, 1, 20, NULL);
INSERT INTO employees VALUES (4, 'Pham', 'IT_PROG', DATE '2018-05-01', 12000, 1, 10, NULL);
INSERT INTO employees VALUES (5, 'Hoang', 'HR_REP', DATE '2022-08-12', 6000, 4, 30, NULL);
INSERT INTO employees VALUES (6, 'Vo', 'FI_MGR', DATE '2017-11-30', 20000, NULL, 40, NULL);
INSERT INTO employees VALUES (7, 'Dang', 'SA_REP', DATE '2020-06-18', 4500, 2, 20, 0.15);
INSERT INTO employees VALUES (8, 'Bui', 'IT_PROG', DATE '2023-02-10', 9000, 4, 10, NULL);
INSERT INTO employees VALUES (9, 'Do', 'ST_CLERK', DATE '2021-09-25', 3500, 3, 50, NULL);
INSERT INTO employees VALUES (10, 'Nguyen', 'SA_REP', DATE '2019-12-05', 8000, 2, 20, 0.2);
INSERT INTO employees VALUES (11, 'Le', 'IT_PROG', DATE '2022-04-17', 11000, 4, 10, NULL);
INSERT INTO employees VALUES (12, 'Tran', 'HR_REP', DATE '2023-01-01', 5000, 5, 30, NULL);
INSERT INTO employees VALUES (13, 'Pham', 'FI_MGR', DATE '2016-10-10', 18000, NULL, 40, NULL);
INSERT INTO employees VALUES (14, 'Hoang', 'ST_CLERK', DATE '2020-07-07', 3200, 3, 50, NULL);
INSERT INTO employees VALUES (15, 'Vo', 'SA_REP', DATE '2021-11-11', 6000, 2, 20, 0.05);

INSERT INTO job_history VALUES (2, DATE '2020-01-01', DATE '2021-03-01', 'ST_CLERK', 50);
INSERT INTO job_history VALUES (3, DATE '2018-01-01', DATE '2019-07-01', 'SA_REP', 20);
INSERT INTO job_history VALUES (5, DATE '2021-01-01', DATE '2022-08-01', 'ST_CLERK', 50);

COMMIT;

SELECT last_name, salary
FROM employees
WHERE salary > 12000;

SELECT last_name, salary
FROM employees
WHERE salary < 5000 OR salary > 12000;

SELECT last_name, salary
FROM employees
WHERE salary NOT BETWEEN 5000 AND 12000;

SELECT last_name, job_id, hire_date
FROM employees
WHERE hire_date BETWEEN
TO_DATE('20/02/1998', 'DD/MM/YYYY')
AND TO_DATE('01/05/1998', 'DD/MM/YYYY')
ORDER BY hire_date ASC;

SELECT last_name, department_id
FROM employees
WHERE department_id IN (20, 50)
ORDER BY last_name ASC;

SELECT last_name, hire_date
FROM employees
WHERE TO_CHAR(hire_date, 'YYYY ') = '1994 ';

SELECT last_name, hire_date
FROM employees
WHERE hire_date BETWEEN
TO_DATE('01/01/1994', 'DD/MM/YYYY')
AND TO_DATE('31/12/1994', 'DD/MM/YYYY');

SELECT last_name, job_id
FROM employees
WHERE manager_id IS NULL;

SELECT last_name, salary, commission_pct
FROM employees
WHERE commission_pct IS NOT NULL
ORDER BY salary DESC, commission_pct DESC;

SELECT last_name
FROM employees
WHERE last_name LIKE '__a% ';

SELECT last_name
FROM employees
WHERE last_name LIKE '%a% ';
AND last_name LIKE '%e% ';

SELECT last_name, job_id, salary
FROM employees
WHERE job_id IN ('SA_REP', 'ST_CLERK')
AND salary NOT IN (2500, 3500, 7000);

SELECT employee_id,
last_name,
ROUND(salary * 1.15, 0) AS "New Salary"
FROM employees;

SELECT INITCAP(last_name) AS "Ten Nhan Vien",
LENGTH(last_name) AS "Chieu Dai"
FROM employees
WHERE SUBSTR(last_name, 1, 1) IN ('N', 'T', 'L', 'P')
ORDER BY last_name ASC;

SELECT last_name,
TRUNC(MONTHS_BETWEEN(SYSDATE, hire_date)) AS "So Thang Lam Viec"
FROM employees
ORDER BY MONTHS_BETWEEN(SYSDATE, hire_date) ASC;

SELECT last_name || 'earns' ||
TO_CHAR(salary,'$99,999') || 'monthly but wants' ||
TO_CHAR(salary*3,'$99,999') AS "Dream Salaries"
FROM employees;

SELECT last_name,
CASE WHEN commission_pct IS NULL THEN 'No commission'
ELSE TO_CHAR(commission_pct)
END AS "Commission"
FROM employees;

SELECT last_name,
NVL(TO_CHAR(commission_pct), 'No commission') AS "Commission"
FROM employees;

SELECT job_id,
DECODE(job_id,
'AD_PRES', 'A',
'ST_MAN', 'B',
'IT_PROG', 'C',
'SA_REP', 'D',
'ST_CLERK', 'E',
'0') AS "GRADE"
FROM employees;

SELECT job_id,
CASE job_id
WHEN 'AD_PRES' THEN 'A'
WHEN 'ST_MAN' THEN 'B'
WHEN 'IT_PROG' THEN 'C'
WHEN 'SA_REP' THEN 'D'
WHEN 'ST_CLERK' THEN 'E'
ELSE '0'
END AS "GRADE"
FROM employees;

SELECT e.last_name, e.department_id, d.department_name
FROM employees e, departments d, locations l
WHERE e.department_id = d.department_id
AND d.location_id = l.location_id
AND UPPER(l.city) = 'TORONTO';

SELECT e.employee_id AS "Ma NV",
e.last_name AS "Ten NV",
m.employee_id AS "Ma Quan Ly",
m.last_name AS "Ten Quan Ly"
FROM employees e, employees m
WHERE e.manager_id = m.employee_id;

SELECT e1.last_name AS "Nhan Vien 1",
e2.last_name AS "Nhan Vien 2",
e1.department_id AS "Phong Ban"
FROM employees e1, employees e2
WHERE e1.department_id = e2.department_id;

SELECT last_name, hire_date
FROM employees
WHERE hire_date > (SELECT hire_date
FROM employees
WHERE last_name = 'Davies');

SELECT e.last_name AS "Nhan Vien",
e.hire_date AS "Ngay Vao",
m.last_name AS "Quan Ly ",
m.hire_date AS "Quan Ly Vao"
FROM employees e, employees m

WHERE e.manager_id = m.employee_id
AND e.hire_date  <  m.hire_date;

SELECT job_id,
MIN(salary) AS "Luong Thap Nhat",
MAX(salary) AS "Luong Cao Nhat",
ROUND(AVG(salary),2) AS "Luong Trung Binh",
SUM(salary) AS "Tong Luong"
FROM employees
GROUP BY job_id
ORDER BY job_id;

SELECT d.department_id,
d.department_name,
COUNT(e.employee_id) AS "So Nhan Vien"
FROM departments d LEFT JOIN employees e
ON d.department_id = e.department_id
GROUP BY d.department_id, d.department_name
ORDER BY d.department_id;

SELECT COUNT(*) AS "Tong NV",
SUM(CASE WHEN TO_CHAR(hire_date, 'YYYY') = '1995'  THEN 1 ELSE 0 END) AS "Nam 1995",
SUM(CASE WHEN TO_CHAR(hire_date, 'YYYY')= '1996' THEN 1 ELSE 0 END) AS "Nam 1996",
SUM(CASE WHEN TO_CHAR(hire_date, 'YYYY')= '1997' THEN 1 ELSE 0 END) AS "Nam 1997",
SUM(CASE WHEN TO_CHAR(hire_date, 'YYYY')= '1998' THEN 1 ELSE 0 END) AS "Nam1998"
FROM employees;

SELECT last_name, hire_date
FROM employees
WHERE department_id = (SELECT department_id 
FROM employees
WHERE last_name = 'Zlotkey')
AND last_name <> 'Zlotkey';

SELECT last_name, department_id, job_id
FROM employees
WHERE department_id IN (SELECT department_id 
FROM departments
WHERE location_id = 1700);

SELECT last_name, manager_id
FROM employees
WHERE manager_id IN (SELECT employee_id 
FROM employees
WHERE last_name = 'King');

SELECT last_name, salary, department_id
FROM employees
WHERE salary > (SELECT AVG(salary) FROM employees)
AND department_id IN ( SELECT department_id 
FROM employees
WHERE last_name LIKE '%n');

SELECT department_id, department_name
FROM departments d
WHERE (
    SELECT COUNT(*)
    FROM employees e
    WHERE e.department_id = d.department_id
) < 3
ORDER BY department_id;

SELECT d.department_id, d.department_name, COUNT(e.employee_id) AS "So NV"
FROM departments d LEFT JOIN employees e
ON d.department_id = e.department_id
GROUP BY d.department_id, d.department_name
HAVING COUNT(e.employee_id) < 3
ORDER BY d.department_id;

SELECT department_id, COUNT(*) AS "So Nhan Vien", 'Dong nhat' AS "Loai"
FROM employees
GROUP BY department_id
HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM employees GROUP BY
department_id)
UNION ALL
SELECT department_id, COUNT(*), 'It nhat'
FROM employees
GROUP BY department_id
HAVING COUNT(*) = (SELECT MIN(COUNT(*)) FROM employees GROUP BY
department_id);

SELECT last_name, hire_date
FROM employees
WHERE TO_CHAR(hire_date,'Day') = (
SELECT TO_CHAR(hire_date,'Day')
FROM employees
GROUP BY TO_CHAR(hire_date,'Day')
HAVING COUNT(*) = (
SELECT MAX(COUNT(*))
FROM employees
GROUP BY TO_CHAR(hire_date,'Day')));

SELECT last_name, salary
FROM (
SELECT last_name, salary
FROM employees
ORDER BY salary DESC)
WHERE ROWNUM <= 3;

SELECT e.last_name, e.department_id
FROM employees e,
departments d,
locations l
WHERE e.department_id = d.department_id
AND d.location_id = l.location_id
AND UPPER(l. city) = 'CALIFORNIA';

SELECT employee_id, last_name FROM employees WHERE employee_id = 3;

UPDATE employees
SET last_name = 'Drexler'
WHERE employee_id = 3;

SELECT employee_id, last_name FROM employees WHERE employee_id = 3;

SELECT e1.last_name, e1.salary, e1.department_id
FROM employees e1
WHERE e1.salary < (SELECT AVG(e2.salary)
FROM employees e2
WHERE e2.department_id = e1.department_id)
ORDER BY e1.department_id;

SELECT employee_id, last_name, salary
FROM employees
WHERE salary < 900;

UPDATE employees
SET salary = salary + 100
WHERE salary < 900;

COMMIT;

SELECT COUNT(*) FROM employees WHERE department_id = 500;

DELETE FROM departments WHERE department_id = 500;
COMMIT;

UPDATE employees SET department_id = NULL WHERE department_id = 500;
DELETE FROM departments WHERE department_id = 500;
COMMIT;

SELECT department_id, department_name FROM departments
WHERE department_id NOT IN (
SELECT DISTINCT department_id FROM employees
WHERE department_id IS NOT NULL
);

DELETE FROM departments
WHERE department_id NOT IN (
SELECT DISTINCT department_id FROM employees
WHERE department_id IS NOT NULL
);
COMMIT;

DELETE FROM departments d
WHERE NOT EXISTS (
SELECT 1 FROM employees e
WHERE e.department_id = d.department_id
);
COMMIT;

CREATE TABLE DMKHOA (
    MAKHOA CHAR(2) PRIMARY KEY,
    TENKHOA NVARCHAR2(30)
);
CREATE TABLE DMMH (
    MAMH CHAR(2) PRIMARY KEY,
    TENMH NVARCHAR2(35),
    SOTIET NUMBER(3)
);
CREATE TABLE DMSV (
    MASV CHAR(3) PRIMARY KEY,
    HOSV NVARCHAR2(30),
    TENSV NVARCHAR2(10),
    PHAI NVARCHAR2(3),
    NGAYSINH DATE,
    NOISINH NVARCHAR2(25),
    MAKH CHAR(2),
    HOCBONG NUMBER(10,0),
    FOREIGN KEY (MAKH) REFERENCES DMKHOA(MAKHOA)
);
CREATE TABLE KETQUA (
    MASV CHAR(3),
    MAMH CHAR(2),
    DIEM NUMBER(4,2),
    PRIMARY KEY (MASV, MAMH),
    FOREIGN KEY (MASV) REFERENCES DMSV(MASV),
    FOREIGN KEY (MAMH) REFERENCES DMMH(MAMH)
);

-- DMKHOA
INSERT INTO DMKHOA VALUES ('IT', N'Cong nghe thong tin');
INSERT INTO DMKHOA VALUES ('KT', N'Ke toan');
INSERT INTO DMKHOA VALUES ('QT', N'Quan tri');

-- DMMH
INSERT INTO DMMH VALUES ('01', N'Co so du lieu', 45);
INSERT INTO DMMH VALUES ('02', N'Lap trinh Java', 60);
INSERT INTO DMMH VALUES ('03', N'He dieu hanh', 45);
INSERT INTO DMMH VALUES ('04', N'Mang may tinh', 45);

-- DMSV
INSERT INTO DMSV VALUES ('S01', N'Nguyen', N'An', N'Nam', DATE '2002-01-01', N'Hanoi', 'IT', 1000000);
INSERT INTO DMSV VALUES ('S02', N'Tran', N'Binh', N'Nam', DATE '2002-02-02', N'HCM', 'IT', 500000);
INSERT INTO DMSV VALUES ('S03', N'Le', N'Chi', N'Nu', DATE '2002-03-03', N'Danang', 'KT', 0);
INSERT INTO DMSV VALUES ('S04', N'Pham', N'Dung', N'Nu', DATE '2002-04-04', N'Hue', 'QT', 200000);
INSERT INTO DMSV VALUES ('S05', N'Hoang', N'Em', N'Nam', DATE '2002-05-05', N'Hanoi', 'IT', 300000);
INSERT INTO DMSV VALUES ('S06', N'Vo', N'Gia', N'Nam', DATE '2002-06-06', N'HCM', 'KT', 0);

-- KETQUA
INSERT INTO KETQUA VALUES ('S01','01',8);
INSERT INTO KETQUA VALUES ('S01','02',7);
INSERT INTO KETQUA VALUES ('S02','01',9);
INSERT INTO KETQUA VALUES ('S02','03',6);
INSERT INTO KETQUA VALUES ('S03','02',5);
INSERT INTO KETQUA VALUES ('S03','04',7);
INSERT INTO KETQUA VALUES ('S04','01',6);
INSERT INTO KETQUA VALUES ('S04','02',8);
INSERT INTO KETQUA VALUES ('S05','03',7);
INSERT INTO KETQUA VALUES ('S06','04',6);

COMMIT;

CREATE TABLE PHONGBAN (
    MAPHG NUMBER PRIMARY KEY,
    TENPHG NVARCHAR2(30)
);
CREATE TABLE NHANVIEN (
    MANV NUMBER PRIMARY KEY,
    HONV NVARCHAR2(30),
    TENNV NVARCHAR2(10),
    LUONG NUMBER,
    MAPHG NUMBER,
    FOREIGN KEY (MAPHG) REFERENCES PHONGBAN(MAPHG)
);
CREATE TABLE DEAN (
    MADA NUMBER PRIMARY KEY,
    TENDA NVARCHAR2(30),
    MAPHG NUMBER,
    FOREIGN KEY (MAPHG) REFERENCES PHONGBAN(MAPHG)
);
CREATE TABLE PHANCONG (
    MANV NUMBER,
    MADA NUMBER,
    THOIGIAN NUMBER,
    PRIMARY KEY (MANV, MADA),
    FOREIGN KEY (MANV) REFERENCES NHANVIEN(MANV),
    FOREIGN KEY (MADA) REFERENCES DEAN(MADA)
);
CREATE TABLE THANNHAN (
    MANV NUMBER,
    TENTN NVARCHAR2(30),
    PRIMARY KEY (MANV, TENTN),
    FOREIGN KEY (MANV) REFERENCES NHANVIEN(MANV)
);
CREATE TABLE DIADIEM_PHG (
    MAPHG NUMBER,
    DIADIEM NVARCHAR2(30),
    PRIMARY KEY (MAPHG, DIADIEM),
    FOREIGN KEY (MAPHG) REFERENCES PHONGBAN(MAPHG)
);

-- PHONGBAN
INSERT INTO PHONGBAN VALUES (1, N'IT');
INSERT INTO PHONGBAN VALUES (2, N'HR');
INSERT INTO PHONGBAN VALUES (3, N'Finance');

-- NHANVIEN
INSERT INTO NHANVIEN VALUES (101, N'Nguyen', N'An', 10000, 1);
INSERT INTO NHANVIEN VALUES (102, N'Tran', N'Binh', 8000, 1);
INSERT INTO NHANVIEN VALUES (103, N'Le', N'Chi', 7000, 2);
INSERT INTO NHANVIEN VALUES (104, N'Pham', N'Dung', 9000, 3);
INSERT INTO NHANVIEN VALUES (105, N'Vo', N'Em', 6000, 2);

-- DEAN
INSERT INTO DEAN VALUES (201, N'Du an A', 1);
INSERT INTO DEAN VALUES (202, N'Du an B', 2);
INSERT INTO DEAN VALUES (203, N'Du an C', 3);

-- PHANCONG
INSERT INTO PHANCONG VALUES (101,201,10);
INSERT INTO PHANCONG VALUES (102,201,15);
INSERT INTO PHANCONG VALUES (103,202,20);
INSERT INTO PHANCONG VALUES (104,203,25);
INSERT INTO PHANCONG VALUES (105,202,10);

-- THANNHAN
INSERT INTO THANNHAN VALUES (101, N'Cha');
INSERT INTO THANNHAN VALUES (101, N'Me');
INSERT INTO THANNHAN VALUES (102, N'Vo');
INSERT INTO THANNHAN VALUES (103, N'Anh');
INSERT INTO THANNHAN VALUES (104, N'Chi');

-- DIADIEM_PHG
INSERT INTO DIADIEM_PHG VALUES (1, N'Hanoi');
INSERT INTO DIADIEM_PHG VALUES (1, N'HCM');
INSERT INTO DIADIEM_PHG VALUES (2, N'Danang');
INSERT INTO DIADIEM_PHG VALUES (3, N'Hue');
INSERT INTO DIADIEM_PHG VALUES (3, N'CanTho');

COMMIT;
