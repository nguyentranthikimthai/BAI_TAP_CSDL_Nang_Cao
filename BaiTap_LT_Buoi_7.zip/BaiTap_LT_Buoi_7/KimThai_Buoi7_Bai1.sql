SET SERVEROUTPUT ON;

----PHIẾU BÀI TẬP 1

CREATE TABLE KHOA (
  MaKhoa     VARCHAR2(10) PRIMARY KEY,
  TenKhoa    VARCHAR2(100) NOT NULL,
  DienThoai  VARCHAR2(20)
);

CREATE TABLE LOP (
  MaLop       VARCHAR2(10) PRIMARY KEY,
  TenLop      VARCHAR2(100) NOT NULL,
  Khoa        VARCHAR2(50),
  HeDT        VARCHAR2(50),
  NamNhapHoc  NUMBER(4),
  MaKhoa      VARCHAR2(10) NOT NULL,
  CONSTRAINT FK_LOP_KHOA FOREIGN KEY (MaKhoa) REFERENCES KHOA(MaKhoa)
);

-- BÀI TẬP 1
CREATE OR REPLACE PROCEDURE SP_Them_Khoa (
  p_makhoa    IN  VARCHAR2,
  p_tenkhoa   IN  VARCHAR2,
  p_dienthoai IN  VARCHAR2
)
AS
  v_dem NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem
  FROM KHOA
  WHERE MaKhoa = p_makhoa;

  IF v_dem > 0 THEN
    DBMS_OUTPUT.PUT_LINE('MaKhoa da ton tai: ' || p_makhoa);
  ELSE
    INSERT INTO KHOA(MaKhoa, TenKhoa, DienThoai)
    VALUES (p_makhoa, p_tenkhoa, p_dienthoai);

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Da them KHOA thanh cong: ' || p_makhoa);
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('Loi SP_Them_Khoa: ' || SQLERRM);
END;
/
-- TEST 2 TRƯỜNG HỢP
BEGIN
  SP_Them_Khoa('CNTT', 'Cong nghe thong tin', '0909000001'); -- thêm
  SP_Them_Khoa('CNTT', 'Cong nghe thong tin', '0909000001'); -- trùng
END;
/

-- BÀI TẬP 2
CREATE OR REPLACE PROCEDURE SP_Them_Lop (
  p_malop      IN VARCHAR2,
  p_tenlop     IN VARCHAR2,
  p_khoa       IN VARCHAR2,
  p_hedt       IN VARCHAR2,
  p_namnhaphoc IN NUMBER,
  p_makhoa     IN VARCHAR2
)
AS
  v_dem_tenlop NUMBER := 0;
  v_dem_makhoa NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem_tenlop
  FROM LOP
  WHERE UPPER(TenLop) = UPPER(p_tenlop);

  IF v_dem_tenlop > 0 THEN
    DBMS_OUTPUT.PUT_LINE('Ten lop da ton tai: ' || p_tenlop);
    RETURN;
  END IF;

  SELECT COUNT(*) INTO v_dem_makhoa
  FROM KHOA
  WHERE MaKhoa = p_makhoa;

  IF v_dem_makhoa = 0 THEN
    DBMS_OUTPUT.PUT_LINE('MaKhoa khong ton tai trong KHOA: ' || p_makhoa);
    RETURN;
  END IF;

  INSERT INTO LOP(MaLop, TenLop, Khoa, HeDT, NamNhapHoc, MaKhoa)
  VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Da them LOP thanh cong: ' || p_malop);
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('Loi SP_Them_Lop: ' || SQLERRM);
END;
/
-- TEST
BEGIN
  SP_Them_Lop('CTK42', 'Cao dang K42', 'K42', 'CD', 2024, 'CNTT');     -- OK
  SP_Them_Lop('CTK43', 'Cao dang K42', 'K43', 'CD', 2024, 'CNTT');     -- TenLop trùng
  SP_Them_Lop('CTK44', 'Lop moi',      'K44', 'CD', 2024, 'SAI_MK');   -- MaKhoa không có
END;
/
-- BÀI TẬP 3
CREATE OR REPLACE PROCEDURE SP_Them_Khoa_TraKQ (
  p_makhoa    IN  VARCHAR2,
  p_tenkhoa   IN  VARCHAR2,
  p_dienthoai IN  VARCHAR2,
  p_kq        OUT NUMBER
)
AS
  v_dem NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem
  FROM KHOA
  WHERE UPPER(TenKhoa) = UPPER(p_tenkhoa);

  IF v_dem > 0 THEN
    p_kq := 0;
    DBMS_OUTPUT.PUT_LINE('TenKhoa da ton tai -> tra 0: ' || p_tenkhoa);
  ELSE
    INSERT INTO KHOA(MaKhoa, TenKhoa, DienThoai)
    VALUES (p_makhoa, p_tenkhoa, p_dienthoai);

    COMMIT;
    p_kq := 1;
    DBMS_OUTPUT.PUT_LINE('Them moi TenKhoa -> tra 1: ' || p_tenkhoa);
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_kq := -1;
    DBMS_OUTPUT.PUT_LINE('Loi SP_Them_Khoa_TraKQ: ' || SQLERRM);
END;
/
-- TEST 2 TRƯỜNG HỢP
DECLARE
  v_kq NUMBER;
BEGIN
  SP_Them_Khoa_TraKQ('QTKD', 'Quan tri kinh doanh', '0909000002', v_kq);
  DBMS_OUTPUT.PUT_LINE('KQ = ' || v_kq);

  SP_Them_Khoa_TraKQ('QTKD2', 'Quan tri kinh doanh', '0909000003', v_kq);
  DBMS_OUTPUT.PUT_LINE('KQ = ' || v_kq);
END;
/

-- BÀI TẬP 4
CREATE OR REPLACE PROCEDURE SP_Them_Lop_TraMa (
  p_malop      IN  VARCHAR2,
  p_tenlop     IN  VARCHAR2,
  p_khoa       IN  VARCHAR2,
  p_hedt       IN  VARCHAR2,
  p_namnhaphoc IN  NUMBER,
  p_makhoa     IN  VARCHAR2,
  p_ma         OUT NUMBER
)
AS
  v_dem_tenlop NUMBER := 0;
  v_dem_makhoa NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem_tenlop
  FROM LOP
  WHERE UPPER(TenLop) = UPPER(p_tenlop);

  IF v_dem_tenlop > 0 THEN
    p_ma := 0;
    DBMS_OUTPUT.PUT_LINE('TenLop da co -> tra 0');
    RETURN;
  END IF;

  SELECT COUNT(*) INTO v_dem_makhoa
  FROM KHOA
  WHERE MaKhoa = p_makhoa;

  IF v_dem_makhoa = 0 THEN
    p_ma := 1;
    DBMS_OUTPUT.PUT_LINE('MaKhoa khong co -> tra 1');
    RETURN;
  END IF;

  INSERT INTO LOP(MaLop, TenLop, Khoa, HeDT, NamNhapHoc, MaKhoa)
  VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);

  COMMIT;
  p_ma := 2;
  DBMS_OUTPUT.PUT_LINE('Nhap thanh cong -> tra 2');
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_ma := -1;
    DBMS_OUTPUT.PUT_LINE('Loi SP_Them_Lop_TraMa: ' || SQLERRM);
END;
/
-- TEST
DECLARE
  v_ma NUMBER;
BEGIN
  SP_Them_Lop_TraMa('D1', 'Cao dang K42', 'K42', 'CD', 2024, 'CNTT', v_ma); -- TenLop trùng -> 0
  DBMS_OUTPUT.PUT_LINE('Ma tra ve = ' || v_ma);

  SP_Them_Lop_TraMa('D2', 'Lop ABC',     'K45', 'CD', 2024, 'SAI',  v_ma); -- MaKhoa sai -> 1
  DBMS_OUTPUT.PUT_LINE('Ma tra ve = ' || v_ma);

  SP_Them_Lop_TraMa('D3', 'Lop XYZ',     'K46', 'CD', 2024, 'CNTT', v_ma); -- OK -> 2
  DBMS_OUTPUT.PUT_LINE('Ma tra ve = ' || v_ma);
END;
/

---- PHIẾU BÀI TẬP 2

CREATE TABLE tblChucVu (
  MaCV  VARCHAR2(10) PRIMARY KEY,
  TenCV VARCHAR2(100) NOT NULL
);

CREATE TABLE tblNhanVien (
  MaNV        VARCHAR2(10) PRIMARY KEY,
  MaCV        VARCHAR2(10) NOT NULL,
  TenNV       VARCHAR2(100) NOT NULL,
  NgaySinh    DATE,
  LuongCanBan NUMBER(18,2),
  NgayCong    NUMBER(10,2),
  PhuCap      NUMBER(18,2),
  CONSTRAINT FK_NV_CV FOREIGN KEY (MaCV) REFERENCES tblChucVu(MaCV)
);

BEGIN
  INSERT INTO tblChucVu VALUES ('GD',  'Giam doc');
  INSERT INTO tblChucVu VALUES ('TP',  'Truong phong');
  INSERT INTO tblChucVu VALUES ('NV',  'Nhan vien');
  INSERT INTO tblChucVu VALUES ('KT',  'Ke toan');

  INSERT INTO tblNhanVien VALUES ('NV01','NV','Nguyen Van A', TO_DATE('1999-06-15','YYYY-MM-DD'), 5000000, 26, 500000);
  INSERT INTO tblNhanVien VALUES ('NV02','KT','Tran Thi B',    TO_DATE('2000-01-10','YYYY-MM-DD'), 6000000, 24, 700000);
  INSERT INTO tblNhanVien VALUES ('NV03','TP','Le Van C',      TO_DATE('1998-12-20','YYYY-MM-DD'), 9000000, 25, 1000000);
  COMMIT;
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    NULL; -- chạy lại script không bị lỗi trùng
END;
/
--D. Yêu cầu
--a. Thủ tục SP_Them_Nhan_Vien
CREATE OR REPLACE PROCEDURE SP_Them_Nhan_Vien (
  p_manv        IN VARCHAR2,
  p_macv        IN VARCHAR2,
  p_tennv       IN VARCHAR2,
  p_ngaysinh    IN DATE,
  p_luongcb     IN NUMBER,
  p_ngaycong    IN NUMBER,
  p_phucap      IN NUMBER
)
AS
  v_dem_cv NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem_cv
  FROM tblChucVu
  WHERE MaCV = p_macv;

  IF v_dem_cv = 0 THEN
    DBMS_OUTPUT.PUT_LINE('MaCV khong ton tai: ' || p_macv);
    RETURN;
  END IF;

  INSERT INTO tblNhanVien(MaNV, MaCV, TenNV, NgaySinh, LuongCanBan, NgayCong, PhuCap)
  VALUES (p_manv, p_macv, p_tennv, p_ngaysinh, p_luongcb, p_ngaycong, p_phucap);

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Da them nhan vien: ' || p_manv);
EXCEPTION
  WHEN DUP_VAL_ON_INDEX THEN
    DBMS_OUTPUT.PUT_LINE('MaNV bi trung: ' || p_manv);
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('Loi SP_Them_Nhan_Vien: ' || SQLERRM);
END;
/
-- TEST
BEGIN
  SP_Them_Nhan_Vien('NV04','NV','Pham D', TO_DATE('2001-02-02','YYYY-MM-DD'), 4500000, 26, 400000); -- OK
  SP_Them_Nhan_Vien('NV05','SAI','Pham E', TO_DATE('2001-02-02','YYYY-MM-DD'), 4500000, 26, 400000); -- MaCV sai
END;
/

--b. Thủ tục SP_CapNhat_Nhan_Vien
CREATE OR REPLACE PROCEDURE SP_CapNhat_Nhan_Vien (
  p_manv        IN VARCHAR2,
  p_macv        IN VARCHAR2,
  p_tennv       IN VARCHAR2,
  p_ngaysinh    IN DATE,
  p_luongcb     IN NUMBER,
  p_ngaycong    IN NUMBER,
  p_phucap      IN NUMBER
)
AS
  v_dem_cv NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem_cv
  FROM tblChucVu
  WHERE MaCV = p_macv;

  IF v_dem_cv = 0 THEN
    DBMS_OUTPUT.PUT_LINE('MaCV khong ton tai: ' || p_macv);
    RETURN;
  END IF;

  UPDATE tblNhanVien
  SET MaCV = p_macv,
      TenNV = p_tennv,
      NgaySinh = p_ngaysinh,
      LuongCanBan = p_luongcb,
      NgayCong = p_ngaycong,
      PhuCap = p_phucap
  WHERE MaNV = p_manv;

  IF SQL%ROWCOUNT = 0 THEN
    DBMS_OUTPUT.PUT_LINE('Khong tim thay MaNV: ' || p_manv);
    ROLLBACK;
  ELSE
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Da cap nhat nhan vien: ' || p_manv);
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('Loi SP_CapNhat_Nhan_Vien: ' || SQLERRM);
END;
/
-- TEST
BEGIN
  SP_CapNhat_Nhan_Vien('NV02','NV','Tran Thi B (Update)',
    TO_DATE('2000-01-10','YYYY-MM-DD'), 6500000, 25, 800000); -- OK
  SP_CapNhat_Nhan_Vien('NVXX','NV','Khong ton tai',
    TO_DATE('2000-01-10','YYYY-MM-DD'), 6500000, 25, 800000); -- MaNV không có
END;
/
--c. Thủ tục SP_LuongLN
CREATE OR REPLACE PROCEDURE SP_LuongLN
AS
  v_luong NUMBER(18,2);
BEGIN
  DBMS_OUTPUT.PUT_LINE('--- DANH SACH LUONG ---');
  FOR r IN (SELECT MaNV, TenNV, LuongCanBan, NgayCong, PhuCap FROM tblNhanVien ORDER BY MaNV) LOOP
    v_luong := NVL(r.LuongCanBan,0) * NVL(r.NgayCong,0) + NVL(r.PhuCap,0);
    DBMS_OUTPUT.PUT_LINE(
      r.MaNV || ' - ' || r.TenNV || ' | Luong = ' || TO_CHAR(v_luong)
    );
  END LOOP;
END;
/
-- TEST
BEGIN
  SP_LuongLN;
END;
/

----PHIẾU BÀI TẬP 3
--D. Yêu cầu
--1. Thủ tục sp_them_nhan_vien1 (có tham số OUT)
CREATE OR REPLACE PROCEDURE sp_them_nhan_vien1 (
  p_manv        IN  VARCHAR2,
  p_macv        IN  VARCHAR2,
  p_tennv       IN  VARCHAR2,
  p_ngaysinh    IN  DATE,
  p_luongcb     IN  NUMBER,
  p_ngaycong    IN  NUMBER,
  p_phucap      IN  NUMBER,
  p_kq          OUT NUMBER
)
AS
  v_dem_nv NUMBER := 0;
  v_dem_cv NUMBER := 0;
BEGIN
  -- MaNV trùng?
  SELECT COUNT(*) INTO v_dem_nv
  FROM tblNhanVien
  WHERE MaNV = p_manv;

  IF v_dem_nv > 0 THEN
    p_kq := 0; -- MaNV đã tồn tại
    DBMS_OUTPUT.PUT_LINE('MaNV da ton tai -> tra 0');
    RETURN;
  END IF;

--2. Sửa thủ tục – kiểm tra thêm MaNV trùng lặp
  SELECT COUNT(*) INTO v_dem_cv
  FROM tblChucVu
  WHERE MaCV = p_macv;

  IF v_dem_cv = 0 THEN
    p_kq := 1; -- MaCV chưa tồn tại
    DBMS_OUTPUT.PUT_LINE('MaCV chua ton tai -> tra 1');
    RETURN;
  END IF;

  -- OK: chèn
  INSERT INTO tblNhanVien(MaNV, MaCV, TenNV, NgaySinh, LuongCanBan, NgayCong, PhuCap)
  VALUES (p_manv, p_macv, p_tennv, p_ngaysinh, p_luongcb, p_ngaycong, p_phucap);

  COMMIT;
  p_kq := 2;
  DBMS_OUTPUT.PUT_LINE('Chen thanh cong -> tra 2');
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_kq := -1;
    DBMS_OUTPUT.PUT_LINE('Loi sp_them_nhan_vien1: ' || SQLERRM);
END;
/
-- TEST 3 TRƯỜNG HỢP (0/1/2)
DECLARE
  v_kq NUMBER;
BEGIN
  sp_them_nhan_vien1('NV01','NV','Trung MaNV', TO_DATE('2001-01-01','YYYY-MM-DD'), 1, 1, 1, v_kq);
  DBMS_OUTPUT.PUT_LINE('KQ='||v_kq);

  sp_them_nhan_vien1('NV99','SAI','Sai MaCV', TO_DATE('2001-01-01','YYYY-MM-DD'), 1, 1, 1, v_kq);
  DBMS_OUTPUT.PUT_LINE('KQ='||v_kq);

  sp_them_nhan_vien1('NV98','NV','Hop le',    TO_DATE('2001-01-01','YYYY-MM-DD'), 1000, 20, 50, v_kq);
  DBMS_OUTPUT.PUT_LINE('KQ='||v_kq);
END;
/

--3. Thủ tục cập nhật NgaySinh cho nhân viên
CREATE OR REPLACE PROCEDURE sp_capnhat_ngaysinh (
  p_manv     IN  VARCHAR2,
  p_ngaysinh IN  DATE,
  p_kq       OUT NUMBER
)
AS
BEGIN
  UPDATE tblNhanVien
  SET NgaySinh = p_ngaysinh
  WHERE MaNV = p_manv;

  IF SQL%ROWCOUNT = 0 THEN
    p_kq := 0;
    DBMS_OUTPUT.PUT_LINE('Khong tim thay MaNV -> tra 0');
    ROLLBACK;
  ELSE
    p_kq := 1;
    DBMS_OUTPUT.PUT_LINE('Cap nhat thanh cong -> tra 1');
    COMMIT;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_kq := -1;
    DBMS_OUTPUT.PUT_LINE('Loi sp_capnhat_ngaysinh: ' || SQLERRM);
END;
/
-- TEST
DECLARE
  v_kq NUMBER;
BEGIN
  sp_capnhat_ngaysinh('NVXX', TO_DATE('1990-01-01','YYYY-MM-DD'), v_kq);
  DBMS_OUTPUT.PUT_LINE('KQ='||v_kq);

  sp_capnhat_ngaysinh('NV02', TO_DATE('1995-05-05','YYYY-MM-DD'), v_kq);
  DBMS_OUTPUT.PUT_LINE('KQ='||v_kq);
END;
/