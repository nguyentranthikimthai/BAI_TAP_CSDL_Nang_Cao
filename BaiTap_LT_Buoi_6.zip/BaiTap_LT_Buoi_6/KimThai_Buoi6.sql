BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE TaiKhoanVay PURGE';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE TaiKhoanGoi PURGE';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE ChiNhanh PURGE';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE KhachHang PURGE';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE NganHang PURGE';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

CREATE TABLE NganHang (
  MaNH NUMBER(2) PRIMARY KEY,
  TenNH VARCHAR2(100) NOT NULL
);

CREATE TABLE KhachHang (
  MaKH VARCHAR2(20) PRIMARY KEY,
  TenKH VARCHAR2(100) NOT NULL,
  DiaChi VARCHAR2(200)
);

CREATE TABLE ChiNhanh (
  MaCN VARCHAR2(10) PRIMARY KEY,
  MaNH NUMBER(2) NOT NULL,
  ThanhPhoCN VARCHAR2(50) NOT NULL,
  TaiSan NUMBER(15) NOT NULL,
  CONSTRAINT fk_ChiNhanh_NganHang 
    FOREIGN KEY (MaNH) REFERENCES NganHang(MaNH)
);

CREATE TABLE TaiKhoanGoi (
  SoTKG VARCHAR2(10) PRIMARY KEY,
  MaKH VARCHAR2(20) NOT NULL,
  MaCN VARCHAR2(10) NOT NULL,
  SoTienGoi NUMBER(15) NOT NULL,
  CONSTRAINT fk_TKG_KhachHang FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
  CONSTRAINT fk_TKG_ChiNhanh FOREIGN KEY (MaCN) REFERENCES ChiNhanh(MaCN)
);

CREATE TABLE TaiKhoanVay (
  SoTKV VARCHAR2(10) PRIMARY KEY,
  MaKH VARCHAR2(20) NOT NULL,
  MaCN VARCHAR2(10) NOT NULL,
  SoTienVay NUMBER(15) NOT NULL,
  CONSTRAINT fk_TKV_KhachHang FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH),
  CONSTRAINT fk_TKV_ChiNhanh FOREIGN KEY (MaCN) REFERENCES ChiNhanh(MaCN)
);


INSERT INTO NganHang VALUES (1, 'Ngan Hang Cong Thuong');
INSERT INTO NganHang VALUES (2, 'Ngan Hang Ngoai Thuong');
INSERT INTO NganHang VALUES (3, 'Ngan Hang Nong Nghiep');
INSERT INTO NganHang VALUES (4, 'Ngan Hang A Chau');
INSERT INTO NganHang VALUES (5, 'Ngan Hang Thuong Tin');

INSERT INTO ChiNhanh VALUES ('CN01', 1, 'Da Lat', 2000000000);
INSERT INTO ChiNhanh VALUES ('CN02', 2, 'Nha Trang', 2700000000);
INSERT INTO ChiNhanh VALUES ('CN03', 3, 'Thanh Hoa', 4500000000);
INSERT INTO ChiNhanh VALUES ('CN04', 4, 'TP HCM', 6000000000);
INSERT INTO ChiNhanh VALUES ('CN05', 5, 'Da Nang', 7000000000);
INSERT INTO ChiNhanh VALUES ('CN11', 1, 'TP HCM', 5000000000);
INSERT INTO ChiNhanh VALUES ('CN12', 2, 'Hue', 1400000000);
INSERT INTO ChiNhanh VALUES ('CN13', 3, 'Da Nang', 3600000000);
INSERT INTO ChiNhanh VALUES ('CN14', 4, 'Ha Noi', 5700000000);
INSERT INTO ChiNhanh VALUES ('CN21', 1, 'Ha Noi', 3500000000);
INSERT INTO ChiNhanh VALUES ('CN22', 2, 'Ha Noi', 4500000000);
INSERT INTO ChiNhanh VALUES ('CN23', 3, 'Da Lat', 2400000000);
INSERT INTO ChiNhanh VALUES ('CN31', 1, 'Da Nang', 4000000000);
INSERT INTO ChiNhanh VALUES ('CN32', 2, 'TP HCM', 5600000000);
INSERT INTO ChiNhanh VALUES ('CN33', 3, 'Can Tho', 5400000000);
INSERT INTO ChiNhanh VALUES ('CN43', 3, 'Nam Dinh', 3600000000);

INSERT INTO KhachHang VALUES ('111222333', 'Ho Thi Thanh Thao', '456 Le Duan, Ha Noi');
INSERT INTO KhachHang VALUES ('112233445', 'Tran Van Tien', '12 Dien Bien Phu, Q1, TP HCM');
INSERT INTO KhachHang VALUES ('123123123', 'Phan Thi Quynh Nhu', '54 Hai Ba Trung, Ha Noi');
INSERT INTO KhachHang VALUES ('123412341', 'Nguyen Van Thao', '34 Tran Phu, TP Nha Trang');
INSERT INTO KhachHang VALUES ('123456789', 'Nguyen Thi Hoa', '1/4 Hoang Van Thu, Da Lat');
INSERT INTO KhachHang VALUES ('221133445', 'Nguyen Thi Kim Mai', '4 Tran Binh Trong, Da Lat');
INSERT INTO KhachHang VALUES ('222111333', 'Do Tien Dong', '123 Tran Phu, Nam Dinh');
INSERT INTO KhachHang VALUES ('331122445', 'Bui Thi Dong', '345 Tran Hung Dao, Thanh Hoa');
INSERT INTO KhachHang VALUES ('333111222', 'Tran Dinh Hung', '783 Ly Thuong Kiet, Can Tho');
INSERT INTO KhachHang VALUES ('441122335', 'Nguyen dinh Cuong', 'P12 Thanh Xuan Nam, Q Thanh Xuan');
INSERT INTO KhachHang VALUES ('456456456', 'Tran Nam Son', '5 Le Duan, TP Da Nang');
INSERT INTO KhachHang VALUES ('551122334', 'Tran Thi Khanh Van', '1A Ho Tung Mau, Da Lat');
INSERT INTO KhachHang VALUES ('987654321', 'Ho Thanh Son', '209 Tran Hung Dao, Q5, TP HCM');

INSERT INTO TaiKhoanGoi VALUES ('00001A', '123123123', 'CN01', 10000000);
INSERT INTO TaiKhoanGoi VALUES ('00001C', '123456789', 'CN01', 127000000);
INSERT INTO TaiKhoanGoi VALUES ('00002A', '221133445', 'CN02', 12500000);
INSERT INTO TaiKhoanGoi VALUES ('00003H', '456456456', 'CN03', 123000000);
INSERT INTO TaiKhoanGoi VALUES ('00005A', '222111333', 'CN05', 1200000);
INSERT INTO TaiKhoanGoi VALUES ('00005D', '987654321', 'CN05', 345000000);
INSERT INTO TaiKhoanGoi VALUES ('00005N', '123412341', 'CN05', 45000000);
INSERT INTO TaiKhoanGoi VALUES ('00003A', '331122445', 'CN13', 27000000);
INSERT INTO TaiKhoanGoi VALUES ('00004D', '551122334', 'CN14', 560000000);
INSERT INTO TaiKhoanGoi VALUES ('00004P', '123456789', 'CN14', 35400000);
INSERT INTO TaiKhoanGoi VALUES ('00001B', '123412341', 'CN21', 67000000);
INSERT INTO TaiKhoanGoi VALUES ('00002G', '222111333', 'CN22', 56000000);
INSERT INTO TaiKhoanGoi VALUES ('00004F', '987654321', 'CN23', 4500000);
INSERT INTO TaiKhoanGoi VALUES ('00003D', '333111222', 'CN33', 47000000);

INSERT INTO TaiKhoanVay VALUES ('10001A', '111222333', 'CN01', 10000000);
INSERT INTO TaiKhoanVay VALUES ('10002A', '333111222', 'CN02', 6000000);
INSERT INTO TaiKhoanVay VALUES ('10004A', '551122334', 'CN04', 20000000);
INSERT INTO TaiKhoanVay VALUES ('10005G', '221133445', 'CN05', 15000000);
INSERT INTO TaiKhoanVay VALUES ('10001D', '987654321', 'CN11', 45000000);
INSERT INTO TaiKhoanVay VALUES ('10002D', '112233445', 'CN12', 12000000);
INSERT INTO TaiKhoanVay VALUES ('10003F', '441122335', 'CN13', 5500000);
INSERT INTO TaiKhoanVay VALUES ('10005A', '123123123', 'CN14', 12500000);

COMMIT;


-- 1. Tìm tên tất cả các ngân hàng có chi nhánh ngân hàng ở thành phố "Da Lat".
SELECT DISTINCT nh.TenNH
FROM NganHang nh
JOIN ChiNhanh cn ON cn.MaNH = nh.MaNH
WHERE cn.ThanhPhoCN = 'Da Lat';

-- 2. Tìm tất cả những thành phố mà có chi nhánh của ngân hàng công thương.
SELECT DISTINCT cn.ThanhPhoCN
FROM NganHang nh
JOIN ChiNhanh cn ON cn.MaNH = nh.MaNH
WHERE nh.TenNH = 'Ngan Hang Cong Thuong';

-- 3. Tìm thông tin về tất cả các chi nhánh của ngân hàng công thương có địa điểm ở "TP HCM".
SELECT cn.MaCN, cn.MaNH, cn.ThanhPhoCN, cn.TaiSan
FROM NganHang nh
JOIN ChiNhanh cn ON cn.MaNH = nh.MaNH
WHERE nh.TenNH = 'Ngan Hang Cong Thuong'
  AND cn.ThanhPhoCN = 'TP HCM';

-- 4. Xuất thông tin từng ngân hàng và chi nhánh của nó.
SELECT nh.MaNH, nh.TenNH, cn.MaCN, cn.ThanhPhoCN, cn.TaiSan
FROM NganHang nh
LEFT JOIN ChiNhanh cn ON cn.MaNH = nh.MaNH
ORDER BY nh.MaNH, cn.MaCN;

-- 5. Tìm khách hàng mà địa chỉ của họ ở 'Ha Noi'.
SELECT MaKH, TenKH, DiaChi
FROM KhachHang
WHERE DiaChi LIKE '%Ha Noi%';

-- 6. Tìm các khách hàng có tên Son.
SELECT MaKH, TenKH, DiaChi
FROM KhachHang
WHERE TenKH LIKE '%Son%';

-- 7. Tìm các khách hàng mà địa chỉ của họ ở đường "Tran Hung Dao".
SELECT MaKH, TenKH, DiaChi
FROM KhachHang
WHERE DiaChi LIKE '%Tran Hung Dao%';

-- 8. Tìm các khách hàng có tên "Thao".
SELECT MaKH, TenKH, DiaChi
FROM KhachHang
WHERE TenKH LIKE '%Thao%';

-- 9. Tìm khách hàng có mã số bắt đầu là '11' và ở 'TP HCM'.
SELECT MaKH, TenKH, DiaChi
FROM KhachHang
WHERE MaKH LIKE '11%'
  AND DiaChi LIKE '%TP HCM%';

-- 10. Xuất thông tin về tên ngân hàng, thành phố chi nhánh và tài sản tăng dần.
SELECT nh.TenNH, cn.ThanhPhoCN, cn.TaiSan
FROM NganHang nh
JOIN ChiNhanh cn ON cn.MaNH = nh.MaNH
ORDER BY cn.TaiSan ASC, cn.ThanhPhoCN ASC;

-- 11. Tìm thông tin chi nhánh có tài sản từ 3 tỷ đến 5 tỷ.
SELECT nh.MaNH, nh.TenNH, cn.MaCN, cn.ThanhPhoCN, cn.TaiSan
FROM NganHang nh
JOIN ChiNhanh cn ON cn.MaNH = nh.MaNH
WHERE cn.TaiSan > 3000000000
  AND cn.TaiSan < 5000000000;

-- 12. Cho biết tài sản trung bình chi nhánh của từng ngân hàng.
SELECT nh.MaNH, nh.TenNH, AVG(cn.TaiSan) AS TaiSan_TrungBinh
FROM NganHang nh
JOIN ChiNhanh cn ON cn.MaNH = nh.MaNH
GROUP BY nh.MaNH, nh.TenNH
ORDER BY nh.MaNH;

-- 13. Tìm khách hàng vay tại ngân hàng công thương và có tên là 'Thao'.
SELECT DISTINCT kh.MaKH, kh.TenKH, kh.DiaChi
FROM KhachHang kh
JOIN TaiKhoanVay tkv ON tkv.MaKH = kh.MaKH
JOIN ChiNhanh cn ON cn.MaCN = tkv.MaCN
JOIN NganHang nh ON nh.MaNH = cn.MaNH
WHERE nh.TenNH = 'Ngan Hang Cong Thuong'
  AND kh.TenKH LIKE '%Thao%';

-- 14. Xuất thông tin về tên ngân hàng và tổng tài sản của các ngân hàng.
SELECT nh.MaNH, nh.TenNH, SUM(cn.TaiSan) AS Tong_TaiSan
FROM NganHang nh
JOIN ChiNhanh cn ON cn.MaNH = nh.MaNH
GROUP BY nh.MaNH, nh.TenNH
ORDER BY nh.MaNH;

-- 15. Tìm MaCN và TaiSan của chi nhánh có tài sản lớn nhất.
SELECT MaCN, TaiSan
FROM ChiNhanh
WHERE TaiSan = (SELECT MAX(TaiSan) FROM ChiNhanh);

-- 16. Liệt kê tất cả những khách hàng có tài khoản gởi tại chi nhánh ngân hàng "A Chau".
SELECT DISTINCT kh.MaKH, kh.TenKH, kh.DiaChi
FROM KhachHang kh
JOIN TaiKhoanGoi tkg ON tkg.MaKH = kh.MaKH
JOIN ChiNhanh cn ON cn.MaCN = tkg.MaCN
JOIN NganHang nh ON nh.MaNH = cn.MaNH
WHERE nh.TenNH = 'Ngan Hang A Chau';

-- 17. Tìm tất cả các số tài khoản vay tại ngân hàng ngoại thương có số tiền vay > 1.200.000.
SELECT tkv.SoTKV
FROM TaiKhoanVay tkv
JOIN ChiNhanh cn ON cn.MaCN = tkv.MaCN
JOIN NganHang nh ON nh.MaNH = cn.MaNH
WHERE nh.TenNH = 'Ngan Hang Ngoai Thuong'
  AND tkv.SoTienVay > 1200000;

-- 18. Tính tổng số tiền mà mỗi chi nhánh ngân hàng đang được khách hàng gởi.
SELECT cn.MaCN, cn.ThanhPhoCN, SUM(tkg.SoTienGoi) AS Tong_Tien_Goi
FROM ChiNhanh cn
JOIN TaiKhoanGoi tkg ON tkg.MaCN = cn.MaCN
GROUP BY cn.MaCN, cn.ThanhPhoCN
ORDER BY cn.MaCN;

-- 19. Xuất thông tin về tài khoản vay và tài khoản gởi hiện có của tất cả khách hàng tên 'Son'.
SELECT kh.MaKH, kh.TenKH,
       tkv.SoTKV, tkv.SoTienVay,
       tkg.SoTKG, tkg.SoTienGoi
FROM KhachHang kh
LEFT JOIN TaiKhoanVay tkv ON tkv.MaKH = kh.MaKH
LEFT JOIN TaiKhoanGoi tkg ON tkg.MaKH = kh.MaKH
WHERE kh.TenKH LIKE '%Son%'
ORDER BY kh.MaKH, tkv.SoTKV, tkg.SoTKG;

-- 20. Tìm thông tin về khách hàng có tổng số tiền vay tại tất cả các ngân hàng > 30.000.000.
SELECT kh.MaKH, kh.TenKH, SUM(tkv.SoTienVay) AS Tong_Tien_Vay
FROM KhachHang kh
JOIN TaiKhoanVay tkv ON tkv.MaKH = kh.MaKH
GROUP BY kh.MaKH, kh.TenKH
HAVING SUM(tkv.SoTienVay) > 30000000
ORDER BY Tong_Tien_Vay DESC;