SQL> SET SERVEROUTPUT ON;
SQL> CREATE TABLE course (
  2      courseno NUMBER PRIMARY KEY,
  3      description VARCHAR2(50),
  4      cost NUMBER,
  5      prerequisite NUMBER,
  6      createdby VARCHAR2(30),
  7      createddate DATE,
  8      modifiedby VARCHAR2(30),
  9      modifieddate DATE
 10  );

Table created.

SQL> 
SQL> CREATE TABLE instructor (
  2      instructorid NUMBER PRIMARY KEY,
  3      firstname VARCHAR2(25),
  4      lastname VARCHAR2(25),
  5      createdby VARCHAR2(30),
  6      createddate DATE,
  7      modifiedby VARCHAR2(30),
  8      modifieddate DATE
  9  );

Table created.

SQL> 
SQL> CREATE TABLE class (
  2      classid NUMBER PRIMARY KEY,
  3      courseno NUMBER,
  4      classno NUMBER,
  5      instructorid NUMBER,
  6      createdby VARCHAR2(30),
  7      createddate DATE,
  8      modifiedby VARCHAR2(30),
  9      modifieddate DATE
 10  );

Table created.

SQL> 
SQL> CREATE TABLE student (
  2      studentid NUMBER PRIMARY KEY,
  3      firstname VARCHAR2(25),
  4      lastname VARCHAR2(25),
  5      address VARCHAR2(50),
  6      registrationdate DATE,
  7      createdby VARCHAR2(30),
  8      createddate DATE,
  9      modifiedby VARCHAR2(30),
 10      modifieddate DATE
 11  );

Table created.

SQL> 
SQL> CREATE TABLE enrollment (
  2      studentid NUMBER,
  3      classid NUMBER,
  4      enrolldate DATE,
  5      finalgrade NUMBER,
  6      createdby VARCHAR2(30),
  7      createddate DATE,
  8      modifiedby VARCHAR2(30),
  9      modifieddate DATE
 10  );

Table created.

SQL> DROP TABLE course;

Table dropped.

SQL> DROP TABLE student;

Table dropped.

SQL> DROP TABLE enrollment;

Table dropped.

SQL> DROP TABLE instructor;

Table dropped.

SQL> DROP TABLE grade;
DROP TABLE grade
           *
ERROR at line 1:
ORA-00942: table or view does not exist 


SQL> CREATE TABLE course (
  2      courseno NUMBER(8,0) PRIMARY KEY,
  3      description VARCHAR2(50),
  4      cost NUMBER(9,2),
  5      prerequisite NUMBER(8,0),
  6      createdby VARCHAR2(30) NOT NULL,
  7      createddate DATE NOT NULL,
  8      modifiedby VARCHAR2(30) NOT NULL,
  9      modifieddate DATE NOT NULL
 10  );

Table created.

SQL> CREATE TABLE class (
  2      classid NUMBER(8,0) PRIMARY KEY,
  3      courseno NUMBER(8,0) NOT NULL,
  4      classno NUMBER(3) NOT NULL,
  5      startdatetime DATE,
  6      location VARCHAR2(50),
  7      instructorid NUMBER(8,0) NOT NULL,
  8      capacity NUMBER(3),
  9      createdby VARCHAR2(30) NOT NULL,
 10      createddate DATE NOT NULL,
 11      modifiedby VARCHAR2(30) NOT NULL,
 12      modifieddate DATE NOT NULL
 13  );
CREATE TABLE class (
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> CREATE TABLE student (
  2      studentid NUMBER(8,0) PRIMARY KEY,
  3      salutation VARCHAR2(5),
  4      firstname VARCHAR2(25),
  5      lastname VARCHAR2(25) NOT NULL,
  6      address VARCHAR2(50),
  7      phone VARCHAR2(15),
  8      employer VARCHAR2(50),
  9      registrationdate DATE NOT NULL,
 10      createdby VARCHAR2(30) NOT NULL,
 11      createddate DATE NOT NULL,
 12      modifiedby VARCHAR2(30) NOT NULL,
 13      modifieddate DATE NOT NULL
 14  );

Table created.

SQL> CREATE TABLE enrollment (
  2      studentid NUMBER(8,0) NOT NULL,
  3      classid NUMBER(8,0) NOT NULL,
  4      enrolldate DATE NOT NULL,
  5      finalgrade NUMBER(3),
  6      registrationdate DATE NOT NULL,
  7      createdby VARCHAR2(30) NOT NULL,
  8      createddate DATE NOT NULL,
  9      modifiedby VARCHAR2(30) NOT NULL,
 10      modifieddate DATE NOT NULL
 11  );

Table created.

SQL> CREATE TABLE instructor (
  2      instructorid NUMBER(8,0) PRIMARY KEY,
  3      salutation VARCHAR2(5),
  4      firstname VARCHAR2(25),
  5      lastname VARCHAR2(25),
  6      address VARCHAR2(50),
  7      phone VARCHAR2(15),
  8      createdby VARCHAR2(30) NOT NULL,
  9      createddate DATE NOT NULL,
 10      modifiedby VARCHAR2(30) NOT NULL,
 11      modifieddate DATE NOT NULL
 12  );

Table created.

SQL> CREATE TABLE grade (
  2      studentid NUMBER(8,0) NOT NULL,
  3      classid NUMBER(8,0) NOT NULL,
  4      grade NUMBER(3) NOT NULL,
  5      comments VARCHAR2(2000),
  6      createdby VARCHAR2(30) NOT NULL,
  7      createddate DATE NOT NULL,
  8      modifiedby VARCHAR2(30) NOT NULL,
  9      modifieddate DATE NOT NULL
 10  );

Table created.

SQL> DROP TABLE class;

Table dropped.

SQL> CREATE TABLE class (
  2      classid NUMBER(8,0) PRIMARY KEY,
  3      courseno NUMBER(8,0) NOT NULL,
  4      classno NUMBER(3) NOT NULL,
  5      startdatetime DATE,
  6      location VARCHAR2(50),
  7      instructorid NUMBER(8,0) NOT NULL,
  8      capacity NUMBER(3),
  9      createdby VARCHAR2(30) NOT NULL,
 10      createddate DATE NOT NULL,
 11      modifiedby VARCHAR2(30) NOT NULL,
 12      modifieddate DATE NOT NULL
 13  );

Table created.

SQL> INSERT INTO instructor VALUES (1,NULL,'An','Nguyen','HCM','0901',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (2,NULL,'Binh','Tran','HCM','0902',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (3,NULL,'Cuong','Le','HCM','0903',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (4,NULL,'Dung','Pham','HCM','0904',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (5,NULL,'Hieu','Hoang','HCM','0905',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (6,NULL,'Khanh','Vo','HCM','0906',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (7,NULL,'Linh','Dang','HCM','0907',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (8,NULL,'Minh','Bui','HCM','0908',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (9,NULL,'Nam','Do','HCM','0909',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (10,NULL,'Phong','Ngo','HCM','0910',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (11,NULL,'Quang','Ly','HCM','0911',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (12,NULL,'Son','Vu','HCM','0912',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (13,NULL,'Tuan','Phan','HCM','0913',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (14,NULL,'Viet','Huynh','HCM','0914',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (15,NULL,'Anh','Nguyen','HCM','0915',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (16,NULL,'Bao','Tran','HCM','0916',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (17,NULL,'Chau','Le','HCM','0917',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (18,NULL,'Duc','Pham','HCM','0918',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (19,NULL,'Giang','Hoang','HCM','0919',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO instructor VALUES (20,NULL,'Hung','Vo','HCM','0920',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (1,'Co so du lieu',100,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (2,'He quan tri CSDL',150,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (3,'Java',200,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (4,'Python',180,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (5,'C++',170,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (6,'Web',160,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (7,'HTML',120,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (8,'CSS',130,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (9,'JS',140,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (10,'React',220,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (11,'Angular',210,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (12,'Vue',205,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (13,'PHP',160,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (14,'Laravel',170,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (15,'Spring',250,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (16,'AI',300,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (17,'ML',320,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (18,'DL',350,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (19,'Data',280,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO course VALUES (20,'BigData',400,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (1,1,1,SYSDATE,'P101',1,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (2,2,1,SYSDATE,'P102',2,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (3,3,1,SYSDATE,'P103',3,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (4,4,1,SYSDATE,'P104',4,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (5,5,1,SYSDATE,'P105',5,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (6,6,1,SYSDATE,'P106',6,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (7,7,1,SYSDATE,'P107',7,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (8,8,1,SYSDATE,'P108',8,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (9,9,1,SYSDATE,'P109',9,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (10,10,1,SYSDATE,'P110',10,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (11,11,1,SYSDATE,'P111',1,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (12,12,1,SYSDATE,'P112',2,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (13,13,1,SYSDATE,'P113',3,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (14,14,1,SYSDATE,'P114',4,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (15,15,1,SYSDATE,'P115',5,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (16,16,1,SYSDATE,'P116',6,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (17,17,1,SYSDATE,'P117',7,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (18,18,1,SYSDATE,'P118',8,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (19,19,1,SYSDATE,'P119',9,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO class VALUES (20,20,1,SYSDATE,'P120',10,30,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (101,NULL,'An','Nguyen','HCM','0901','CTY A',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (102,NULL,'Binh','Tran','HCM','0902','CTY B',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (103,NULL,'Cuong','Le','HCM','0903','CTY C',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (104,NULL,'Dung','Pham','HCM','0904','CTY D',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (105,NULL,'Hieu','Hoang','HCM','0905','CTY E',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (106,NULL,'Khanh','Vo','HCM','0906','CTY F',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (107,NULL,'Linh','Dang','HCM','0907','CTY G',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (108,NULL,'Minh','Bui','HCM','0908','CTY H',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (109,NULL,'Nam','Do','HCM','0909','CTY I',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (110,NULL,'Phong','Ngo','HCM','0910','CTY K',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (111,NULL,'Quang','Ly','HCM','0911','CTY L',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (112,NULL,'Son','Vu','HCM','0912','CTY M',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (113,NULL,'Tuan','Phan','HCM','0913','CTY N',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (114,NULL,'Viet','Huynh','HCM','0914','CTY O',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (115,NULL,'Anh','Nguyen','HCM','0915','CTY P',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (116,NULL,'Bao','Tran','HCM','0916','CTY Q',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (117,NULL,'Chau','Le','HCM','0917','CTY R',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (118,NULL,'Duc','Pham','HCM','0918','CTY S',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (119,NULL,'Giang','Hoang','HCM','0919','CTY T',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO student VALUES (120,NULL,'Hung','Vo','HCM','0920','CTY U',SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (101,1,SYSDATE,90,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (101,2,SYSDATE,80,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (101,3,SYSDATE,70,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (102,1,SYSDATE,60,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (103,2,SYSDATE,50,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (104,3,SYSDATE,85,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (105,4,SYSDATE,75,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (106,5,SYSDATE,65,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (107,6,SYSDATE,95,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (108,7,SYSDATE,88,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (109,8,SYSDATE,77,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (110,9,SYSDATE,66,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (111,10,SYSDATE,91,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (112,11,SYSDATE,82,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (113,12,SYSDATE,73,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (114,13,SYSDATE,64,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (115,14,SYSDATE,55,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (116,15,SYSDATE,89,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (117,16,SYSDATE,78,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (118,17,SYSDATE,68,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (119,18,SYSDATE,92,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO enrollment VALUES (120,19,SYSDATE,85,SYSDATE,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (101,1,90,'Tot',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (102,2,80,'Kha',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (103,3,70,'TB',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (104,4,85,'Tot',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (105,5,75,'Kha',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (106,6,65,'TB',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (107,7,95,'XS',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (108,8,88,'Tot',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (109,9,77,'Kha',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> INSERT INTO grade VALUES (110,10,66,'TB',USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> SHOW USER;
USER is "NGUYENTHAI"
SQL> SET SERVEROUTPUT ON;
SQL> DECLARE
  2      v_ten VARCHAR2(25) := 'Oracle';
  3  BEGIN
  4      DBMS_OUTPUT.PUT_LINE('Xin chao: ' || v_ten);
  5  EXCEPTION
  6      WHEN OTHERS THEN
  7          DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
  8  END;
  9  /
Xin chao: Oracle                                                                

PL/SQL procedure successfully completed.

SQL> DECLARE
  2      v_name student.firstname%TYPE;
  3      v_row student%ROWTYPE;
  4  BEGIN
  5      v_name := 'Thai';
  6      SELECT * INTO v_row FROM student WHERE studentid = 101;
  7      DBMS_OUTPUT.PUT_LINE('Ten: ' || v_name);
  8      DBMS_OUTPUT.PUT_LINE('SV: ' || v_row.firstname || ' ' || v_row.lastname);
  9  END;
 10  /
Ten: Thai                                                                       
SV: An Nguyen                                                                   

PL/SQL procedure successfully completed.

SQL> DECLARE
  2      v_id NUMBER := &ma_sv;
  3      v_name VARCHAR2(50);
  4  BEGIN
  5      SELECT firstname || ' ' || lastname
  6      INTO v_name
  7      FROM student
  8      WHERE studentid = v_id;
  9      DBMS_OUTPUT.PUT_LINE('Sinh vien: ' || v_name);
 10  END;
 11  /
Enter value for ma_sv: 103
old   2:     v_id NUMBER := &ma_sv;
new   2:     v_id NUMBER := 103;
Sinh vien: Cuong Le                                                             

PL/SQL procedure successfully completed.

SQL> DECLARE
  2      v_diem NUMBER := 85;
  3      v_grade VARCHAR2(2);
  4  BEGIN
  5      CASE
  6          WHEN v_diem >= 90 THEN v_grade := 'A';
  7          WHEN v_diem >= 80 THEN v_grade := 'B';
  8          ELSE v_grade := 'C';
  9      END CASE;
 10      DBMS_OUTPUT.PUT_LINE('Diem chu: ' || v_grade);
 11  END;
 12  /
Diem chu: B                                                                     

PL/SQL procedure successfully completed.

SQL> BEGIN
  2      INSERT INTO student VALUES (999,NULL,'Test','SV','HCM','0999','CTY',SYSDATE,USER,SYSDATE,USER,SYSDATE);
  3      SAVEPOINT sp1;
  4      INSERT INTO student VALUES (998,NULL,'Test2','SV','HCM','0998','CTY',SYSDATE,USER,SYSDATE,USER,SYSDATE);
  5      ROLLBACK TO sp1;
  6      COMMIT;
  7  END;
  8  /

PL/SQL procedure successfully completed.

SQL> CREATE SEQUENCE seq_test
  2  START WITH 1
  3  INCREMENT BY 1;

Sequence created.

SQL> INSERT INTO course VALUES (seq_test.NEXTVAL,'Test',100,NULL,USER,SYSDATE,USER,SYSDATE);
INSERT INTO course VALUES (seq_test.NEXTVAL,'Test',100,NULL,USER,SYSDATE,USER,SYSDATE)
*
ERROR at line 1:
ORA-00001: unique constraint (NGUYENTHAI.SYS_C008488) violated 


SQL> DROP SEQUENCE seq_test;

Sequence dropped.

SQL> 
SQL> CREATE SEQUENCE seq_test
  2  START WITH 21
  3  INCREMENT BY 1;

Sequence created.

SQL> INSERT INTO course
  2  VALUES (seq_test.NEXTVAL,'Test',100,NULL,USER,SYSDATE,USER,SYSDATE);

1 row created.

SQL> DECLARE
  2      CURSOR c1 IS
  3          SELECT studentid, firstname FROM student;
  4  BEGIN
  5      FOR r IN c1 LOOP
  6          DBMS_OUTPUT.PUT_LINE(r.studentid || ' - ' || r.firstname);
  7      END LOOP;
  8  END;
  9  /
101 - An                                                                        
102 - Binh                                                                      
103 - Cuong                                                                     
104 - Dung                                                                      
105 - Hieu                                                                      
106 - Khanh                                                                     
107 - Linh                                                                      
108 - Minh                                                                      
109 - Nam                                                                       
110 - Phong                                                                     
111 - Quang                                                                     
112 - Son                                                                       
113 - Tuan                                                                      
114 - Viet                                                                      
115 - Anh                                                                       
116 - Bao                                                                       
117 - Chau                                                                      
118 - Duc                                                                       
119 - Giang                                                                     
120 - Hung                                                                      
999 - Test                                                                      

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE PROCEDURE test_proc(p_id IN NUMBER, p_name OUT VARCHAR2)
  2  IS
  3  BEGIN
  4      p_name := 'SV ' || p_id;
  5  END;
  6  /

Procedure created.

SQL> DECLARE
  2      v_name VARCHAR2(50);
  3  BEGIN
  4      test_proc(1, v_name);
  5      DBMS_OUTPUT.PUT_LINE(v_name);
  6  END;
  7  /
SV 1                                                                            

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE FUNCTION test_func(p_num NUMBER)
  2  RETURN NUMBER
  3  IS
  4  BEGIN
  5      RETURN p_num * 2;
  6  END;
  7  /

Function created.

SQL> SELECT test_func(10) FROM dual;

TEST_FUNC(10)                                                                   
-------------                                                                   
           20                                                                   

SQL> CREATE OR REPLACE TRIGGER trg_student
  2  BEFORE INSERT ON student
  3  FOR EACH ROW
  4  BEGIN
  5      :NEW.createdby := USER;
  6      :NEW.createddate := SYSDATE;
  7  END;
  8  /

Trigger created.

SQL> DECLARE
  2      v_name VARCHAR2(50);
  3  BEGIN
  4      SELECT firstname INTO v_name
  5      FROM student
  6      WHERE studentid = 9999;
  7  EXCEPTION
  8      WHEN NO_DATA_FOUND THEN
  9          DBMS_OUTPUT.PUT_LINE('Khong tim thay');
 10  END;
 11  /
Khong tim thay                                                                  

PL/SQL procedure successfully completed.

SQL> COMMIT;

Commit complete.

SQL> CREATE TABLE Cau1 (
  2  ID NUMBER,
  3  NAME VARCHAR2(20)
  4  );

Table created.

SQL> CREATE SEQUENCE Cau1Seq
  2  START WITH 5
  3  INCREMENT BY 5;

Sequence created.

SQL> SET SERVEROUTPUT ON;
SQL> DECLARE
  2  v_name VARCHAR2(50);
  3  v_id NUMBER;
  4  BEGIN
  5  -- [d] Them sinh vien dang ki nhieu mon nhat
  6  SELECT firstname || ' ' || lastname
  7  INTO v_name
  8  FROM student
  9  WHERE studentid = (
 10  SELECT studentid FROM enrollment
 11  GROUP BY studentid
 12  HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM enrollment GROUP BY
 13  studentid)
 14  FETCH FIRST 1 ROWS ONLY
 15  );
 16  INSERT INTO Cau1 (ID, NAME)
 17  VALUES (Cau1Seq.NEXTVAL, v_name);
 18  SAVEPOINT sp_a; -- Savepoint A
 19  -- [e] Them sinh vien dang ki it mon nhat
 20  SELECT firstname || ' ' || lastname
 21  INTO v_name
 22  FROM student
 23  WHERE studentid = (
 24  SELECT studentid FROM enrollment
 25  GROUP BY studentid
 26  HAVING COUNT(*) = (SELECT MIN(COUNT(*)) FROM enrollment GROUP BY
 27  studentid)
 28  FETCH FIRST 1 ROWS ONLY
 29  );
 30  INSERT INTO Cau1 (ID, NAME)
 31  VALUES (Cau1Seq.NEXTVAL, v_name);
 32  SAVEPOINT sp_b; -- Savepoint B
 33  -- [f] Them giao vien day nhieu lop nhat
 34  SELECT i.firstname || ' ' || i.lastname
 35  INTO v_name
 36  FROM instructor i
 37  WHERE i.instructorid = (
 38  SELECT instructorid FROM class
 39  GROUP BY instructorid
 40  HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM class GROUP BY
 41  instructorid)
 42  FETCH FIRST 1 ROWS ONLY
 43  );
 44  INSERT INTO Cau1 (ID, NAME)
 45  VALUES (Cau1Seq.NEXTVAL, v_name);
 46  SAVEPOINT sp_c; -- Savepoint C
 47  -- [g] SELECT INTO: lay ID cua giao vien vua them vao bien v_id
 48  SELECT ID INTO v_id
 49  FROM Cau1
 50  WHERE NAME = v_name;
 51  DBMS_OUTPUT.PUT_LINE('ID giao vien nhieu lop: ' || v_id);
 52  -- [h] Rollback giao vien nhieu lop (ve Savepoint B)
 53  ROLLBACK TO sp_b;
 54  -- [i] Them giao vien it lop nhat, dung v_id da luu
 55  SELECT i.firstname || ' ' || i.lastname
 56  INTO v_name
 57  FROM instructor i
 58  WHERE i.instructorid = (
 59  SELECT instructorid FROM class
 60  GROUP BY instructorid
 61  HAVING COUNT(*) = (SELECT MIN(COUNT(*)) FROM class GROUP BY
 62  instructorid)
 63  FETCH FIRST 1 ROWS ONLY
 64  );
 65  INSERT INTO Cau1 (ID, NAME)
 66  VALUES (v_id, v_name); -- Dung v_id (khong phai sequence)
 67  -- [j] Them lai giao vien nhieu lop, dung sequence
 68  SELECT i.firstname || ' ' || i.lastname
 69  INTO v_name
 70  FROM instructor i
 71  WHERE i.instructorid = (
 72  SELECT instructorid FROM class
 73  GROUP BY instructorid
 74  HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM class GROUP BY
 75  instructorid)
 76  FETCH FIRST 1 ROWS ONLY
 77  );
 78  INSERT INTO Cau1 (ID, NAME)
 79  VALUES (Cau1Seq.NEXTVAL, v_name); -- Dung sequence
 80  COMMIT;
 81  DBMS_OUTPUT.PUT_LINE('Hoan tat! Kiem tra: SELECT * FROM Cau1;');
 82  EXCEPTION
 83  WHEN NO_DATA_FOUND THEN
 84  DBMS_OUTPUT.PUT_LINE('Loi: Khong tim thay du lieu!');
 85  ROLLBACK;
 86  WHEN OTHERS THEN
 87  DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
 88  ROLLBACK;
 89  END;
 90  /
Loi: ORA-01422: exact fetch returns more than requested number of rows          

PL/SQL procedure successfully completed.

SQL> SET SERVEROUTPUT ON;
SQL> DECLARE
  2  v_name VARCHAR2(50);
  3  v_id NUMBER;
  4  BEGIN
  5  -- [d] Them sinh vien dang ki nhieu mon nhat
  6  SELECT firstname || ' ' || lastname
  7  INTO v_name
  8  FROM student
  9  WHERE studentid = (
 10  SELECT studentid FROM enrollment
 11  GROUP BY studentid
 12  HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM enrollment GROUP BY
 13  studentid)
 14  FETCH FIRST 1 ROWS ONLY
 15  );
 16  INSERT INTO Cau1 (ID, NAME)
 17  VALUES (Cau1Seq.NEXTVAL, v_name);
 18  SAVEPOINT sp_a; -- Savepoint A
 19  -- [e] Them sinh vien dang ki it mon nhat
 20  SELECT firstname || ' ' || lastname
 21  INTO v_name
 22  FROM student
 23  WHERE studentid = (
 24  SELECT studentid FROM enrollment
 25  GROUP BY studentid
 26  HAVING COUNT(*) = (SELECT MIN(COUNT(*)) FROM enrollment GROUP BY
 27  studentid)
 28  FETCH FIRST 1 ROWS ONLY
 29  );
 30  INSERT INTO Cau1 (ID, NAME)
 31  VALUES (Cau1Seq.NEXTVAL, v_name);
 32  SAVEPOINT sp_b; -- Savepoint B
 33  -- [f] Them giao vien day nhieu lop nhat
 34  SELECT i.firstname || ' ' || i.lastname
 35  INTO v_name
 36  FROM instructor i
 37  WHERE i.instructorid = (
 38  SELECT instructorid FROM class
 39  GROUP BY instructorid
 40  HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM class GROUP BY
 41  instructorid)
 42  FETCH FIRST 1 ROWS ONLY
 43  );
 44  INSERT INTO Cau1 (ID, NAME)
 45  VALUES (Cau1Seq.NEXTVAL, v_name);
 46  SAVEPOINT sp_c; -- Savepoint C
 47  -- [g] SELECT INTO: lay ID cua giao vien vua them vao bien v_id
 48  SELECT ID INTO v_id
 49  FROM Cau1
 50  WHERE NAME = v_name
 51  AND ROWNUM = 1;
 52  DBMS_OUTPUT.PUT_LINE('ID giao vien nhieu lop: ' || v_id);
 53  -- [h] Rollback giao vien nhieu lop (ve Savepoint B)
 54  ROLLBACK TO sp_b;
 55  -- [i] Them giao vien it lop nhat, dung v_id da luu
 56  SELECT i.firstname || ' ' || i.lastname
 57  INTO v_name
 58  FROM instructor i
 59  WHERE i.instructorid = (
 60  SELECT instructorid FROM class
 61  GROUP BY instructorid
 62  HAVING COUNT(*) = (SELECT MIN(COUNT(*)) FROM class GROUP BY
 63  instructorid)
 64  FETCH FIRST 1 ROWS ONLY
 65  );
 66  INSERT INTO Cau1 (ID, NAME)
 67  VALUES (v_id, v_name); -- Dung v_id (khong phai sequence)
 68  -- [j] Them lai giao vien nhieu lop, dung sequence
 69  SELECT i.firstname || ' ' || i.lastname
 70  INTO v_name
 71  FROM instructor i
 72  WHERE i.instructorid = (
 73  SELECT instructorid FROM class
 74  GROUP BY instructorid
 75  HAVING COUNT(*) = (SELECT MAX(COUNT(*)) FROM class GROUP BY
 76  instructorid)
 77  FETCH FIRST 1 ROWS ONLY
 78  );
 79  INSERT INTO Cau1 (ID, NAME)
 80  VALUES (Cau1Seq.NEXTVAL, v_name); -- Dung sequence
 81  COMMIT;
 82  DBMS_OUTPUT.PUT_LINE('Hoan tat! Kiem tra: SELECT * FROM Cau1;');
 83  EXCEPTION
 84  WHEN NO_DATA_FOUND THEN
 85  DBMS_OUTPUT.PUT_LINE('Loi: Khong tim thay du lieu!');
 86  ROLLBACK;
 87  WHEN OTHERS THEN
 88  DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
 89  ROLLBACK;
 90  END;
 91  /
ID giao vien nhieu lop: 20                                                      
Hoan tat! Kiem tra: SELECT * FROM Cau1;                                         

PL/SQL procedure successfully completed.

SQL> SET SERVEROUTPUT ON;
SQL> DECLARE
  2  v_sid NUMBER := &ma_sinh_vien;
  3  v_fname VARCHAR2(25) := '&ho_sinh_vien';
  4  v_lname VARCHAR2(25) := '&ten_sinh_vien';
  5  v_addr VARCHAR2(50) := '&dia_chi';
  6  v_found VARCHAR2(50);
  7  v_classes NUMBER;
  8  BEGIN
  9  -- Thu tim sinh vien theo ma vua nhap
 10  SELECT firstname || ' ' || lastname
 11  INTO v_found
 12  FROM student
 13  WHERE studentid = v_sid;
 14  -- Neu tim thay: dem so lop dang hoc
 15  SELECT COUNT(*)
 16  INTO v_classes
 17  FROM enrollment
 18  WHERE studentid = v_sid;
 19  DBMS_OUTPUT.PUT_LINE('Ho ten: ' || v_found);
 20  DBMS_OUTPUT.PUT_LINE('So lop dang hoc: ' || v_classes);
 21  EXCEPTION
 22  WHEN NO_DATA_FOUND THEN
 23  -- Sinh vien chua ton tai: them moi
 24  DBMS_OUTPUT.PUT_LINE('Sinh vien chua ton tai. Dang them moi...');
 25  INSERT INTO student (studentid, firstname, lastname, address,
 26  registrationdate, createdby, createddate,
 27  modifiedby, modifieddate)
 28  VALUES (v_sid, v_fname, v_lname, v_addr,
 29  SYSDATE, USER, SYSDATE, USER, SYSDATE);
 30  COMMIT;
 31  DBMS_OUTPUT.PUT_LINE('Da them sinh vien moi: ' || v_fname || ' ' ||
 32  v_lname);
 33  END;
 34  /
Enter value for ma_sinh_vien: 110
old   2: v_sid NUMBER := &ma_sinh_vien;
new   2: v_sid NUMBER := 110;
Enter value for ho_sinh_vien: 130
old   3: v_fname VARCHAR2(25) := '&ho_sinh_vien';
new   3: v_fname VARCHAR2(25) := '130';
Enter value for ten_sinh_vien: 110
old   4: v_lname VARCHAR2(25) := '&ten_sinh_vien';
new   4: v_lname VARCHAR2(25) := '110';
Enter value for dia_chi: 
old   5: v_addr VARCHAR2(50) := '&dia_chi';
new   5: v_addr VARCHAR2(50) := '';
Ho ten: Phong Ngo                                                               
So lop dang hoc: 1                                                              

PL/SQL procedure successfully completed.

SQL> SET SERVEROUTPUT ON;
SQL> DECLARE
  2  v_sid NUMBER := &ma_sinh_vien;
  3  v_fname VARCHAR2(25) := '&ho_sinh_vien';
  4  v_lname VARCHAR2(25) := '&ten_sinh_vien';
  5  v_addr VARCHAR2(50) := '&dia_chi';
  6  v_found VARCHAR2(50);
  7  v_classes NUMBER;
  8  BEGIN
  9  -- Thu tim sinh vien theo ma vua nhap
 10  SELECT firstname || ' ' || lastname
 11  INTO v_found
 12  FROM student
 13  WHERE studentid = v_sid;
 14  -- Neu tim thay: dem so lop dang hoc
 15  SELECT COUNT(*)
 16  INTO v_classes
 17  FROM enrollment
 18  WHERE studentid = v_sid;
 19  DBMS_OUTPUT.PUT_LINE('Ho ten: ' || v_found);
 20  DBMS_OUTPUT.PUT_LINE('So lop dang hoc: ' || v_classes);
 21  EXCEPTION
 22  WHEN NO_DATA_FOUND THEN
 23  -- Sinh vien chua ton tai: them moi
 24  DBMS_OUTPUT.PUT_LINE('Sinh vien chua ton tai. Dang them moi...');
 25  INSERT INTO student (studentid, firstname, lastname, address,
 26  registrationdate, createdby, createddate,
 27  modifiedby, modifieddate)
 28  VALUES (v_sid, v_fname, v_lname, v_addr,
 29  SYSDATE, USER, SYSDATE, USER, SYSDATE);
 30  COMMIT;
 31  DBMS_OUTPUT.PUT_LINE('Da them sinh vien moi: ' || v_fname || ' ' ||
 32  v_lname);
 33  END;
 34  /
Enter value for ma_sinh_vien: 200
old   2: v_sid NUMBER := &ma_sinh_vien;
new   2: v_sid NUMBER := 200;
Enter value for ho_sinh_vien: Nguyen
old   3: v_fname VARCHAR2(25) := '&ho_sinh_vien';
new   3: v_fname VARCHAR2(25) := 'Nguyen';
Enter value for ten_sinh_vien: Thai
old   4: v_lname VARCHAR2(25) := '&ten_sinh_vien';
new   4: v_lname VARCHAR2(25) := 'Thai';
Enter value for dia_chi: HCM
old   5: v_addr VARCHAR2(50) := '&dia_chi';
new   5: v_addr VARCHAR2(50) := 'HCM';
Sinh vien chua ton tai. Dang them moi...                                        
Da them sinh vien moi: Nguyen Thai                                              

PL/SQL procedure successfully completed.

SQL> SET SERVEROUTPUT ON;
SQL> DECLARE
  2  v_instructor_id NUMBER := &ma_giao_vien;
  3  v_so_lop NUMBER;
  4  BEGIN
  5  -- Dem so lop giao vien dang day
  6  SELECT COUNT(*)
  7  INTO v_so_lop
  8  FROM class
  9  WHERE instructorid = v_instructor_id;
 10  -- Phan nhanh theo ket qua
 11  IF v_so_lop >= 5 THEN
 12  DBMS_OUTPUT.PUT_LINE('Giao vien nay nen nghi ngoi!');
 13  ELSE
 14  DBMS_OUTPUT.PUT_LINE('So lop giao vien dang day: ' || v_so_lop);
 15  END IF;
 16  EXCEPTION
 17  WHEN NO_DATA_FOUND THEN
 18  DBMS_OUTPUT.PUT_LINE('Khong tim thay giao vien co ma: ' ||
 19  v_instructor_id);
 20  END;
 21  /
Enter value for ma_giao_vien: 1
old   2: v_instructor_id NUMBER := &ma_giao_vien;
new   2: v_instructor_id NUMBER := 1;
So lop giao vien dang day: 2                                                    

PL/SQL procedure successfully completed.

SQL> SET SERVEROUTPUT ON;
SQL> DECLARE
  2  v_sid NUMBER := &ma_sinh_vien;
  3  v_cid NUMBER := &ma_lop;
  4  v_score NUMBER;
  5  v_grade VARCHAR2(2);
  6  v_check NUMBER;
  7  BEGIN
  8  -- Kiem tra sinh vien ton tai
  9  SELECT COUNT(*) INTO v_check
 10  FROM student WHERE studentid = v_sid;
 11  IF v_check = 0 THEN
 12  DBMS_OUTPUT.PUT_LINE('Loi: Ma sinh vien ' || v_sid || ' khong ton tai!');
 13  RETURN;
 14  END IF;
 15  -- Kiem tra lop ton tai
 16  SELECT COUNT(*) INTO v_check
 17  FROM class WHERE classid = v_cid;
 18  IF v_check = 0 THEN
 19  DBMS_OUTPUT.PUT_LINE('Loi: Ma lop ' || v_cid || ' khong ton tai!');
 20  RETURN;
 21  END IF;
 22  -- Lay diem cua sinh vien trong lop
 23  SELECT finalgrade
 24  INTO v_score
 25  FROM enrollment
 26  WHERE studentid = v_sid AND classid = v_cid;
 27  -- Quy doi diem so sang diem chu bang CASE
 28  CASE
 29  WHEN v_score >= 90 THEN v_grade := 'A';
 30  WHEN v_score >= 80 THEN v_grade := 'B';
 31  WHEN v_score >= 70 THEN v_grade := 'C';
 32  WHEN v_score >= 50 THEN v_grade := 'D';
 33  ELSE v_grade := 'F';
 34  END CASE;
 35  DBMS_OUTPUT.PUT_LINE('Diem so: ' || v_score || ' -> Diem chu: ' ||
 36  v_grade);
 37  EXCEPTION
 38  WHEN NO_DATA_FOUND THEN
 39  DBMS_OUTPUT.PUT_LINE('Sinh vien chua dang ky lop nay hoac chua co diem!');
 40  END;
 41  /
Enter value for ma_sinh_vien: 101
old   2: v_sid NUMBER := &ma_sinh_vien;
new   2: v_sid NUMBER := 101;
Enter value for ma_lop: 1
old   3: v_cid NUMBER := &ma_lop;
new   3: v_cid NUMBER := 1;
Diem so: 90 -> Diem chu: A                                                      

PL/SQL procedure successfully completed.

SQL> SET SERVEROUTPUT ON;
SQL> DECLARE
  2  -- Cursor 1: Duyet tung mon hoc
  3  CURSOR cur_course IS
  4  SELECT courseno, description
  5  FROM course
  6  ORDER BY courseno;
  7  -- Cursor 2: Lay lop hoc cua mot mon (co doi so)
  8  CURSOR cur_class (p_courseno NUMBER) IS
  9  SELECT c.classno,
 10  COUNT(e.studentid) AS so_sv
 11  FROM class c
 12  LEFT JOIN enrollment e ON c.classid = e.classid
 13  WHERE c.courseno = p_courseno
 14  GROUP BY c.classno
 15  ORDER BY c.classno;
 16  v_courseno course.courseno%TYPE;
 17  v_desc course.description%TYPE;
 18  v_classno class.classno%TYPE;
 19  v_count NUMBER;
 20  BEGIN
 21  -- Duyet cursor ngoai: tung mon hoc
 22  OPEN cur_course;
 23  LOOP
 24  FETCH cur_course INTO v_courseno, v_desc;
 25  EXIT WHEN cur_course%NOTFOUND;
 26  -- In ten mon hoc
 27  DBMS_OUTPUT.PUT_LINE(v_courseno || ' ' || v_desc);
 28  -- Mo cursor trong voi doi so la ma mon hoc hien tai
 29  OPEN cur_class(v_courseno);
 30  LOOP
 31  FETCH cur_class INTO v_classno, v_count;
 32  EXIT WHEN cur_class%NOTFOUND;
 33  DBMS_OUTPUT.PUT_LINE('Lop: ' || v_classno ||
 34  ' co so luong sinh vien dang ki: ' ||
 35  v_count);
 36  END LOOP;
 37  CLOSE cur_class;
 38  END LOOP;
 39  CLOSE cur_course;
 40  EXCEPTION
 41  WHEN OTHERS THEN
 42  IF cur_course%ISOPEN THEN CLOSE cur_course; END IF;
 43  IF cur_class%ISOPEN THEN CLOSE cur_class; END IF;
 44  DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
 45  END;
 46  /
1 Co so du lieu                                                                 
Lop: 1 co so luong sinh vien dang ki: 2                                         
2 He quan tri CSDL                                                              
Lop: 1 co so luong sinh vien dang ki: 2                                         
3 Java                                                                          
Lop: 1 co so luong sinh vien dang ki: 2                                         
4 Python                                                                        
Lop: 1 co so luong sinh vien dang ki: 1                                         
5 C++                                                                           
Lop: 1 co so luong sinh vien dang ki: 1                                         
6 Web                                                                           
Lop: 1 co so luong sinh vien dang ki: 1                                         
7 HTML                                                                          
Lop: 1 co so luong sinh vien dang ki: 1                                         
8 CSS                                                                           
Lop: 1 co so luong sinh vien dang ki: 1                                         
9 JS                                                                            
Lop: 1 co so luong sinh vien dang ki: 1                                         
10 React                                                                        
Lop: 1 co so luong sinh vien dang ki: 1                                         
11 Angular                                                                      
Lop: 1 co so luong sinh vien dang ki: 1                                         
12 Vue                                                                          
Lop: 1 co so luong sinh vien dang ki: 1                                         
13 PHP                                                                          
Lop: 1 co so luong sinh vien dang ki: 1                                         
14 Laravel                                                                      
Lop: 1 co so luong sinh vien dang ki: 1                                         
15 Spring                                                                       
Lop: 1 co so luong sinh vien dang ki: 1                                         
16 AI                                                                           
Lop: 1 co so luong sinh vien dang ki: 1                                         
17 ML                                                                           
Lop: 1 co so luong sinh vien dang ki: 1                                         
18 DL                                                                           
Lop: 1 co so luong sinh vien dang ki: 1                                         
19 Data                                                                         
Lop: 1 co so luong sinh vien dang ki: 1                                         
20 BigData                                                                      
Lop: 1 co so luong sinh vien dang ki: 0                                         
21 Test                                                                         

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE PROCEDURE find_sname
  2  (i_student_id IN student.studentid%TYPE,
  3  o_first_name OUT student.firstname%TYPE,
  4  o_last_name OUT student.lastname%TYPE)
  5  IS
  6  BEGIN
  7  SELECT firstname, lastname
  8  INTO o_first_name, o_last_name
  9  FROM student
 10  WHERE studentid = i_student_id;
 11  EXCEPTION
 12  WHEN NO_DATA_FOUND THEN
 13  o_first_name := NULL;
 14  o_last_name := NULL;
 15  DBMS_OUTPUT.PUT_LINE('Khong tim thay sinh vien ID: ' ||
 16  i_student_id);
 17  END find_sname;
 18  /

Procedure created.

SQL> CREATE OR REPLACE PROCEDURE print_student_name
  2  (i_student_id IN student.studentid%TYPE)
  3  IS
  4  v_first student.firstname%TYPE;
  5  v_last student.lastname%TYPE;
  6  BEGIN
  7  -- Goi thu tuc find_sname da co san
  8  find_sname(i_student_id, v_first, v_last);
  9  IF v_first IS NOT NULL OR v_last IS NOT NULL THEN
 10  DBMS_OUTPUT.PUT_LINE('Ho ten sinh vien: ' || v_first || ' ' ||
 11  v_last);
 12  END IF;
 13  END print_student_name;
 14  /

Procedure created.

SQL> -- Goi thu tuc de kiem tra:
SQL> BEGIN
  2  print_student_name(101);
  3  END;
  4  /
Ho ten sinh vien: An Nguyen                                                     

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE PROCEDURE Discount
  2  IS
  3  BEGIN
  4  FOR rec IN (
  5  SELECT c.courseno, c.description, c.cost
  6  FROM course c
  7  WHERE (SELECT COUNT(*) FROM enrollment e
  8  JOIN class cl ON e.classid = cl.classid
  9  WHERE cl.courseno = c.courseno) > 1
 10  ) LOOP
 11  -- Giam gia 5%
 12  UPDATE course
 13  SET cost = cost * 0.95
 14  WHERE courseno = rec.courseno;
 15  DBMS_OUTPUT.PUT_LINE('Da giam gia mon hoc: ' || rec.description
 16  || ' | Gia cu: ' || rec.cost
 17  || ' | Gia moi: ' || ROUND(rec.cost * 0.95, 2));
 18  END LOOP;
 19  COMMIT;
 20  DBMS_OUTPUT.PUT_LINE('Hoan tat giam gia.');
 21  EXCEPTION
 22  WHEN OTHERS THEN
 23  ROLLBACK;
 24  DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
 25  END Discount;
 26  /

Procedure created.

SQL> -- Goi thu tuc:
SQL> BEGIN Discount; END;
  2  /
Da giam gia mon hoc: Co so du lieu | Gia cu: 100 | Gia moi: 95                  
Da giam gia mon hoc: He quan tri CSDL | Gia cu: 150 | Gia moi: 142.5            
Da giam gia mon hoc: Java | Gia cu: 200 | Gia moi: 190                          
Hoan tat giam gia.                                                              

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE FUNCTION Total_cost_for_student
  2  (p_student_id IN student.studentid%TYPE)
  3  RETURN NUMBER
  4  IS
  5  v_total NUMBER;
  6  v_check NUMBER;
  7  BEGIN
  8  -- Kiem tra sinh vien co ton tai khong
  9  SELECT COUNT(*) INTO v_check
 10  FROM student WHERE studentid = p_student_id;
 11  IF v_check = 0 THEN
 12  RETURN NULL; -- Sinh vien khong ton tai
 13  END IF;
 14  -- Tinh tong chi phi: sum(cost cua tung mon da dang ky)
 15  SELECT NVL(SUM(co.cost), 0)
 16  INTO v_total
 17  FROM enrollment e
 18  JOIN class cl ON e.classid = cl.classid
 19  JOIN course co ON cl.courseno = co.courseno
 20  WHERE e.studentid = p_student_id;
 21  RETURN v_total;
 22  EXCEPTION
 23  WHEN OTHERS THEN
 24  RETURN NULL;
 25  END Total_cost_for_student;
 26  /

Function created.

SQL> -- Goi ham de kiem tra:
SQL> SELECT Total_cost_for_student(101) AS "Tong chi phi" FROM DUAL;

Tong chi phi                                                                    
------------                                                                    
       427.5                                                                    

SQL> -- Hoac trong PL/SQL:
SQL> BEGIN
  2  DBMS_OUTPUT.PUT_LINE('Tong chi phi: ' || Total_cost_for_student(101));
  3  END;
  4  /
Tong chi phi: 427.5                                                             

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE TRIGGER trg_course_audit
  2  BEFORE INSERT OR UPDATE ON course
  3  FOR EACH ROW
  4  BEGIN
  5  IF INSERTING THEN
  6  :NEW.created_by := USER;
  7  :NEW.created_date := SYSDATE;
  8  END IF;
  9  -- Luon cap nhat modified (ca khi INSERT lan UPDATE)
 10  :NEW.modified_by := USER;
 11  :NEW.modified_date := SYSDATE;
 12  END trg_course_audit;
 13  /

Warning: Trigger created with compilation errors.

SQL> CREATE OR REPLACE TRIGGER trg_course_audit
  2  BEFORE INSERT OR UPDATE ON course
  3  FOR EACH ROW
  4  BEGIN
  5  IF INSERTING THEN
  6  :NEW.createdby := USER;
  7  :NEW.createddate := SYSDATE;
  8  END IF;
  9  -- Luon cap nhat modified (ca khi INSERT lan UPDATE)
 10  :NEW.modifiedby := USER;
 11  :NEW.modifieddate := SYSDATE;
 12  END trg_course_audit;
 13  /

Trigger created.

SQL> CREATE OR REPLACE TRIGGER trg_class_audit
  2  BEFORE INSERT OR UPDATE ON class
  3  FOR EACH ROW
  4  BEGIN
  5  IF INSERTING THEN
  6  :NEW.createdby := USER;
  7  :NEW.createddate := SYSDATE;
  8  END IF;
  9  :NEW.modifiedby := USER;
 10  :NEW.modifieddate := SYSDATE;
 11  END trg_class_audit;
 12  /

Trigger created.

SQL> CREATE OR REPLACE TRIGGER trg_student_audit
  2  BEFORE INSERT OR UPDATE ON student FOR EACH ROW
  3  BEGIN
  4  IF INSERTING THEN :NEW.createdby:=USER; :NEW.createddate:=SYSDATE; END
  5  IF;
  6  :NEW.modifiedby:=USER; :NEW.modifieddate:=SYSDATE;
  7  END;
  8  /

Trigger created.

SQL> CREATE OR REPLACE TRIGGER trg_enrollment_audit
  2  BEFORE INSERT OR UPDATE ON enrollment FOR EACH ROW
  3  BEGIN
  4  IF INSERTING THEN :NEW.createdby:=USER; :NEW.createddate:=SYSDATE; END
  5  IF;
  6  :NEW.modifiedby:=USER; :NEW.modifieddate:=SYSDATE;
  7  END;
  8  /

Trigger created.

SQL> CREATE OR REPLACE TRIGGER trg_instructor_audit
  2  BEFORE INSERT OR UPDATE ON instructor FOR EACH ROW
  3  BEGIN
  4  IF INSERTING THEN :NEW.createdby:=USER; :NEW.createddate:=SYSDATE; END
  5  IF;
  6  :NEW.modifiedby:=USER; :NEW.modifieddate:=SYSDATE;
  7  END;
  8  /

Trigger created.

SQL> CREATE OR REPLACE TRIGGER trg_grade_audit
  2  BEFORE INSERT OR UPDATE ON grade FOR EACH ROW
  3  BEGIN
  4  IF INSERTING THEN :NEW.createdby:=USER; :NEW.createddate:=SYSDATE; END
  5  IF;
  6  :NEW.modifiedby:=USER; :NEW.modifieddate:=SYSDATE;
  7  END;
  8  /

Trigger created.

SQL> CREATE OR REPLACE TRIGGER trg_max_enrollment
  2  BEFORE INSERT ON enrollment
  3  FOR EACH ROW
  4  DECLARE
  5  v_so_lop NUMBER;
  6  BEGIN
  7  -- Dem so lop sinh vien nay dang dang ky
  8  SELECT COUNT(*)
  9  INTO v_so_lop
 10  FROM enrollment
 11  WHERE studentid = :NEW.studentid;
 12  -- Neu da co 3 lop tro len thi tu choi
 13  IF v_so_lop >= 3 THEN
 14  RAISE_APPLICATION_ERROR(
 15  -20001,
 16  'Sinh vien ' || :NEW.studentid ||
 17  ' da dang ky du 3 lop! Khong the dang ky them.'
 18  );
 19  END IF;
 20  END trg_max_enrollment;
 21  /

Trigger created.

SQL> -- Kiem tra trigger:
SQL> -- Gia su sinh vien 101 da co 3 lop, thu them lop thu 4:
SQL> INSERT INTO enrollment (studentid, classid, enrolldate, createdby, createddate, modifiedby, modifieddate)
  2  VALUES (101, 999, SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO enrollment (studentid, classid, enrolldate, createdby, createddate, modifiedby, modifieddate)
            *
ERROR at line 1:
ORA-20001: Sinh vien 101 da dang ky du 3 lop! Khong the dang ky them. 
ORA-06512: at "NGUYENTHAI.TRG_MAX_ENROLLMENT", line 11 
ORA-04088: error during execution of trigger 'NGUYENTHAI.TRG_MAX_ENROLLMENT' 


SQL> CREATE OR REPLACE TRIGGER trg_max_enrollment
  2  BEFORE INSERT ON enrollment
  3  FOR EACH ROW
  4  DECLARE
  5  v_so_lop NUMBER;
  6  BEGIN
  7  -- Dem so lop sinh vien nay dang dang ky
  8  SELECT COUNT(*)
  9  INTO v_so_lop
 10  FROM enrollment
 11  WHERE studentid = :NEW.studentid;
 12  -- Neu da co 3 lop tro len thi tu choi
 13  IF v_so_lop >= 3 THEN
 14  RAISE_APPLICATION_ERROR(
 15  -20001,
 16  'Sinh vien ' || :NEW.studentid ||
 17  ' da dang ky du 3 lop! Khong the dang ky them.'
 18  );
 19  END IF;
 20  END trg_max_enrollment;
 21  /

Trigger created.

SQL> -- Kiem tra trigger:
SQL> -- Gia su sinh vien 101 da co 3 lop, thu them lop thu 4:
SQL> INSERT INTO enrollment (studentid, classid, enrolldate, createdby, createddate, modifiedby, modifieddate)
  2  VALUES (101, 90, SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO enrollment (studentid, classid, enrolldate, createdby, createddate, modifiedby, modifieddate)
            *
ERROR at line 1:
ORA-20001: Sinh vien 101 da dang ky du 3 lop! Khong the dang ky them. 
ORA-06512: at "NGUYENTHAI.TRG_MAX_ENROLLMENT", line 11 
ORA-04088: error during execution of trigger 'NGUYENTHAI.TRG_MAX_ENROLLMENT' 


SQL> SPOOL OFF;
