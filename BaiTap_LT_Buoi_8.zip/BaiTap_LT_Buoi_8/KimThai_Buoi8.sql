

CREATE TABLE HangSX (
    MaHangSX VARCHAR2(10) CONSTRAINT pk_hangsx PRIMARY KEY,
    TenHang VARCHAR2(30) NOT NULL,
    DiaChi VARCHAR2(50),
    SoDT VARCHAR2(15),
    Email VARCHAR2(50)
);
CREATE TABLE SanPham (
    MaSP VARCHAR2(10) CONSTRAINT pk_sanpham PRIMARY KEY,
    MaHangSX VARCHAR2(10) REFERENCES HangSX(MaHangSX),
    TenSP VARCHAR2(50) NOT NULL,
    SoLuong NUMBER(10),
    MauSac VARCHAR2(20),
    GiaBan NUMBER(15,2),
    DonViTinh VARCHAR2(15),
    MoTa CLOB
);
CREATE TABLE NhanVien (
    MaNV VARCHAR2(10) CONSTRAINT pk_nhanvien PRIMARY KEY,
    TenNV VARCHAR2(50) NOT NULL,
    GioiTinh VARCHAR2(10),
    DiaChi VARCHAR2(100),
    SoDT VARCHAR2(15),
    Email VARCHAR2(50),
    TenPhong VARCHAR2(30)
);
CREATE TABLE PNhap (
    SoHDN VARCHAR2(10) CONSTRAINT pk_pnhap PRIMARY KEY,
    NgayNhap DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);
CREATE TABLE Nhap (
    SoHDN VARCHAR2(10) REFERENCES PNhap(SoHDN),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongN NUMBER(10),
    DonGiaN NUMBER(15,2),
    CONSTRAINT pk_nhap PRIMARY KEY (SoHDN, MaSP)
);
CREATE TABLE PXuat (
    SoHDX VARCHAR2(10) CONSTRAINT pk_pxuat PRIMARY KEY,
    NgayXuat DATE,
    MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV)
);
CREATE TABLE Xuat (
    SoHDX VARCHAR2(10) REFERENCES PXuat(SoHDX),
    MaSP VARCHAR2(10) REFERENCES SanPham(MaSP),
    SoLuongX NUMBER(10),
    CONSTRAINT pk_xuat PRIMARY KEY (SoHDX, MaSP)
);

---PHIẾU BÀI TẬP 1
--a. Thủ tục sp_NhapHangSX
CREATE OR REPLACE PROCEDURE sp_NhapHangSX (
    p_MaHangSX IN VARCHAR2,
    p_TenHang  IN VARCHAR2,
    p_DiaChi   IN VARCHAR2,
    p_SoDT     IN VARCHAR2,
    p_Email    IN VARCHAR2
)
AS
    v_TenHang VARCHAR2(30);
BEGIN
    SELECT TenHang INTO v_TenHang
    FROM HangSX
    WHERE TenHang = p_TenHang;

    DBMS_OUTPUT.PUT_LINE('Ten hang da ton tai');
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        INSERT INTO HangSX(MaHangSX, TenHang, DiaChi, SoDT, Email)
        VALUES (p_MaHangSX, p_TenHang, p_DiaChi, p_SoDT, p_Email);

        DBMS_OUTPUT.PUT_LINE('Them hang san xuat thanh cong');
END;
/
--b. Thủ tục sp_NhapSP
CREATE OR REPLACE PROCEDURE sp_NhapSP (
    p_MaSP       IN VARCHAR2,
    p_TenHang    IN VARCHAR2,
    p_TenSP      IN VARCHAR2,
    p_SoLuong    IN NUMBER,
    p_MauSac     IN VARCHAR2,
    p_GiaBan     IN NUMBER,
    p_DonViTinh  IN VARCHAR2,
    p_MoTa       IN CLOB
)
AS
    v_MaHangSX VARCHAR2(10);
    v_MaSP     VARCHAR2(10);
BEGIN
    -- Kiểm tra TenHang có tồn tại không
    BEGIN
        SELECT MaHangSX INTO v_MaHangSX
        FROM HangSX
        WHERE TenHang = p_TenHang;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Ten hang khong ton tai');
            RETURN;
    END;

    -- Kiểm tra MaSP đã có chưa
    BEGIN
        SELECT MaSP INTO v_MaSP
        FROM SanPham
        WHERE MaSP = p_MaSP;

        UPDATE SanPham
        SET MaHangSX   = v_MaHangSX,
            TenSP      = p_TenSP,
            SoLuong    = p_SoLuong,
            MauSac     = p_MauSac,
            GiaBan     = p_GiaBan,
            DonViTinh  = p_DonViTinh,
            MoTa       = p_MoTa
        WHERE MaSP = p_MaSP;

        DBMS_OUTPUT.PUT_LINE('Da cap nhat san pham');
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            INSERT INTO SanPham(MaSP, MaHangSX, TenSP, SoLuong, MauSac, GiaBan, DonViTinh, MoTa)
            VALUES (p_MaSP, v_MaHangSX, p_TenSP, p_SoLuong, p_MauSac, p_GiaBan, p_DonViTinh, p_MoTa);

            DBMS_OUTPUT.PUT_LINE('Da them san pham moi');
    END;
END;
/
--c. Thủ tục sp_xoaHangSX
CREATE OR REPLACE PROCEDURE sp_XoaHangSX (
    p_TenHang IN VARCHAR2
)
AS
    v_MaHangSX VARCHAR2(10);
BEGIN
    BEGIN
        SELECT MaHangSX INTO v_MaHangSX
        FROM HangSX
        WHERE TenHang = p_TenHang;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('Ten hang khong ton tai');
            RETURN;
    END;

    DELETE FROM SanPham
    WHERE MaHangSX = v_MaHangSX;

    DELETE FROM HangSX
    WHERE MaHangSX = v_MaHangSX;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Xoa hang san xuat thanh cong');
END;
/
--d. Thủ tục nhập dữ liệu NhanVien (có biến FLAG)
CREATE OR REPLACE PROCEDURE sp_NhapNhanVien (
    p_MaNV      IN VARCHAR2,
    p_TenNV     IN VARCHAR2,
    p_GioiTinh  IN VARCHAR2,
    p_DiaChi    IN VARCHAR2,
    p_SoDT      IN VARCHAR2,
    p_Email     IN VARCHAR2,
    p_TenPhong  IN VARCHAR2,
    p_Flag      IN NUMBER
)
AS
BEGIN
    IF p_Flag = 0 THEN
        UPDATE NhanVien
        SET TenNV     = p_TenNV,
            GioiTinh  = p_GioiTinh,
            DiaChi    = p_DiaChi,
            SoDT      = p_SoDT,
            Email     = p_Email,
            TenPhong  = p_TenPhong
        WHERE MaNV = p_MaNV;

        DBMS_OUTPUT.PUT_LINE('Da cap nhat nhan vien');
    ELSE
        INSERT INTO NhanVien(MaNV, TenNV, GioiTinh, DiaChi, SoDT, Email, TenPhong)
        VALUES (p_MaNV, p_TenNV, p_GioiTinh, p_DiaChi, p_SoDT, p_Email, p_TenPhong);

        DBMS_OUTPUT.PUT_LINE('Da them moi nhan vien');
    END IF;
END;
/
--e. Thủ tục nhập dữ liệu bảng Nhap
CREATE OR REPLACE PROCEDURE sp_NhapDuLieuNhap (
    p_SoHDN     IN VARCHAR2,
    p_MaSP      IN VARCHAR2,
    p_MaNV      IN VARCHAR2,
    p_NgayNhap  IN DATE,
    p_SoLuongN  IN NUMBER,
    p_DonGiaN   IN NUMBER
)
AS
    v_MaSP  VARCHAR2(10);
    v_MaNV  VARCHAR2(10);
    v_SoHDN VARCHAR2(10);
BEGIN
    BEGIN
        SELECT MaSP INTO v_MaSP
        FROM SanPham
        WHERE MaSP = p_MaSP;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('MaSP khong ton tai');
            RETURN;
    END;

    BEGIN
        SELECT MaNV INTO v_MaNV
        FROM NhanVien
        WHERE MaNV = p_MaNV;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('MaNV khong ton tai');
            RETURN;
    END;

    BEGIN
        SELECT SoHDN INTO v_SoHDN
        FROM PNhap
        WHERE SoHDN = p_SoHDN;

        UPDATE PNhap
        SET NgayNhap = p_NgayNhap,
            MaNV = p_MaNV
        WHERE SoHDN = p_SoHDN;

        UPDATE Nhap
        SET MaSP = p_MaSP,
            SoLuongN = p_SoLuongN,
            DonGiaN = p_DonGiaN
        WHERE SoHDN = p_SoHDN;

        DBMS_OUTPUT.PUT_LINE('Da cap nhat phieu nhap');
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            INSERT INTO PNhap(SoHDN, NgayNhap, MaNV)
            VALUES (p_SoHDN, p_NgayNhap, p_MaNV);

            INSERT INTO Nhap(SoHDN, MaSP, SoLuongN, DonGiaN)
            VALUES (p_SoHDN, p_MaSP, p_SoLuongN, p_DonGiaN);

            DBMS_OUTPUT.PUT_LINE('Da them phieu nhap moi');
    END;
END;
/
--f. Thủ tục nhập dữ liệu bảng Xuat
CREATE OR REPLACE PROCEDURE sp_NhapDuLieuXuat (
    p_SoHDX     IN VARCHAR2,
    p_MaSP      IN VARCHAR2,
    p_MaNV      IN VARCHAR2,
    p_NgayXuat  IN DATE,
    p_SoLuongX  IN NUMBER
)
AS
    v_MaSP         VARCHAR2(10);
    v_MaNV         VARCHAR2(10);
    v_SoHDX        VARCHAR2(10);
    v_SoLuongTon   NUMBER := 0;
BEGIN
    BEGIN
        SELECT MaSP, SoLuong INTO v_MaSP, v_SoLuongTon
        FROM SanPham
        WHERE MaSP = p_MaSP;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('MaSP khong ton tai');
            RETURN;
    END;

    BEGIN
        SELECT MaNV INTO v_MaNV
        FROM NhanVien
        WHERE MaNV = p_MaNV;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('MaNV khong ton tai');
            RETURN;
    END;

    IF p_SoLuongX > v_SoLuongTon THEN
        DBMS_OUTPUT.PUT_LINE('So luong xuat vuot qua ton kho');
        RETURN;
    END IF;

    BEGIN
        SELECT SoHDX INTO v_SoHDX
        FROM PXuat
        WHERE SoHDX = p_SoHDX;

        UPDATE PXuat
        SET NgayXuat = p_NgayXuat,
            MaNV = p_MaNV
        WHERE SoHDX = p_SoHDX;

        UPDATE Xuat
        SET MaSP = p_MaSP,
            SoLuongX = p_SoLuongX
        WHERE SoHDX = p_SoHDX;

        DBMS_OUTPUT.PUT_LINE('Da cap nhat phieu xuat');
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            INSERT INTO PXuat(SoHDX, NgayXuat, MaNV)
            VALUES (p_SoHDX, p_NgayXuat, p_MaNV);

            INSERT INTO Xuat(SoHDX, MaSP, SoLuongX)
            VALUES (p_SoHDX, p_MaSP, p_SoLuongX);

            DBMS_OUTPUT.PUT_LINE('Da them phieu xuat moi');
    END;
END;
/
--g. Thủ tục xóa NhanVien
CREATE OR REPLACE PROCEDURE sp_XoaNhanVien (
    p_MaNV IN VARCHAR2
)
AS
    v_MaNV VARCHAR2(10);
BEGIN
    BEGIN
        SELECT MaNV INTO v_MaNV
        FROM NhanVien
        WHERE MaNV = p_MaNV;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('MaNV khong ton tai');
            RETURN;
    END;

    DELETE FROM Nhap
    WHERE SoHDN IN (
        SELECT SoHDN FROM PNhap WHERE MaNV = p_MaNV
    );

    DELETE FROM Xuat
    WHERE SoHDX IN (
        SELECT SoHDX FROM PXuat WHERE MaNV = p_MaNV
    );

    DELETE FROM PNhap WHERE MaNV = p_MaNV;
    DELETE FROM PXuat WHERE MaNV = p_MaNV;
    DELETE FROM NhanVien WHERE MaNV = p_MaNV;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Da xoa nhan vien');
END;
/
--h. Thủ tục xóa SanPham
CREATE OR REPLACE PROCEDURE sp_XoaSanPham (
    p_MaSP IN VARCHAR2
)
AS
    v_MaSP VARCHAR2(10);
BEGIN
    BEGIN
        SELECT MaSP INTO v_MaSP
        FROM SanPham
        WHERE MaSP = p_MaSP;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('MaSP khong ton tai');
            RETURN;
    END;

    DELETE FROM Nhap WHERE MaSP = p_MaSP;
    DELETE FROM Xuat WHERE MaSP = p_MaSP;
    DELETE FROM SanPham WHERE MaSP = p_MaSP;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Da xoa san pham');
END;
/

---PHIẾU BÀI TẬP 2
--a. Thủ tục sp_ThemNhanVien (có OUT)
CREATE OR REPLACE PROCEDURE sp_ThemNhanVien (
    p_MaNV      IN VARCHAR2,
    p_TenNV     IN VARCHAR2,
    p_GioiTinh  IN VARCHAR2,
    p_DiaChi    IN VARCHAR2,
    p_SoDT      IN VARCHAR2,
    p_Email     IN VARCHAR2,
    p_TenPhong  IN VARCHAR2,
    p_Flag      IN NUMBER,
    p_KQ        OUT NUMBER
)
AS
BEGIN
    IF p_GioiTinh <> 'Nam' AND p_GioiTinh <> 'Nữ' AND p_GioiTinh <> 'Nu' THEN
        p_KQ := 1;
        RETURN;
    END IF;

    IF p_Flag = 0 THEN
        INSERT INTO NhanVien(MaNV, TenNV, GioiTinh, DiaChi, SoDT, Email, TenPhong)
        VALUES (p_MaNV, p_TenNV, p_GioiTinh, p_DiaChi, p_SoDT, p_Email, p_TenPhong);
    ELSE
        UPDATE NhanVien
        SET TenNV = p_TenNV,
            GioiTinh = p_GioiTinh,
            DiaChi = p_DiaChi,
            SoDT = p_SoDT,
            Email = p_Email,
            TenPhong = p_TenPhong
        WHERE MaNV = p_MaNV;
    END IF;

    p_KQ := 0;
END;
/
--b. Thủ tục sp_ThemMoiSP (có OUT)
CREATE OR REPLACE PROCEDURE sp_ThemMoiSP (
    p_MaSP       IN VARCHAR2,
    p_TenHang    IN VARCHAR2,
    p_TenSP      IN VARCHAR2,
    p_SoLuong    IN NUMBER,
    p_MauSac     IN VARCHAR2,
    p_GiaBan     IN NUMBER,
    p_DonViTinh  IN VARCHAR2,
    p_MoTa       IN CLOB,
    p_Flag       IN NUMBER,
    p_KQ         OUT NUMBER
)
AS
    v_MaHangSX VARCHAR2(10);
BEGIN
    BEGIN
        SELECT MaHangSX INTO v_MaHangSX
        FROM HangSX
        WHERE TenHang = p_TenHang;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_KQ := 1;
            RETURN;
    END;

    IF p_SoLuong < 0 THEN
        p_KQ := 2;
        RETURN;
    END IF;

    IF p_Flag = 0 THEN
        INSERT INTO SanPham(MaSP, MaHangSX, TenSP, SoLuong, MauSac, GiaBan, DonViTinh, MoTa)
        VALUES (p_MaSP, v_MaHangSX, p_TenSP, p_SoLuong, p_MauSac, p_GiaBan, p_DonViTinh, p_MoTa);
    ELSE
        UPDATE SanPham
        SET MaHangSX = v_MaHangSX,
            TenSP = p_TenSP,
            SoLuong = p_SoLuong,
            MauSac = p_MauSac,
            GiaBan = p_GiaBan,
            DonViTinh = p_DonViTinh,
            MoTa = p_MoTa
        WHERE MaSP = p_MaSP;
    END IF;

    p_KQ := 0;
END;
/
--c. Thủ tục xóa NhanVien (có OUT)
CREATE OR REPLACE PROCEDURE sp_XoaNhanVien_OUT (
    p_MaNV IN VARCHAR2,
    p_KQ   OUT NUMBER
)
AS
    v_MaNV VARCHAR2(10);
BEGIN
    BEGIN
        SELECT MaNV INTO v_MaNV
        FROM NhanVien
        WHERE MaNV = p_MaNV;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_KQ := 1;
            RETURN;
    END;

    DELETE FROM Nhap
    WHERE SoHDN IN (SELECT SoHDN FROM PNhap WHERE MaNV = p_MaNV);

    DELETE FROM Xuat
    WHERE SoHDX IN (SELECT SoHDX FROM PXuat WHERE MaNV = p_MaNV);

    DELETE FROM PNhap WHERE MaNV = p_MaNV;
    DELETE FROM PXuat WHERE MaNV = p_MaNV;
    DELETE FROM NhanVien WHERE MaNV = p_MaNV;

    p_KQ := 0;
END;
/
--d. Thủ tục xóa SanPham (có OUT)
CREATE OR REPLACE PROCEDURE sp_XoaSanPham_OUT (
    p_MaSP IN VARCHAR2,
    p_KQ   OUT NUMBER
)
AS
    v_MaSP VARCHAR2(10);
BEGIN
    BEGIN
        SELECT MaSP INTO v_MaSP
        FROM SanPham
        WHERE MaSP = p_MaSP;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_KQ := 1;
            RETURN;
    END;

    DELETE FROM Nhap WHERE MaSP = p_MaSP;
    DELETE FROM Xuat WHERE MaSP = p_MaSP;
    DELETE FROM SanPham WHERE MaSP = p_MaSP;

    p_KQ := 0;
END;
/
--e. Thủ tục sp_NhapHangSX (có OUT)
CREATE OR REPLACE PROCEDURE sp_NhapHangSX_OUT (
    p_MaHangSX IN VARCHAR2,
    p_TenHang  IN VARCHAR2,
    p_DiaChi   IN VARCHAR2,
    p_SoDT     IN VARCHAR2,
    p_Email    IN VARCHAR2,
    p_KQ       OUT NUMBER
)
AS
    v_TenHang VARCHAR2(30);
BEGIN
    BEGIN
        SELECT TenHang INTO v_TenHang
        FROM HangSX
        WHERE TenHang = p_TenHang;

        p_KQ := 1;
        RETURN;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            INSERT INTO HangSX(MaHangSX, TenHang, DiaChi, SoDT, Email)
            VALUES (p_MaHangSX, p_TenHang, p_DiaChi, p_SoDT, p_Email);

            p_KQ := 0;
    END;
END;
/
--f. Thủ tục nhập bảng Nhap (có OUT)
CREATE OR REPLACE PROCEDURE sp_NhapBangNhap_OUT (
    p_SoHDN     IN VARCHAR2,
    p_MaSP      IN VARCHAR2,
    p_MaNV      IN VARCHAR2,
    p_NgayNhap  IN DATE,
    p_SoLuongN  IN NUMBER,
    p_DonGiaN   IN NUMBER,
    p_KQ        OUT NUMBER
)
AS
    v_Temp VARCHAR2(10);
BEGIN
    BEGIN
        SELECT MaSP INTO v_Temp
        FROM SanPham
        WHERE MaSP = p_MaSP;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_KQ := 1;
            RETURN;
    END;

    BEGIN
        SELECT MaNV INTO v_Temp
        FROM NhanVien
        WHERE MaNV = p_MaNV;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_KQ := 2;
            RETURN;
    END;

    BEGIN
        SELECT SoHDN INTO v_Temp
        FROM PNhap
        WHERE SoHDN = p_SoHDN;

        UPDATE PNhap
        SET NgayNhap = p_NgayNhap,
            MaNV = p_MaNV
        WHERE SoHDN = p_SoHDN;

        UPDATE Nhap
        SET MaSP = p_MaSP,
            SoLuongN = p_SoLuongN,
            DonGiaN = p_DonGiaN
        WHERE SoHDN = p_SoHDN;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            INSERT INTO PNhap(SoHDN, NgayNhap, MaNV)
            VALUES (p_SoHDN, p_NgayNhap, p_MaNV);

            INSERT INTO Nhap(SoHDN, MaSP, SoLuongN, DonGiaN)
            VALUES (p_SoHDN, p_MaSP, p_SoLuongN, p_DonGiaN);
    END;

    p_KQ := 0;
END;
/
--g. Thủ tục nhập bảng Xuat (có OUT)
CREATE OR REPLACE PROCEDURE sp_NhapBangXuat_OUT (
    p_SoHDX     IN VARCHAR2,
    p_MaSP      IN VARCHAR2,
    p_MaNV      IN VARCHAR2,
    p_NgayXuat  IN DATE,
    p_SoLuongX  IN NUMBER,
    p_KQ        OUT NUMBER
)
AS
    v_Temp        VARCHAR2(10);
    v_SoLuongTon  NUMBER := 0;
BEGIN
    BEGIN
        SELECT MaSP, SoLuong INTO v_Temp, v_SoLuongTon
        FROM SanPham
        WHERE MaSP = p_MaSP;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_KQ := 1;
            RETURN;
    END;

    BEGIN
        SELECT MaNV INTO v_Temp
        FROM NhanVien
        WHERE MaNV = p_MaNV;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_KQ := 2;
            RETURN;
    END;

    IF p_SoLuongX > v_SoLuongTon THEN
        p_KQ := 3;
        RETURN;
    END IF;

    BEGIN
        SELECT SoHDX INTO v_Temp
        FROM PXuat
        WHERE SoHDX = p_SoHDX;

        UPDATE PXuat
        SET NgayXuat = p_NgayXuat,
            MaNV = p_MaNV
        WHERE SoHDX = p_SoHDX;

        UPDATE Xuat
        SET MaSP = p_MaSP,
            SoLuongX = p_SoLuongX
        WHERE SoHDX = p_SoHDX;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            INSERT INTO PXuat(SoHDX, NgayXuat, MaNV)
            VALUES (p_SoHDX, p_NgayXuat, p_MaNV);

            INSERT INTO Xuat(SoHDX, MaSP, SoLuongX)
            VALUES (p_SoHDX, p_MaSP, p_SoLuongX);
    END;

    p_KQ := 0;
END;
/
    