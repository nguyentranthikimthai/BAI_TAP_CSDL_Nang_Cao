SQL> SET SERVEROUTPUT ON;
SQL> @D:\Nam3\hk2\CSDLNangCao\THanh\Lab4\csdl.sql
DROP TABLE grade CASCADE CONSTRAINTS
           *
ERROR at line 1:
ORA-00942: table or view does not exist 


DROP TABLE enrollment CASCADE CONSTRAINTS
           *
ERROR at line 1:
ORA-00942: table or view does not exist 


DROP TABLE student CASCADE CONSTRAINTS
           *
ERROR at line 1:
ORA-00942: table or view does not exist 


DROP TABLE class CASCADE CONSTRAINTS
           *
ERROR at line 1:
ORA-00942: table or view does not exist 


DROP TABLE course CASCADE CONSTRAINTS
           *
ERROR at line 1:
ORA-00942: table or view does not exist 


DROP TABLE instructor CASCADE CONSTRAINTS
           *
ERROR at line 1:
ORA-00942: table or view does not exist 



Table created.


Table created.


Table created.


Table created.


Table created.


Table created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


1 row created.


Commit complete.

SQL> -- Cu phap chung
SQL> ten_ham() OVER ([PARTITION BY cot1] [ORDER BY cot2] [khung_cua_so])
SP2-0734: unknown command beginning "ten_ham() ..." - rest of line ignored.
SQL> -- Khung cua so (frame):
SQL> ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW -- Tu dau den hien tai
SP2-0734: unknown command beginning "ROWS BETWE..." - rest of line ignored.
SQL> ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING -- 1 hang truoc + 1 sau
SP2-0734: unknown command beginning "ROWS BETWE..." - rest of line ignored.
SQL> -- Cac ham phan tich hay dung:
SQL> RANK() OVER (ORDER BY salary DESC) -- Xep hang, co khoang (1,1,3)
SP2-0734: unknown command beginning "RANK() OVE..." - rest of line ignored.
SQL> DENSE_RANK() OVER (ORDER BY salary DESC) -- Xep hang lien tuc (1,1,2)
SP2-0734: unknown command beginning "DENSE_RANK..." - rest of line ignored.
SQL> ROW_NUMBER() OVER (ORDER BY salary DESC) -- So thu tu tuyet doi (1,2,3)
SP2-0734: unknown command beginning "ROW_NUMBER..." - rest of line ignored.
SQL> LAG(salary,1) OVER (ORDER BY hire_date) -- Gia tri hang truoc do
SP2-0734: unknown command beginning "LAG(salary..." - rest of line ignored.
SP2-0044: For a list of known commands enter HELP
and to leave enter EXIT.
SQL> LEAD(salary,1)OVER (ORDER BY hire_date) -- Gia tri hang sau do
SP2-0734: unknown command beginning "LEAD(salar..." - rest of line ignored.
SQL> SUM(salary) OVER (ORDER BY hire_date -- Tong tich luy
SP2-0734: unknown command beginning "SUM(salary..." - rest of line ignored.
SQL> ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
SP2-0734: unknown command beginning "ROWS BETWE..." - rest of line ignored.
SQL> AVG(salary) OVER (PARTITION BY dept_id) -- Trung binh theo nhom (giu hang)
SP2-0734: unknown command beginning "AVG(salary..." - rest of line ignored.
SP2-0044: For a list of known commands enter HELP
and to leave enter EXIT.
SQL> -- Ham phan vi (Percentile):
SQL> PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY finalgrade) -- Trung vi (P50)
SP2-0734: unknown command beginning "PERCENTILE..." - rest of line ignored.
SQL> PERCENTILE_DISC(0.25)WITHIN GROUP (ORDER BY finalgrade) -- P25 (phan vi roi rac)
SP2-0734: unknown command beginning "PERCENTILE..." - rest of line ignored.
SQL> STDDEV(finalgrade) -- Do lech chuan
SP2-0734: unknown command beginning "STDDEV(fin..." - rest of line ignored.
SQL> VARIANCE(finalgrade) -- Phuong sai
SP2-0734: unknown command beginning "VARIANCE(f..." - rest of line ignored.
SP2-0044: For a list of known commands enter HELP
and to leave enter EXIT.
SQL> CREATE OR REPLACE VIEW vw_prerequisite_check AS
  2  SELECT s.studentid,
  3  s.firstname || ' ' || s.lastname AS ho_ten,
  4  co.description AS ten_mon,
  5  co.courseno,
  6  tq.description AS ten_mon_tq,
  7  tq.courseno AS courseno_tq
  8  FROM enrollment e
  9  JOIN student s ON e.studentid = s.studentid
 10  JOIN class cl ON e.classid = cl.classid
 11  JOIN course co ON cl.courseno = co.courseno
 12  JOIN course tq ON co.prerequisite = tq.courseno
 13  WHERE co.prerequisite IS NOT NULL
 14  AND NOT EXISTS (
 15  SELECT 1
 16  FROM enrollment e2
 17  JOIN class cl2 ON e2.classid = cl2.classid
 18  WHERE e2.studentid = s.studentid
 19  AND cl2.courseno = co.prerequisite
 20  AND e2.finalgrade IS NOT NULL
 21  );

View created.

SQL> 
SQL> -- Dem truong hop hoc vuot theo tung mon:
SQL> SELECT ten_mon, courseno, COUNT(*) AS so_sv_hoc_vuot
  2  FROM vw_prerequisite_check
  3  GROUP BY ten_mon, courseno
  4  ORDER BY so_sv_hoc_vuot DESC;

no rows selected

SQL> CREATE OR REPLACE VIEW vw_instructor_performance AS
  2  SELECT instructorid, ho_ten, so_lop, tong_sv,
  3  sv_co_diem, diem_tb, diem_max, diem_min,
  4  ROUND(sv_dat * 100 / NULLIF(sv_co_diem,0), 1) AS ty_le_dat_pct,
  5  DENSE_RANK() OVER (ORDER BY diem_tb DESC NULLS LAST) AS
  6  hang_diem_tb,
  7  RANK() OVER (ORDER BY tong_sv DESC) AS hang_so_sv
  8  FROM (
  9  SELECT i.instructorid,
 10  i.firstname || ' ' || i.lastname AS ho_ten,
 11  COUNT(DISTINCT cl.classid) AS so_lop,
 12  COUNT(e.studentid) AS tong_sv,
 13  COUNT(e.finalgrade) AS sv_co_diem,
 14  ROUND(AVG(e.finalgrade),2) AS diem_tb,
 15  MAX(e.finalgrade) AS diem_max,
 16  MIN(e.finalgrade) AS diem_min,
 17  SUM(CASE WHEN e.finalgrade >= 50
 18  THEN 1 ELSE 0 END) AS sv_dat
 19  FROM instructor i
 20  LEFT JOIN class cl ON i.instructorid = cl.instructorid
 21  LEFT JOIN enrollment e ON cl.classid = e.classid
 22  GROUP BY i.instructorid, i.firstname, i.lastname
 23  );

View created.

SQL> 
SQL> -- Top 3 giao vien ty le SV dat cao nhat:
SQL> SELECT ho_ten, ty_le_dat_pct, sv_co_diem, diem_tb
  2  FROM vw_instructor_performance
  3  WHERE hang_diem_tb <= 3
  4  ORDER BY hang_diem_tb;

HO_TEN                                              TY_LE_DAT_PCT SV_CO_DIEM    
--------------------------------------------------- ------------- ----------    
   DIEM_TB                                                                      
----------                                                                      
Phong Ngo                                                     100          1    
        91                                                                      
                                                                                
Khanh Vo                                                      100          2    
      86.5                                                                      
                                                                                
Minh Bui                                                      100          2    
      84.5                                                                      
                                                                                

SQL> CREATE OR REPLACE VIEW vw_monthly_enrollment_stats AS
  2  SELECT nam, thang, so_dang_ky, so_sv_moi, so_mon, diem_tb_thang,
  3  SUM(so_dang_ky) OVER (
  4  ORDER BY nam, thang
  5  ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
  6  ) AS luy_ke_dang_ky
  7  FROM (
  8  SELECT TO_CHAR(e.enrolldate,'YYYY') AS nam,
  9  TO_CHAR(e.enrolldate,'MM') AS thang,
 10  COUNT(*) AS so_dang_ky,
 11  COUNT(DISTINCT e.studentid) AS so_sv_moi,
 12  COUNT(DISTINCT cl.courseno) AS so_mon,
 13  ROUND(AVG(e.finalgrade),2) AS diem_tb_thang
 14  FROM enrollment e
 15  JOIN class cl ON e.classid = cl.classid
 16  GROUP BY TO_CHAR(e.enrolldate,'YYYY'),
 17  TO_CHAR(e.enrolldate,'MM')
 18  )
 19  ORDER BY nam DESC, thang ASC;

View created.

SQL> 
SQL> SELECT * FROM vw_monthly_enrollment_stats;

NAM  TH SO_DANG_KY  SO_SV_MOI     SO_MON DIEM_TB_THANG LUY_KE_DANG_KY           
---- -- ---------- ---------- ---------- ------------- --------------           
2026 05         22         20         19         76.27             22           

SQL> CREATE OR REPLACE VIEW vw_enrollment_full AS
  2  SELECT e.studentid, e.classid, e.enrolldate, e.finalgrade,
  3  s.firstname || ' ' || s.lastname AS ten_sv,
  4  co.description AS ten_mon,
  5  i.firstname || ' ' || i.lastname AS ten_gv
  6  FROM enrollment e
  7  JOIN student s ON e.studentid = s.studentid
  8  JOIN class cl ON e.classid = cl.classid
  9  JOIN course co ON cl.courseno = co.courseno
 10  JOIN instructor i ON cl.instructorid = i.instructorid;

View created.

SQL> CREATE OR REPLACE TRIGGER trg_iot_enrollment_full
  2  INSTEAD OF INSERT ON vw_enrollment_full
  3  FOR EACH ROW
  4  DECLARE
  5  v_sv_check NUMBER;
  6  v_cl_check NUMBER;
  7  v_capacity NUMBER;
  8  v_enrolled NUMBER;
  9  BEGIN
 10  SELECT COUNT(*) INTO v_sv_check FROM student WHERE
 11  studentid=:NEW.studentid;
 12  IF v_sv_check=0 THEN
 13  RAISE_APPLICATION_ERROR(-20050,'Sinh vien khong ton tai!'); RETURN;
 14  END IF;
 15  
 16  SELECT COUNT(*) INTO v_cl_check FROM class WHERE classid=:NEW.classid;
 17  IF v_cl_check=0 THEN
 18  RAISE_APPLICATION_ERROR(-20051,'Lop hoc khong ton tai!'); RETURN;
 19  END IF;
 20  
 21  SELECT capacity INTO v_capacity FROM class WHERE classid=:NEW.classid;
 22  SELECT COUNT(*) INTO v_enrolled FROM enrollment WHERE
 23  classid=:NEW.classid;
 24  IF v_enrolled >= v_capacity THEN
 25  RAISE_APPLICATION_ERROR(-20052,'Lop da day!'); RETURN;
 26  END IF;
 27  
 28  INSERT INTO enrollment
 29  (studentid,classid,enrolldate,createdby,createddate,modifiedby,modifieddate
 30  )
 31  VALUES
 32  (:NEW.studentid,:NEW.classid,NVL(:NEW.enrolldate,SYSDATE),
 33  USER,SYSDATE,USER,SYSDATE);
 34  DBMS_OUTPUT.PUT_LINE('[OK] Da dang ky: SV '||:NEW.studentid||' -> Lop
 35  '||:NEW.classid);
 36  END trg_iot_enrollment_full;
 37  /

Trigger created.

SQL> 
SQL> -- Kiem tra INSERT qua view:
SQL> INSERT INTO vw_enrollment_full (studentid,classid)
  2  VALUES (101, 3);
INSERT INTO vw_enrollment_full (studentid,classid)
            *
ERROR at line 1:
ORA-01400: cannot insert NULL into ("KTHAI"."ENROLLMENT"."REGISTRATIONDATE") 
ORA-06512: at "KTHAI.TRG_IOT_ENROLLMENT_FULL", line 25 
ORA-04088: error during execution of trigger 'KTHAI.TRG_IOT_ENROLLMENT_FULL' 


SQL> COMMIT;

Commit complete.

SQL> CREATE OR REPLACE VIEW vw_grade_distribution AS
  2  SELECT classid, courseno, description,
  3  sv_A, sv_B, sv_C, sv_D, sv_F, sv_chua_co,
  4  p25, p50_median, p75,
  5  ROUND(std_dev,2) AS
  6  do_lech_chuan,
  7  ROUND(std_dev / NULLIF(diem_tb,0) * 100, 2) AS he_so_bt
  8  FROM (
  9  SELECT cl.classid,
 10  cl.courseno,
 11  co.description,
 12  SUM(CASE WHEN e.finalgrade>=90 THEN 1 ELSE 0 END) AS sv_A,
 13  SUM(CASE WHEN e.finalgrade>=80
 14  AND e.finalgrade<90 THEN 1 ELSE 0 END) AS sv_B,
 15  SUM(CASE WHEN e.finalgrade>=70
 16  AND e.finalgrade<80 THEN 1 ELSE 0 END) AS sv_C,
 17  SUM(CASE WHEN e.finalgrade>=50
 18  AND e.finalgrade<70 THEN 1 ELSE 0 END) AS sv_D,
 19  SUM(CASE WHEN e.finalgrade<50
 20  AND e.finalgrade IS NOT NULL
 21  THEN 1 ELSE 0 END) AS sv_F,
 22  SUM(CASE WHEN e.finalgrade IS NULL THEN 1 ELSE 0 END) AS
 23  sv_chua_co,
 24  PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY e.finalgrade) AS
 25  p25,
 26  PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY e.finalgrade) AS
 27  p50_median,
 28  PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY e.finalgrade) AS
 29  p75,
 30  STDDEV(e.finalgrade) AS std_dev,
 31  AVG(e.finalgrade) AS diem_tb
 32  FROM class cl
 33  JOIN course co ON cl.courseno = co.courseno
 34  LEFT JOIN enrollment e ON cl.classid = e.classid
 35  GROUP BY cl.classid, cl.courseno, co.description
 36  HAVING COUNT(e.finalgrade) >= 2
 37  );

View created.

SQL> 
SQL> SELECT * FROM vw_grade_distribution ORDER BY classid;

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
      SV_A       SV_B       SV_C       SV_D       SV_F SV_CHUA_CO        P25    
---------- ---------- ---------- ---------- ---------- ---------- ----------    
P50_MEDIAN        P75 DO_LECH_CHUAN   HE_SO_BT                                  
---------- ---------- ------------- ----------                                  
         1          1 Co so du lieu                                             
         1          0          0          1          0          0       67.5    
        75       82.5         21.21      28.28                                  
                                                                                
         2          2 He quan tri CSDL                                          
         0          1          0          1          0          0       57.5    
        65       72.5         21.21      32.64                                  

   CLASSID   COURSENO DESCRIPTION                                               
---------- ---------- --------------------------------------------------        
      SV_A       SV_B       SV_C       SV_D       SV_F SV_CHUA_CO        P25    
---------- ---------- ---------- ---------- ---------- ---------- ----------    
P50_MEDIAN        P75 DO_LECH_CHUAN   HE_SO_BT                                  
---------- ---------- ------------- ----------                                  
                                                                                
         3          3 Java                                                      
         0          1          1          0          0          0      73.75    
      77.5      81.25         10.61      13.69                                  
                                                                                

SQL> CREATE OR REPLACE VIEW vw_student_grade_pivot AS
  2  SELECT studentid,
  3  ho_ten,
  4  MAX(CASE WHEN classid=1 THEN finalgrade END) AS diem_lop_1,
  5  MAX(CASE WHEN classid=2 THEN finalgrade END) AS diem_lop_2,
  6  MAX(CASE WHEN classid=3 THEN finalgrade END) AS diem_lop_3,
  7  MAX(CASE WHEN classid=4 THEN finalgrade END) AS diem_lop_4,
  8  ROUND(AVG(finalgrade),2) AS diem_tb_chung,
  9  COUNT(classid) AS tong_lop
 10  FROM (
 11  SELECT e.studentid,
 12  s.firstname||' '||s.lastname AS ho_ten,
 13  e.classid,
 14  e.finalgrade
 15  FROM enrollment e JOIN student s ON e.studentid=s.studentid
 16  )
 17  GROUP BY studentid, ho_ten
 18  ORDER BY studentid;

View created.

SQL> 
SQL> SELECT * FROM vw_student_grade_pivot;

 STUDENTID HO_TEN                                              DIEM_LOP_1       
---------- --------------------------------------------------- ----------       
DIEM_LOP_2 DIEM_LOP_3 DIEM_LOP_4 DIEM_TB_CHUNG   TONG_LOP                       
---------- ---------- ---------- ------------- ----------                       
       101 An Nguyen                                                   90       
        80         70                       80          3                       
                                                                                
       102 Binh Tran                                                   60       
                                            60          1                       
                                                                                
       103 Cuong Le                                                             
        50                                  50          1                       
                                                                                

 STUDENTID HO_TEN                                              DIEM_LOP_1       
---------- --------------------------------------------------- ----------       
DIEM_LOP_2 DIEM_LOP_3 DIEM_LOP_4 DIEM_TB_CHUNG   TONG_LOP                       
---------- ---------- ---------- ------------- ----------                       
       104 Dung Pham                                                            
                   85                       85          1                       
                                                                                
       105 Hieu Hoang                                                           
                              75            75          1                       
                                                                                
       106 Khanh Vo                                                             
                                            65          1                       
                                                                                

 STUDENTID HO_TEN                                              DIEM_LOP_1       
---------- --------------------------------------------------- ----------       
DIEM_LOP_2 DIEM_LOP_3 DIEM_LOP_4 DIEM_TB_CHUNG   TONG_LOP                       
---------- ---------- ---------- ------------- ----------                       
       107 Linh Dang                                                            
                                            95          1                       
                                                                                
       108 Minh Bui                                                             
                                            88          1                       
                                                                                
       109 Nam Do                                                               
                                            77          1                       
                                                                                

 STUDENTID HO_TEN                                              DIEM_LOP_1       
---------- --------------------------------------------------- ----------       
DIEM_LOP_2 DIEM_LOP_3 DIEM_LOP_4 DIEM_TB_CHUNG   TONG_LOP                       
---------- ---------- ---------- ------------- ----------                       
       110 Phong Ngo                                                            
                                            66          1                       
                                                                                
       111 Quang Ly                                                             
                                            91          1                       
                                                                                
       112 Son Vu                                                               
                                            82          1                       
                                                                                

 STUDENTID HO_TEN                                              DIEM_LOP_1       
---------- --------------------------------------------------- ----------       
DIEM_LOP_2 DIEM_LOP_3 DIEM_LOP_4 DIEM_TB_CHUNG   TONG_LOP                       
---------- ---------- ---------- ------------- ----------                       
       113 Tuan Phan                                                            
                                            73          1                       
                                                                                
       114 Viet Huynh                                                           
                                            64          1                       
                                                                                
       115 Anh Nguyen                                                           
                                            55          1                       
                                                                                

 STUDENTID HO_TEN                                              DIEM_LOP_1       
---------- --------------------------------------------------- ----------       
DIEM_LOP_2 DIEM_LOP_3 DIEM_LOP_4 DIEM_TB_CHUNG   TONG_LOP                       
---------- ---------- ---------- ------------- ----------                       
       116 Bao Tran                                                             
                                            89          1                       
                                                                                
       117 Chau Le                                                              
                                            78          1                       
                                                                                
       118 Duc Pham                                                             
                                            68          1                       
                                                                                

 STUDENTID HO_TEN                                              DIEM_LOP_1       
---------- --------------------------------------------------- ----------       
DIEM_LOP_2 DIEM_LOP_3 DIEM_LOP_4 DIEM_TB_CHUNG   TONG_LOP                       
---------- ---------- ---------- ------------- ----------                       
       119 Giang Hoang                                                          
                                            92          1                       
                                                                                
       120 Hung Vo                                                              
                                            85          1                       
                                                                                

20 rows selected.

SQL> SELECT * FROM (
  2  SELECT e.studentid, e.classid, e.finalgrade
  3  FROM enrollment e
  4  )
  5  PIVOT (MAX(finalgrade) FOR classid IN
  6  (1 AS diem_lop_1, 2 AS diem_lop_2,
  7  3 AS diem_lop_3, 4 AS diem_lop_4)
  8  );

 STUDENTID DIEM_LOP_1 DIEM_LOP_2 DIEM_LOP_3 DIEM_LOP_4                          
---------- ---------- ---------- ---------- ----------                          
       101         90         80         70                                     
       102         60                                                           
       103                    50                                                
       104                               85                                     
       105                                          75                          
       106                                                                      
       107                                                                      
       108                                                                      
       109                                                                      
       110                                                                      
       111                                                                      

 STUDENTID DIEM_LOP_1 DIEM_LOP_2 DIEM_LOP_3 DIEM_LOP_4                          
---------- ---------- ---------- ---------- ----------                          
       112                                                                      
       113                                                                      
       114                                                                      
       115                                                                      
       116                                                                      
       117                                                                      
       118                                                                      
       119                                                                      
       120                                                                      

20 rows selected.

SQL> CREATE OR REPLACE VIEW vw_data_integrity_check AS
  2  -- Loi 1: SV trong ENROLLMENT khong ton tai trong STUDENT
  3  SELECT 'LOI_1: SV_KHONG_TON_TAI' AS loai_van_de,
  4  TO_CHAR(e.studentid) AS ma_tham_chieu,
  5  'StudentID '||e.studentid||' co trong ENROLLMENT nhung khong co
  6  trong STUDENT'
  7  AS mo_ta
  8  FROM enrollment e
  9  WHERE NOT EXISTS (SELECT 1 FROM student s WHERE s.studentid=e.studentid)
 10  UNION ALL
 11  -- Loi 2: Lop trong CLASS thieu giao vien
 12  SELECT 'LOI_2: LOP_THIEU_GIAO_VIEN',
 13  TO_CHAR(cl.classid),
 14  'ClassID '||cl.classid||' khong co InstructorID hop le'
 15  FROM class cl
 16  WHERE NOT EXISTS (SELECT 1 FROM instructor i WHERE
 17  i.instructorid=cl.instructorid)
 18  UNION ALL
 19  -- Loi 3: Diem trong GRADE khong khop voi ENROLLMENT
 20  SELECT 'LOI_3: DIEM_KHONG_KHOP',
 21  TO_CHAR(g.studentid)||'/'||TO_CHAR(g.classid),
 22  'GRADE.grade='||g.grade||' khac
 23  ENROLLMENT.finalgrade='||e.finalgrade
 24  FROM grade g
 25  JOIN enrollment e ON g.studentid=e.studentid AND g.classid=e.classid
 26  WHERE g.grade != NVL(e.finalgrade,-999)
 27  UNION ALL
 28  -- Loi 4: SV dang ky qua 3 lop
 29  SELECT 'LOI_4: DANG_KY_QUA_3_LOP',
 30  TO_CHAR(studentid),
 31  'StudentID '||studentid||' dang ky '||COUNT(*)||' lop (toi da 3)'
 32  FROM enrollment
 33  GROUP BY studentid
 34  HAVING COUNT(*) > 3;

View created.

SQL> SELECT * FROM vw_data_integrity_check;

no rows selected

SQL> CREATE OR REPLACE PROCEDURE get_students_by_class
  2  (p_classid IN NUMBER,
  3  p_result OUT SYS_REFCURSOR)
  4  IS
  5  v_check NUMBER;
  6  BEGIN
  7  SELECT COUNT(*) INTO v_check FROM class WHERE classid=p_classid;
  8  IF v_check=0 THEN
  9  p_result := NULL;
 10  DBMS_OUTPUT.PUT_LINE('Lop '||p_classid||' khong ton tai!');
 11  RETURN;
 12  END IF;
 13  
 14  OPEN p_result FOR
 15  SELECT s.studentid,
 16  s.firstname||' '||s.lastname AS ho_ten,
 17  e.finalgrade,
 18  CASE
 19  WHEN e.finalgrade>=90 THEN 'A'
 20  WHEN e.finalgrade>=80 THEN 'B'
 21  WHEN e.finalgrade>=70 THEN 'C'
 22  WHEN e.finalgrade>=50 THEN 'D'
 23  WHEN e.finalgrade IS NULL THEN 'Chua co'
 24  ELSE 'F'
 25  END AS xep_loai,
 26  RANK() OVER (ORDER BY e.finalgrade DESC NULLS LAST) AS
 27  thu_hang
 28  FROM enrollment e
 29  JOIN student s ON e.studentid=s.studentid
 30  WHERE e.classid=p_classid
 31  ORDER BY thu_hang;
 32  END get_students_by_class;
 33  /

Procedure created.

SQL> CREATE OR REPLACE PROCEDURE print_class_result
  2  (p_classid IN NUMBER)
  3  IS
  4  v_cur SYS_REFCURSOR;
  5  v_sid NUMBER;
  6  v_ten VARCHAR2(50);
  7  v_diem NUMBER;
  8  v_xep VARCHAR2(10);
  9  v_hang NUMBER;
 10  BEGIN
 11  get_students_by_class(p_classid, v_cur);
 12  IF v_cur IS NULL THEN RETURN; END IF;
 13  DBMS_OUTPUT.PUT_LINE('=== KET QUA LOP ' || p_classid || ' ===');
 14  DBMS_OUTPUT.PUT_LINE(RPAD('Hang',5)||RPAD('Ho
 15  Ten',22)||LPAD('Diem',6)||' Xep loai');
 16  DBMS_OUTPUT.PUT_LINE(RPAD('-',45,'-'));
 17  LOOP
 18  FETCH v_cur INTO v_sid, v_ten, v_diem, v_xep, v_hang;
 19  EXIT WHEN v_cur%NOTFOUND;
 20  DBMS_OUTPUT.PUT_LINE(
 21  LPAD(v_hang,4)||' '||RPAD(v_ten,22)
 22  ||LPAD(NVL(TO_CHAR(v_diem),'--'),6)||' '||v_xep);
 23  END LOOP;
 24  CLOSE v_cur;
 25  END print_class_result;
 26  /

Procedure created.

SQL> BEGIN print_class_result(1); END;
  2  /
=== KET QUA LOP 1 ===                                                           
Hang Ho
Ten                  Diem Xep loai                                      
---------------------------------------------                                   
1 An Nguyen                 90 A                                                
2 Binh Tran                 60 D                                                

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE PROCEDURE validate_enrollment
  2  (p_studentid IN NUMBER, p_classid IN NUMBER)
  3  IS
  4  ex_sv_not_found EXCEPTION; PRAGMA EXCEPTION_INIT(ex_sv_not_found, -
  5  20101);
  6  ex_class_not_found EXCEPTION; PRAGMA
  7  EXCEPTION_INIT(ex_class_not_found,-20102);
  8  ex_class_full EXCEPTION; PRAGMA EXCEPTION_INIT(ex_class_full,
  9  -20103);
 10  ex_already_enrolled EXCEPTION; PRAGMA
 11  EXCEPTION_INIT(ex_already_enrolled,-20104);
 12  v_check NUMBER; v_cap NUMBER; v_enr NUMBER;
 13  BEGIN
 14  SELECT COUNT(*) INTO v_check FROM student WHERE studentid=p_studentid;
 15  IF v_check=0 THEN
 16  RAISE_APPLICATION_ERROR(-20101,'Sinh vien '||p_studentid||' khong
 17  ton tai!');
 18  END IF;
 19  
 20  SELECT COUNT(*) INTO v_check FROM class WHERE classid=p_classid;
 21  IF v_check=0 THEN
 22  RAISE_APPLICATION_ERROR(-20102,'Lop hoc '||p_classid||' khong ton
 23  tai!');
 24  END IF;
 25  
 26  SELECT capacity INTO v_cap FROM class WHERE classid=p_classid;
 27  SELECT COUNT(*) INTO v_enr FROM enrollment WHERE classid=p_classid;
 28  IF v_enr>=v_cap THEN
 29  RAISE_APPLICATION_ERROR(-20103,'Lop '||p_classid||' da day
 30  ('||v_enr||'/'||v_cap||')!');
 31  END IF;
 32  
 33  SELECT COUNT(*) INTO v_check FROM enrollment
 34  WHERE studentid=p_studentid AND classid=p_classid;
 35  IF v_check>0 THEN
 36  RAISE_APPLICATION_ERROR(-20104,'SV '||p_studentid||' da dang ky lop
 37  nay roi!');
 38  END IF;
 39  
 40  DBMS_OUTPUT.PUT_LINE('[OK] Tat ca dieu kien deu thoa man!');
 41  EXCEPTION
 42  WHEN ex_sv_not_found THEN DBMS_OUTPUT.PUT_LINE('[KHONG TON TAI]
 43  '||SQLERRM);
 44  WHEN ex_class_not_found THEN DBMS_OUTPUT.PUT_LINE('[LOP SAI]
 45  '||SQLERRM);
 46  WHEN ex_class_full THEN DBMS_OUTPUT.PUT_LINE('[DAY LOP]
 47  '||SQLERRM);
 48  WHEN ex_already_enrolled THEN DBMS_OUTPUT.PUT_LINE('[TRUNG LAP]
 49  '||SQLERRM);
 50  WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE('[LOI KHAC] '||SQLERRM);
 51  END validate_enrollment;
 52  /

Procedure created.

SQL> CREATE OR REPLACE PROCEDURE calc_total_prerequisite_cost
  2  (p_courseno IN NUMBER,
  3  p_total OUT NUMBER,
  4  p_depth IN NUMBER DEFAULT 0)
  5  IS
  6  v_cost NUMBER;
  7  v_prereq NUMBER;
  8  v_desc VARCHAR2(50);
  9  v_sub_total NUMBER := 0;
 10  v_indent VARCHAR2(40);
 11  BEGIN
 12  IF p_depth >= 10 THEN
 13  DBMS_OUTPUT.PUT_LINE('CANH BAO: Dat gioi han do sau (10)!');
 14  p_total := 0; RETURN;
 15  END IF;
 16  
 17  BEGIN
 18  SELECT cost, prerequisite, description
 19  INTO v_cost, v_prereq, v_desc
 20  FROM course WHERE courseno=p_courseno;
 21  EXCEPTION
 22  WHEN NO_DATA_FOUND THEN
 23  p_total:=0; RETURN;
 24  END;
 25  
 26  v_indent := LPAD(' ', p_depth*4);
 27  IF v_prereq IS NOT NULL THEN
 28  calc_total_prerequisite_cost(v_prereq, v_sub_total, p_depth+1);
 29  END IF;
 30  
 31  p_total := NVL(v_cost,0) + v_sub_total;
 32  DBMS_OUTPUT.PUT_LINE(v_indent||'Cap '||p_depth||': '||p_courseno
 33  ||' - '||v_desc||' (phi: '||NVL(v_cost,0)||')');
 34  END calc_total_prerequisite_cost;
 35  /

Procedure created.

SQL> 
SQL> -- Kiem tra:
SQL> DECLARE v_total NUMBER;
  2  BEGIN
  3  calc_total_prerequisite_cost(30, v_total);
  4  DBMS_OUTPUT.PUT_LINE('Tong hoc phi can thiet: ' || v_total);
  5  END; /
  6  /
END; /
     *
ERROR at line 5:
ORA-06550: line 5, column 6: 
PLS-00103: Encountered the symbol "/" The symbol "/" was ignored. 


SQL> DECLARE v_total NUMBER;
  2  BEGIN
  3  calc_total_prerequisite_cost(30, v_total);
  4  DBMS_OUTPUT.PUT_LINE('Tong hoc phi can thiet: ' || v_total);
  5  END;
  6  /
Tong hoc phi can thiet: 0                                                       

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE PACKAGE pkg_student_mgmt AS
  2  c_max_classes CONSTANT NUMBER := 3;
  3  PROCEDURE enroll(p_sid NUMBER, p_cid NUMBER);
  4  PROCEDURE withdraw(p_sid NUMBER, p_cid NUMBER);
  5  FUNCTION get_student_gpa(p_sid NUMBER) RETURN NUMBER;
  6  PROCEDURE print_transcript(p_sid NUMBER);
  7  FUNCTION count_enrolled(p_sid NUMBER) RETURN NUMBER;
  8  END pkg_student_mgmt;
  9  /

Package created.

SQL> CREATE OR REPLACE PACKAGE BODY pkg_student_mgmt AS
  2  -- Bien noi bo: dem so lan goi
  3  g_call_count NUMBER := 0;
  4  FUNCTION count_enrolled(p_sid NUMBER) RETURN NUMBER IS
  5  v_cnt NUMBER;
  6  BEGIN
  7  SELECT COUNT(*) INTO v_cnt FROM enrollment WHERE studentid=p_sid;
  8  RETURN v_cnt;
  9  END;
 10  PROCEDURE enroll(p_sid NUMBER, p_cid NUMBER) IS
 11  v_check NUMBER; v_cap NUMBER; v_enr NUMBER;
 12  BEGIN
 13  g_call_count := g_call_count + 1;
 14  SELECT COUNT(*) INTO v_check FROM student WHERE studentid=p_sid;
 15  IF v_check=0 THEN DBMS_OUTPUT.PUT_LINE('[LOI] SV khong ton tai');
 16  RETURN; END IF;
 17  SELECT COUNT(*) INTO v_check FROM class WHERE classid=p_cid;
 18  IF v_check=0 THEN DBMS_OUTPUT.PUT_LINE('[LOI] Lop khong ton tai');
 19  RETURN; END IF;
 20  IF count_enrolled(p_sid) >= c_max_classes THEN
 21  DBMS_OUTPUT.PUT_LINE('[LOI] SV da du '||c_max_classes||' lop');
 22  RETURN;
 23  END IF;
 24  SELECT capacity INTO v_cap FROM class WHERE classid=p_cid;
 25  SELECT COUNT(*) INTO v_enr FROM enrollment WHERE classid=p_cid;
 26  IF v_enr>=v_cap THEN DBMS_OUTPUT.PUT_LINE('[LOI] Lop day'); RETURN;
 27  END IF;
 28  INSERT INTO
 29  enrollment(studentid,classid,enrolldate,createdby,createddate,modifiedby,mo
 30  difieddate)
 31  VALUES(p_sid,p_cid,SYSDATE,USER,SYSDATE,USER,SYSDATE);
 32  COMMIT;
 33  DBMS_OUTPUT.PUT_LINE('[OK] Dang ky: SV '||p_sid||' -> Lop
 34  '||p_cid);
 35  END enroll;
 36  PROCEDURE withdraw(p_sid NUMBER, p_cid NUMBER) IS
 37  v_check NUMBER;
 38  BEGIN
 39  SELECT COUNT(*) INTO v_check FROM enrollment
 40  WHERE studentid=p_sid AND classid=p_cid;
 41  IF v_check=0 THEN DBMS_OUTPUT.PUT_LINE('[LOI] SV chua dang ky lop
 42  nay'); RETURN; END IF;
 43  DELETE FROM enrollment WHERE studentid=p_sid AND classid=p_cid;
 44  COMMIT;
 45  DBMS_OUTPUT.PUT_LINE('[OK] Da huy dang ky: SV '||p_sid||' khoi Lop
 46  '||p_cid);
 47  END withdraw;
 48  FUNCTION get_student_gpa(p_sid NUMBER) RETURN NUMBER IS
 49  v_gpa NUMBER; v_check NUMBER;
 50  BEGIN
 51  SELECT COUNT(*) INTO v_check FROM student WHERE studentid=p_sid;
 52  IF v_check=0 THEN RETURN NULL; END IF;
 53  SELECT ROUND(AVG(finalgrade),2) INTO v_gpa
 54  FROM enrollment WHERE studentid=p_sid AND finalgrade IS NOT NULL;
 55  RETURN v_gpa;
 56  END;
 57  PROCEDURE print_transcript(p_sid NUMBER) IS
 58  BEGIN
 59  DBMS_OUTPUT.PUT_LINE('=== BANG DIEM SV: '||p_sid||' ===');
 60  FOR rec IN (
 61  SELECT co.description, co.courseno, e.finalgrade,
 62  cl.classid
 63  FROM enrollment e
 64  JOIN class cl ON e.classid=cl.classid
 65  JOIN course co ON cl.courseno=co.courseno
 66  WHERE e.studentid=p_sid ORDER BY co.courseno
 67  ) LOOP
 68  DBMS_OUTPUT.PUT_LINE(' '||rec.courseno||'
 69  '||RPAD(rec.description,25)
 70  ||' : '||NVL(TO_CHAR(rec.finalgrade),'Chua
 71  co diem'));
 72  END LOOP;
 73  DBMS_OUTPUT.PUT_LINE(' GPA:
 74  '||NVL(TO_CHAR(get_student_gpa(p_sid)),'N/A'));
 75  END;
 76  END pkg_student_mgmt;
 77  /

Warning: Package Body created with compilation errors.

SQL> BEGIN
  2  pkg_student_mgmt.enroll(101, 5);
  3  pkg_student_mgmt.print_transcript(101);
  4  END;
  5  /
BEGIN
*
ERROR at line 1:
ORA-04063: package body "KTHAI.PKG_STUDENT_MGMT" has errors 
ORA-06508: PL/SQL: could not find program unit being called: 
"KTHAI.PKG_STUDENT_MGMT" 
ORA-06512: at line 2 


SQL> 
SQL> CREATE OR REPLACE PACKAGE BODY pkg_student_mgmt AS
  2  
  3  -- Bien noi bo
  4  g_call_count NUMBER := 0;
  5  
  6  FUNCTION count_enrolled(p_sid NUMBER) RETURN NUMBER IS
  7      v_cnt NUMBER;
  8  BEGIN
  9      SELECT COUNT(*) INTO v_cnt
 10      FROM enrollment
 11      WHERE studentid = p_sid;
 12      RETURN v_cnt;
 13  END;
 14  
 15  PROCEDURE enroll(p_sid NUMBER, p_cid NUMBER) IS
 16      v_check NUMBER;
 17      v_cap NUMBER;
 18      v_enr NUMBER;
 19  BEGIN
 20      g_call_count := g_call_count + 1;
 21  
 22      SELECT COUNT(*) INTO v_check FROM student WHERE studentid = p_sid;
 23      IF v_check = 0 THEN
 24          DBMS_OUTPUT.PUT_LINE('[LOI] SV khong ton tai');
 25          RETURN;
 26      END IF;
 27  
 28      SELECT COUNT(*) INTO v_check FROM class WHERE classid = p_cid;
 29      IF v_check = 0 THEN
 30          DBMS_OUTPUT.PUT_LINE('[LOI] Lop khong ton tai');
 31          RETURN;
 32      END IF;
 33  
 34      IF count_enrolled(p_sid) >= c_max_classes THEN
 35          DBMS_OUTPUT.PUT_LINE('[LOI] SV da du ' || c_max_classes || ' lop');
 36          RETURN;
 37      END IF;
 38  
 39      SELECT capacity INTO v_cap FROM class WHERE classid = p_cid;
 40      SELECT COUNT(*) INTO v_enr FROM enrollment WHERE classid = p_cid;
 41  
 42      IF v_enr >= v_cap THEN
 43          DBMS_OUTPUT.PUT_LINE('[LOI] Lop day');
 44          RETURN;
 45      END IF;
 46  
 47      INSERT INTO enrollment(
 48          studentid, classid, enrolldate,
 49          createdby, createddate, modifiedby, modifieddate
 50      )
 51      VALUES(
 52          p_sid, p_cid, SYSDATE,
 53          USER, SYSDATE, USER, SYSDATE
 54      );
 55  
 56      COMMIT;
 57  
 58      DBMS_OUTPUT.PUT_LINE('[OK] Dang ky: SV ' || p_sid || ' -> Lop ' || p_cid);
 59  END enroll;
 60  
 61  PROCEDURE withdraw(p_sid NUMBER, p_cid NUMBER) IS
 62      v_check NUMBER;
 63  BEGIN
 64      SELECT COUNT(*) INTO v_check
 65      FROM enrollment
 66      WHERE studentid = p_sid AND classid = p_cid;
 67  
 68      IF v_check = 0 THEN
 69          DBMS_OUTPUT.PUT_LINE('[LOI] SV chua dang ky lop nay');
 70          RETURN;
 71      END IF;
 72  
 73      DELETE FROM enrollment
 74      WHERE studentid = p_sid AND classid = p_cid;
 75  
 76      COMMIT;
 77  
 78      DBMS_OUTPUT.PUT_LINE('[OK] Da huy dang ky: SV ' || p_sid || ' khoi Lop ' || p_cid);
 79  END withdraw;
 80  
 81  FUNCTION get_student_gpa(p_sid NUMBER) RETURN NUMBER IS
 82      v_gpa NUMBER;
 83      v_check NUMBER;
 84  BEGIN
 85      SELECT COUNT(*) INTO v_check FROM student WHERE studentid = p_sid;
 86      IF v_check = 0 THEN RETURN NULL; END IF;
 87  
 88      SELECT ROUND(AVG(finalgrade),2) INTO v_gpa
 89      FROM enrollment
 90      WHERE studentid = p_sid AND finalgrade IS NOT NULL;
 91  
 92      RETURN v_gpa;
 93  END;
 94  
 95  PROCEDURE print_transcript(p_sid NUMBER) IS
 96  BEGIN
 97      DBMS_OUTPUT.PUT_LINE('=== BANG DIEM SV: ' || p_sid || ' ===');
 98  
 99      FOR rec IN (
100          SELECT co.description, co.courseno, e.finalgrade, cl.classid
101          FROM enrollment e
102          JOIN class cl ON e.classid = cl.classid
103          JOIN course co ON cl.courseno = co.courseno
104          WHERE e.studentid = p_sid
105          ORDER BY co.courseno
106      ) LOOP
107  
108          DBMS_OUTPUT.PUT_LINE(
109              ' ' || rec.courseno || ' ' ||
110              RPAD(rec.description,25) || ' : ' ||
111              NVL(TO_CHAR(rec.finalgrade),'Chua co diem')
112          );
113  
114      END LOOP;
115  
116      DBMS_OUTPUT.PUT_LINE(
117          ' GPA: ' || NVL(TO_CHAR(get_student_gpa(p_sid)),'N/A')
118      );
119  END;
120  
121  END pkg_student_mgmt;
122  /

Package body created.

SQL> BEGIN
  2  pkg_student_mgmt.enroll(101, 5);
  3  pkg_student_mgmt.print_transcript(101);
  4  END;
  5  /
[LOI] SV da du 3 lop                                                            
=== BANG DIEM SV: 101 ===                                                       
1 Co so du lieu             : 90                                                
2 He quan tri CSDL          : 80                                                
3 Java                      : 70                                                
GPA: 80                                                                         

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE PROCEDURE bulk_update_grades IS
  2  TYPE t_num IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
  3  v_sids t_num;
  4  v_cids t_num;
  5  v_grades t_num;
  6  v_start NUMBER;
  7  v_end NUMBER;
  8  v_rows NUMBER := 0;
  9  BEGIN
 10  v_start := DBMS_UTILITY.GET_TIME;
 11  -- Doc du lieu vao mang nhanh
 12  SELECT studentid, classid, finalgrade
 13  BULK COLLECT INTO v_sids, v_cids, v_grades
 14  FROM enrollment WHERE finalgrade IS NOT NULL;
 15  DBMS_OUTPUT.PUT_LINE('Doc duoc '||v_sids.COUNT||' ban ghi...');
 16  -- Cap nhat hang loat vao GRADE (MERGE thay the INSERT+UPDATE)
 17  FORALL i IN 1..v_sids.COUNT SAVE EXCEPTIONS
 18  MERGE INTO grade g
 19  USING (SELECT v_sids(i) AS sid, v_cids(i) AS cid,
 20  v_grades(i) AS gr FROM DUAL) src
 21  ON (g.studentid=src.sid AND g.classid=src.cid)
 22  WHEN MATCHED THEN
 23  UPDATE SET g.grade=src.gr, g.modifiedby=USER,
 24  g.modifieddate=SYSDATE
 25  WHEN NOT MATCHED THEN
 26  INSERT
 27  (studentid,classid,grade,createdby,createddate,modifiedby,modifieddate)
 28  VALUES (src.sid,src.cid,src.gr,USER,SYSDATE,USER,SYSDATE);
 29  
 30  v_rows := SQL%ROWCOUNT;
 31  COMMIT;
 32  
 33  v_end := DBMS_UTILITY.GET_TIME;
 34  DBMS_OUTPUT.PUT_LINE('Xu ly: '||v_rows||' hang | Thoi gian: '
 35  ||ROUND((v_end-v_start)/100,2)||' giay');
 36  EXCEPTION
 37  WHEN OTHERS THEN
 38  FOR j IN 1..SQL%BULK_EXCEPTIONS.COUNT LOOP
 39  DBMS_OUTPUT.PUT_LINE('Loi hang
 40  '||SQL%BULK_EXCEPTIONS(j).ERROR_INDEX
 41  ||': '||SQLERRM(-SQL%BULK_EXCEPTIONS(j).ERROR_CODE));
 42  END LOOP;
 43  ROLLBACK;
 44  END bulk_update_grades;
 45  /

Procedure created.

SQL> BEGIN bulk_update_grades; END;
  2  /
Doc duoc 22 ban ghi...                                                          
Xu ly: 22 hang | Thoi gian: .01 giay                                            

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE PROCEDURE generate_course_report
  2  (p_courseno IN NUMBER)
  3  IS
  4  v_check NUMBER; v_desc VARCHAR2(50);
  5  v_cost NUMBER; v_prereq NUMBER;
  6  v_tong_sv NUMBER:=0; v_sum_d NUMBER:=0; v_co_d NUMBER:=0;
  7  v_sep VARCHAR2(70) := RPAD('=',60,'=');
  8  v_sep2 VARCHAR2(70) := RPAD('-',60,'-');
  9  BEGIN
 10  SELECT COUNT(*) INTO v_check FROM course WHERE courseno=p_courseno;
 11  IF v_check=0 THEN
 12  DBMS_OUTPUT.PUT_LINE('Mon hoc '||p_courseno||' khong ton tai!');
 13  RETURN;
 14  END IF;
 15  SELECT description, cost, prerequisite INTO v_desc, v_cost, v_prereq
 16  FROM course WHERE courseno=p_courseno;
 17  DBMS_OUTPUT.PUT_LINE(v_sep);
 18  DBMS_OUTPUT.PUT_LINE('BAO CAO MON HOC: '||p_courseno);
 19  DBMS_OUTPUT.PUT_LINE(v_sep2);
 20  DBMS_OUTPUT.PUT_LINE('Ten mon : '||v_desc);
 21  DBMS_OUTPUT.PUT_LINE('Hoc phi :
 22  '||TO_CHAR(NVL(v_cost,0),'999,990.00')||' VND');
 23  DBMS_OUTPUT.PUT_LINE('Mon tien q: '||NVL(TO_CHAR(v_prereq),'Khong
 24  co'));
 25  DBMS_OUTPUT.PUT_LINE(v_sep2);
 26  DBMS_OUTPUT.PUT_LINE(RPAD('Lop',5)||RPAD('Giao vien',20)
 27  ||LPAD('SVDK',6)||LPAD('DTB',7)||' Trang thai');
 28  DBMS_OUTPUT.PUT_LINE(v_sep2);
 29  FOR rec IN (
 30  SELECT cl.classid, cl.capacity,
 31  i.firstname||' '||i.lastname AS ten_gv,
 32  COUNT(e.studentid) AS so_sv,
 33  ROUND(AVG(e.finalgrade),1) AS dtb
 34  FROM class cl
 35  JOIN instructor i ON cl.instructorid=i.instructorid
 36  LEFT JOIN enrollment e ON cl.classid=e.classid
 37  WHERE cl.courseno=p_courseno
 38  GROUP BY cl.classid,cl.capacity,i.firstname,i.lastname
 39  ORDER BY cl.classid
 40  ) LOOP
 41  v_tong_sv := v_tong_sv + rec.so_sv;
 42  IF rec.dtb IS NOT NULL THEN
 43  v_sum_d:=v_sum_d+rec.dtb; v_co_d:=v_co_d+1;
 44  END IF;
 45  DBMS_OUTPUT.PUT_LINE(
 46  LPAD(rec.classid,4)||' '||RPAD(rec.ten_gv,20)
 47  ||LPAD(rec.so_sv,5)||LPAD(NVL(TO_CHAR(rec.dtb),'--'),7)
 48  ||' '||CASE WHEN rec.capacity-rec.so_sv>0
 49  THEN 'Con '||(rec.capacity-rec.so_sv)||' cho'
 50  
 51  ELSE 'Het cho' END);
 52  
 53  END LOOP;
 54  DBMS_OUTPUT.PUT_LINE(v_sep2);
 55  DBMS_OUTPUT.PUT_LINE('Tong SV dang ky : '||v_tong_sv);
 56  IF v_co_d>0 THEN
 57  DBMS_OUTPUT.PUT_LINE('Diem TB toan mon:
 58  '||ROUND(v_sum_d/v_co_d,2));
 59  END IF;
 60  DBMS_OUTPUT.PUT_LINE(v_sep);
 61  END generate_course_report;
 62  /

Procedure created.

SQL> BEGIN generate_course_report(10); END;
  2  /
============================================================                    
BAO CAO MON HOC: 10                                                             
------------------------------------------------------------                    
Ten mon : React                                                                 
Hoc phi :
     220.00 VND                                                       
Mon tien q: Khong
co                                                            
------------------------------------------------------------                    
Lop  Giao vien             SVDK    DTB Trang thai                               
------------------------------------------------------------                    
10 Phong Ngo               1     91 Con 29 cho                                  
------------------------------------------------------------                    
Tong SV dang ky : 1                                                             
Diem TB toan mon:
91                                                            
============================================================                    

PL/SQL procedure successfully completed.

SQL> CREATE OR REPLACE FUNCTION convert_to_gpa_40
  2  (p_studentid IN NUMBER) RETURN NUMBER
  3  IS
  4  v_check NUMBER; v_gpa NUMBER;
  5  BEGIN
  6  SELECT COUNT(*) INTO v_check FROM student WHERE studentid=p_studentid;
  7  IF v_check=0 THEN RETURN NULL; END IF;
  8  SELECT ROUND(
  9  SUM(CASE
 10  WHEN finalgrade>=90 THEN 4.0
 11  WHEN finalgrade>=85 THEN 3.7
 12  WHEN finalgrade>=80 THEN 3.3
 13  WHEN finalgrade>=75 THEN 3.0
 14  WHEN finalgrade>=70 THEN 2.7
 15  WHEN finalgrade>=65 THEN 2.3
 16  WHEN finalgrade>=60 THEN 2.0
 17  WHEN finalgrade>=50 THEN 1.0
 18  ELSE 0.0
 19  END * 3) / -- So tin chi = 3
 20  NULLIF(SUM(CASE WHEN finalgrade IS NOT NULL THEN 3 ELSE 0 END), 0)
 21  , 2) INTO v_gpa
 22  FROM enrollment WHERE studentid=p_studentid;
 23  RETURN v_gpa;
 24  END convert_to_gpa_40;
 25  /

Function created.

SQL> 
SQL> CREATE OR REPLACE PROCEDURE print_gpa_report IS
  2  BEGIN
  3  DBMS_OUTPUT.PUT_LINE(RPAD('StudentID',12)||RPAD('Ho Ten',25)||LPAD('GPA
  4  (4.0)',10));
  5  DBMS_OUTPUT.PUT_LINE(RPAD('-',48,'-'));
  6  FOR rec IN (
  7  SELECT studentid, firstname||' '||lastname AS ho_ten
  8  FROM student ORDER BY studentid
  9  ) LOOP
 10  DECLARE v_gpa NUMBER;
 11  BEGIN
 12  v_gpa := convert_to_gpa_40(rec.studentid);
 13  IF v_gpa IS NOT NULL THEN
 14  DBMS_OUTPUT.PUT_LINE(
 15  LPAD(rec.studentid,10)||' '||RPAD(rec.ho_ten,25)
 16  ||LPAD(v_gpa,9));
 17  END IF;
 18  END;
 19  END LOOP;
 20  END print_gpa_report;
 21  /

Procedure created.

SQL> BEGIN print_gpa_report; END;
  2  /
StudentID   Ho Ten                    GPA
(4.0)                                 
------------------------------------------------                                
101 An Nguyen                     3.33                                          
102 Binh Tran                        2                                          
103 Cuong Le                         1                                          
104 Dung Pham                      3.7                                          
105 Hieu Hoang                       3                                          
106 Khanh Vo                       2.3                                          
107 Linh Dang                        4                                          
108 Minh Bui                       3.7                                          
109 Nam Do                           3                                          
110 Phong Ngo                      2.3                                          
111 Quang Ly                         4                                          
112 Son Vu                         3.3                                          
113 Tuan Phan                      2.7                                          
114 Viet Huynh                       2                                          
115 Anh Nguyen                       1                                          
116 Bao Tran                       3.7                                          
117 Chau Le                          3                                          
118 Duc Pham                       2.3                                          
119 Giang Hoang                      4                                          
120 Hung Vo                        3.7                                          

PL/SQL procedure successfully completed.

SQL> CREATE TABLE notification_log (
  2  log_id NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  3  nguoi_nhan VARCHAR2(50),
  4  noi_dung VARCHAR2(500),
  5  loai VARCHAR2(20),
  6  thoi_gian DATE DEFAULT SYSDATE,
  7  trang_thai VARCHAR2(10) DEFAULT 'SENT'
  8  );

Table created.

SQL> /
CREATE TABLE notification_log (
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> CREATE OR REPLACE PROCEDURE log_notification
  2  (p_nguoi_nhan VARCHAR2,
  3  p_noi_dung VARCHAR2,
  4  p_loai VARCHAR2 DEFAULT 'INFO')
  5  IS
  6  PRAGMA AUTONOMOUS_TRANSACTION; -- Doc lap khoi transaction cha
  7  BEGIN
  8  INSERT INTO notification_log (nguoi_nhan, noi_dung, loai)
  9  VALUES (p_nguoi_nhan, SUBSTR(p_noi_dung,1,500), p_loai);
 10  COMMIT; -- Commit ngay, khong phu thuoc transaction cha
 11  EXCEPTION
 12  WHEN OTHERS THEN
 13  ROLLBACK; -- Chi rollback autonomous transaction nay
 14  END log_notification;
 15  /

Procedure created.

SQL> -- Kiem tra tinh doc lap:
SQL> BEGIN
  2  INSERT INTO student(studentid,lastname,registrationdate,
  3  createdby,createddate,modifiedby,modifieddate)
  4  VALUES (9999,'Test',SYSDATE,USER,SYSDATE,USER,SYSDATE);
  5  log_notification('Admin','Da them SV 9999','ENROLL');
  6  ROLLBACK; -- Rollback INSERT student, nhung log van con!
  7  END;
  8  /

PL/SQL procedure successfully completed.

SQL> SELECT * FROM notification_log; -- Ban ghi log van con du da ROLLBACK
  2  
SQL> ALTER TABLE class ADD so_sv NUMBER DEFAULT 0;

Table altered.

SQL> CREATE OR REPLACE TRIGGER trg_update_class_count
  2  FOR INSERT OR UPDATE OR DELETE ON enrollment
  3  COMPOUND TRIGGER
  4  TYPE t_ids IS TABLE OF NUMBER INDEX BY PLS_INTEGER;
  5  v_ids t_ids;
  6  v_idx PLS_INTEGER := 0;
  7  BEFORE STATEMENT IS
  8  BEGIN
  9  v_idx := 0;
 10  v_ids.DELETE;
 11  END BEFORE STATEMENT;
 12  AFTER EACH ROW IS
 13  BEGIN
 14  v_idx := v_idx + 1;
 15  v_ids(v_idx) := CASE
 16  WHEN INSERTING OR UPDATING THEN :NEW.classid
 17  ELSE :OLD.classid
 18  END;
 19  END AFTER EACH ROW;
 20  AFTER STATEMENT IS
 21  BEGIN
 22  FOR i IN 1..v_idx LOOP
 23  UPDATE class
 24  SET so_sv = (SELECT COUNT(*) FROM enrollment
 25  WHERE classid = v_ids(i))
 26  WHERE classid = v_ids(i);
 27  END LOOP;
 28  END AFTER STATEMENT;
 29  END trg_update_class_count;
 30  /

Trigger created.

SQL> -- Kiem tra:
SQL> INSERT INTO enrollment(studentid,classid,enrolldate,createdby,
  2  createddate,modifiedby,modifieddate)
  3  VALUES(101,1,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO enrollment(studentid,classid,enrolldate,createdby,
*
ERROR at line 1:
ORA-01400: cannot insert NULL into ("KTHAI"."ENROLLMENT"."REGISTRATIONDATE") 


SQL> COMMIT;

Commit complete.

SQL> SELECT classid, so_sv FROM class WHERE classid=1;

   CLASSID      SO_SV                                                           
---------- ----------                                                           
         1          0                                                           

SQL> CREATE OR REPLACE VIEW vw_class_enrollment_detail AS
  2  SELECT e.classid, e.studentid,
  3  s.firstname||' '||s.lastname AS ten_sv,
  4  co.description AS ten_mon,
  5  e.finalgrade,
  6  i.firstname||' '||i.lastname AS ten_gv
  7  FROM enrollment e
  8  JOIN student s ON e.studentid=s.studentid
  9  JOIN class cl ON e.classid=cl.classid
 10  JOIN course co ON cl.courseno=co.courseno
 11  JOIN instructor i ON cl.instructorid=i.instructorid;

View created.

SQL> CREATE OR REPLACE TRIGGER trg_iot_update_grade
  2  INSTEAD OF UPDATE ON vw_class_enrollment_detail
  3  FOR EACH ROW
  4  DECLARE
  5  v_old_grade NUMBER;
  6  BEGIN
  7  IF :NEW.finalgrade IS NOT NULL AND
  8  (:NEW.finalgrade < 0 OR :NEW.finalgrade > 100) THEN
  9  RAISE_APPLICATION_ERROR(-20060,'Diem khong hop le (0-100)!');
 10  END IF;
 11  SELECT finalgrade INTO v_old_grade FROM enrollment
 12  WHERE studentid=:OLD.studentid AND classid=:OLD.classid;
 13  UPDATE enrollment
 14  SET finalgrade=:NEW.finalgrade,
 15  modifiedby=USER, modifieddate=SYSDATE
 16  WHERE studentid=:OLD.studentid AND classid=:OLD.classid;
 17  MERGE INTO grade g
 18  USING (SELECT :OLD.studentid AS sid, :OLD.classid AS cid FROM DUAL) src
 19  ON (g.studentid=src.sid AND g.classid=src.cid)
 20  WHEN MATCHED THEN
 21  UPDATE SET g.grade=:NEW.finalgrade,
 22  g.modifiedby=USER, g.modifieddate=SYSDATE
 23  WHEN NOT MATCHED THEN
 24  INSERT
 25  (studentid,classid,grade,createdby,createddate,modifiedby,modifieddate)
 26  VALUES (:OLD.studentid,:OLD.classid,:NEW.finalgrade,
 27  USER,SYSDATE,USER,SYSDATE);
 28  log_notification('System',
 29  'Cap nhat diem SV '||:OLD.studentid||' lop '||:OLD.classid
 30  ||': '||NVL(TO_CHAR(v_old_grade),'NULL')||'->'||:NEW.finalgrade,
 31  'GRADE');
 32  END trg_iot_update_grade;
 33  /

Trigger created.

SQL> -- Kiem tra:
SQL> UPDATE vw_class_enrollment_detail SET finalgrade=88
  2  WHERE studentid=101 AND classid=1;

1 row updated.

SQL> COMMIT;

Commit complete.

SQL> CREATE TABLE ddl_audit_log (
  2  log_id NUMBER GENERATED ALWAYS AS IDENTITY,
  3  event_type VARCHAR2(30),
  4  object_type VARCHAR2(30),
  5  object_name VARCHAR2(128),
  6  owner VARCHAR2(30),
  7  event_time DATE,
  8  current_usr VARCHAR2(30)
  9  );

Table created.

SQL> /
CREATE TABLE ddl_audit_log (
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> CREATE OR REPLACE TRIGGER trg_ddl_audit
  2  AFTER DDL ON SCHEMA
  3  DECLARE
  4  PRAGMA AUTONOMOUS_TRANSACTION;
  5  BEGIN
  6  INSERT INTO ddl_audit_log
  7  (event_type, object_type, object_name, owner, event_time,
  8  current_usr)
  9  VALUES
 10  (ORA_SYSEVENT,
 11  ORA_DICT_OBJ_TYPE,
 12  ORA_DICT_OBJ_NAME,
 13  ORA_DICT_OBJ_OWNER,
 14  SYSDATE,
 15  ORA_LOGIN_USER);
 16  COMMIT;
 17  EXCEPTION
 18  WHEN OTHERS THEN ROLLBACK;
 19  END trg_ddl_audit;
 20  /

Trigger created.

SQL> -- Kiem tra:
SQL> CREATE TABLE test_ddl_track (id NUMBER);

Table created.

SQL> DROP TABLE test_ddl_track;

Table dropped.

SQL> SELECT * FROM ddl_audit_log ORDER BY log_id DESC;

    LOG_ID EVENT_TYPE                     OBJECT_TYPE                           
---------- ------------------------------ ------------------------------        
OBJECT_NAME                                                                     
--------------------------------------------------------------------------------
OWNER                          EVENT_TIM CURRENT_USR                            
------------------------------ --------- ------------------------------         
         2 DROP                           TABLE                                 
TEST_DDL_TRACK                                                                  
KTHAI                          04-MAY-26 KTHAI                                  
                                                                                
         1 CREATE                         TABLE                                 
TEST_DDL_TRACK                                                                  
KTHAI                          04-MAY-26 KTHAI                                  

    LOG_ID EVENT_TYPE                     OBJECT_TYPE                           
---------- ------------------------------ ------------------------------        
OBJECT_NAME                                                                     
--------------------------------------------------------------------------------
OWNER                          EVENT_TIM CURRENT_USR                            
------------------------------ --------- ------------------------------         
                                                                                

SQL> -- Trigger 1: BEFORE DELETE tren STUDENT - Kiem tra
SQL> CREATE OR REPLACE TRIGGER trg_prevent_student_delete
  2  BEFORE DELETE ON student FOR EACH ROW
  3  DECLARE v_count NUMBER;
  4  BEGIN
  5  SELECT COUNT(*) INTO v_count FROM enrollment WHERE
  6  studentid=:OLD.studentid;
  7  IF v_count>0 THEN
  8  RAISE_APPLICATION_ERROR(-20030,
  9  'Khong the xoa SV '||:OLD.studentid||
 10  ' dang co '||v_count||' lop dang ky! Huy dang ky truoc.');
 11  END IF;
 12  END;
 13  /

Trigger created.

SQL> -- Trigger 2: AFTER DELETE tren STUDENT - Cascade xoa GRADE
SQL> CREATE OR REPLACE TRIGGER trg_cascade_delete_grade
  2  AFTER DELETE ON student FOR EACH ROW
  3  BEGIN
  4  DELETE FROM grade WHERE studentid=:OLD.studentid;
  5  DBMS_OUTPUT.PUT_LINE('Da xoa '||SQL%ROWCOUNT||' ban ghi GRADE cua SV
  6  '||:OLD.studentid);
  7  END;
  8  /

Trigger created.

SQL> -- Trigger 3: AFTER DELETE tren ENROLLMENT - Cap nhat so_sv trong CLASS
SQL> -- (Compound Trigger o cau 3.1 da xu ly dieu nay!)
SQL> -- Neu chua co compound trigger, viet them:
SQL> CREATE OR REPLACE TRIGGER trg_update_count_on_delete
  2  AFTER DELETE ON enrollment FOR EACH ROW
  3  BEGIN
  4  UPDATE class SET so_sv=so_sv-1 WHERE classid=:OLD.classid AND so_sv>0;
  5  END;
  6  /

Trigger created.

SQL> -- Kiem tra chuoi trigger:
SQL> -- Thu xoa SV co enrollment (bi chan):
SQL> DELETE FROM student WHERE studentid=101;
DELETE FROM student WHERE studentid=101
            *
ERROR at line 1:
ORA-20030: Khong the xoa SV 101 dang co 3 lop dang ky! Huy dang ky truoc. 
ORA-06512: at "KTHAI.TRG_PREVENT_STUDENT_DELETE", line 6 
ORA-04088: error during execution of trigger 'KTHAI.TRG_PREVENT_STUDENT_DELETE' 


SQL> -- Xoa enrollment truoc, sau do xoa SV (thanh cong):
SQL> DELETE FROM enrollment WHERE studentid=101;

3 rows deleted.

SQL> DELETE FROM student WHERE studentid=101;
Da xoa 3 ban ghi GRADE cua SV
101                                               

1 row deleted.

SQL> ROLLBACK;

Rollback complete.

SQL> CREATE TABLE certificate (
  2  cert_id NUMBER GENERATED ALWAYS AS IDENTITY,
  3  studentid NUMBER(8),
  4  courseno NUMBER(8),
  5  cap_cc DATE,
  6  loai VARCHAR2(20)
  7  );

Table created.

SQL> /
CREATE TABLE certificate (
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> CREATE OR REPLACE TRIGGER trg_auto_certificate
  2  AFTER UPDATE OF finalgrade ON enrollment
  3  FOR EACH ROW
  4  WHEN (NEW.finalgrade >= 50) -- Chi chay khi diem >= 50
  5  DECLARE
  6  v_courseno NUMBER;
  7  v_check NUMBER;
  8  v_loai VARCHAR2(20);
  9  v_ten_sv VARCHAR2(50);
 10  v_ten_mon VARCHAR2(50);
 11  BEGIN
 12  -- Lay thong tin
 13  SELECT cl.courseno, co.description, s.firstname||' '||s.lastname
 14  INTO v_courseno, v_ten_mon, v_ten_sv
 15  FROM class cl JOIN course co ON cl.courseno=co.courseno
 16  JOIN student s ON s.studentid=:NEW.studentid
 17  WHERE cl.classid=:NEW.classid;
 18  -- Kiem tra da co chung chi chua
 19  SELECT COUNT(*) INTO v_check FROM certificate
 20  WHERE studentid=:NEW.studentid AND courseno=v_courseno;
 21  IF v_check>0 THEN RETURN; END IF; -- Da co roi, bo qua
 22  -- Xac dinh loai chung chi
 23  v_loai := CASE
 24  WHEN :NEW.finalgrade >= 90 THEN 'HIGH_DISTINCTION'
 25  WHEN :NEW.finalgrade >= 75 THEN 'DISTINCTION'
 26  ELSE 'PASS'
 27  END;
 28  -- Cap chung chi
 29  INSERT INTO certificate (studentid, courseno, cap_cc, loai)
 30  VALUES (:NEW.studentid, v_courseno, SYSDATE, v_loai);
 31  DBMS_OUTPUT.PUT_LINE('Chuc mung '||v_ten_sv||' da hoan thanh mon '
 32  ||v_ten_mon||' voi '||v_loai||'!');
 33  END trg_auto_certificate;
 34  /

Trigger created.

SQL> -- Kiem tra:
SQL> UPDATE enrollment SET finalgrade=92 WHERE studentid=101 AND classid=1;
Chuc mung An Nguyen da hoan thanh mon Co so du lieu voi HIGH_DISTINCTION!       

1 row updated.

SQL> COMMIT;

Commit complete.

SQL> SELECT * FROM certificate;

   CERT_ID  STUDENTID   COURSENO CAP_CC    LOAI                                 
---------- ---------- ---------- --------- --------------------                 
         1        101          1 04-MAY-26 HIGH_DISTINCTION                     

SQL> CREATE OR REPLACE VIEW vw_enrollment_dashboard AS
  2  SELECT
  3  (SELECT COUNT(*) FROM class) AS so_lop_mo,
  4  (SELECT SUM(cl.capacity-NVL(ec.sv,0))
  5  FROM class cl
  6  LEFT JOIN (SELECT classid,COUNT(*) sv FROM enrollment GROUP BY
  7  classid) ec
  8  ON cl.classid=ec.classid) AS
  9  tong_cho_trong,
 10  ROUND(
 11  (SELECT COUNT(*) FROM enrollment)*100.0/
 12  NULLIF((SELECT SUM(capacity) FROM class),0)
 13  ,1) AS
 14  ty_le_lap_day_pct,
 15  (SELECT classid||' ('||sv||' SV)'
 16  FROM (SELECT classid, COUNT(*) sv FROM enrollment GROUP BY classid
 17  ORDER BY sv DESC FETCH FIRST 1 ROW ONLY)) AS
 18  lop_dong_nhat,
 19  (SELECT classid||' ('||sv||' SV)'
 20  FROM (SELECT classid, COUNT(*) sv FROM enrollment GROUP BY classid
 21  ORDER BY sv ASC FETCH FIRST 1 ROW ONLY)) AS lop_it_nhat
 22  FROM DUAL;

View created.

SQL> SELECT * FROM vw_enrollment_dashboard;

 SO_LOP_MO TONG_CHO_TRONG TY_LE_LAP_DAY_PCT                                     
---------- -------------- -----------------                                     
LOP_DONG_NHAT                                                                   
--------------------------------------------------------------------------------
LOP_IT_NHAT                                                                     
--------------------------------------------------------------------------------
        20            578               3.7                                     
1 (2 SV)                                                                        
4 (1 SV)                                                                        
                                                                                

SQL> Package pkg_enrollment_system (r�t g?n ph?n ch�nh):
SP2-0734: unknown command beginning "Package pk..." - rest of line ignored.
SQL> CREATE OR REPLACE PACKAGE pkg_enrollment_system AS
  2  FUNCTION is_eligible(p_sid NUMBER, p_cid NUMBER) RETURN BOOLEAN;
  3  PROCEDURE do_enroll(p_sid NUMBER, p_cid NUMBER);
  4  PROCEDURE do_withdraw(p_sid NUMBER, p_cid NUMBER);
  5  FUNCTION get_waitlist_position(p_sid NUMBER, p_cid NUMBER) RETURN
  6  NUMBER;
  7  END pkg_enrollment_system;
  8  /

Package created.

SQL> CREATE OR REPLACE PACKAGE BODY pkg_enrollment_system AS
  2  FUNCTION is_eligible(p_sid NUMBER, p_cid NUMBER) RETURN BOOLEAN IS
  3  v_sv NUMBER; v_cl NUMBER; v_cap NUMBER; v_enr NUMBER; v_dup NUMBER;
  4  BEGIN
  5  SELECT COUNT(*) INTO v_sv FROM student WHERE studentid=p_sid;
  6  IF v_sv=0 THEN RETURN FALSE; END IF;
  7  SELECT COUNT(*) INTO v_cl FROM class WHERE classid=p_cid;
  8  IF v_cl=0 THEN RETURN FALSE; END IF;
  9  SELECT capacity INTO v_cap FROM class WHERE classid=p_cid;
 10  SELECT COUNT(*) INTO v_enr FROM enrollment WHERE classid=p_cid;
 11  IF v_enr>=v_cap THEN RETURN FALSE; END IF;
 12  SELECT COUNT(*) INTO v_dup FROM enrollment
 13  WHERE studentid=p_sid AND classid=p_cid;
 14  IF v_dup>0 THEN RETURN FALSE; END IF;
 15  SELECT COUNT(*) INTO v_enr FROM enrollment WHERE studentid=p_sid;
 16  IF v_enr>=3 THEN RETURN FALSE; END IF;
 17  RETURN TRUE;
 18  END is_eligible;
 19  PROCEDURE do_enroll(p_sid NUMBER, p_cid NUMBER) IS
 20  BEGIN
 21  IF NOT is_eligible(p_sid, p_cid) THEN
 22  DBMS_OUTPUT.PUT_LINE('[TU CHOI] Khong du dieu kien dang ky!');
 23  RETURN;
 24  END IF;
 25  INSERT INTO
 26  enrollment(studentid,classid,enrolldate,createdby,createddate,
 27  modifiedby,modifieddate)
 28  VALUES(p_sid,p_cid,SYSDATE,USER,SYSDATE,USER,SYSDATE);
 29  COMMIT;
 30  log_notification(USER,'Dang ky: SV '||p_sid||' -> Lop
 31  '||p_cid,'ENROLL');
 32  DBMS_OUTPUT.PUT_LINE('[OK] Dang ky thanh cong!');
 33  END do_enroll;
 34  PROCEDURE do_withdraw(p_sid NUMBER, p_cid NUMBER) IS
 35  v_check NUMBER;
 36  BEGIN
 37  SELECT COUNT(*) INTO v_check FROM enrollment
 38  WHERE studentid=p_sid AND classid=p_cid;
 39  IF v_check=0 THEN
 40  DBMS_OUTPUT.PUT_LINE('[LOI] SV chua dang ky lop nay!'); RETURN;
 41  END IF;
 42  DELETE FROM enrollment WHERE studentid=p_sid AND classid=p_cid;
 43  COMMIT;
 44  log_notification(USER,'Huy dk: SV '||p_sid||' khoi Lop
 45  '||p_cid,'WITHDRAW');
 46  DBMS_OUTPUT.PUT_LINE('[OK] Huy dang ky thanh cong!');
 47  END do_withdraw;
 48  FUNCTION get_waitlist_position(p_sid NUMBER, p_cid NUMBER) RETURN
 49  NUMBER IS
 50  v_cap NUMBER; v_enr NUMBER;
 51  BEGIN
 52  SELECT capacity INTO v_cap FROM class WHERE classid=p_cid;
 53  SELECT COUNT(*) INTO v_enr FROM enrollment WHERE classid=p_cid;
 54  IF v_enr < v_cap THEN RETURN 0; END IF;
 55  RETURN v_enr - v_cap + 1;
 56  END;
 57  END pkg_enrollment_system;
 58  /

Package body created.

SQL> -- Kiem tra:
SQL> BEGIN
  2  pkg_enrollment_system.do_enroll(101, 3);
  3  pkg_enrollment_system.do_enroll(999, 1); -- SV khong ton tai
  4  END;
  5  /
[TU CHOI] Khong du dieu kien dang ky!                                           
[TU CHOI] Khong du dieu kien dang ky!                                           

PL/SQL procedure successfully completed.

SQL> -- Xem execution plan cua view
SQL> EXPLAIN PLAN FOR SELECT * FROM vw_course_summary;
EXPLAIN PLAN FOR SELECT * FROM vw_course_summary
                               *
ERROR at line 1:
ORA-00942: table or view does not exist 


SQL> SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
Error: cannot fetch last explain plan from PLAN_TABLE                           

SQL> -- Tim Full Table Scan (TABLE ACCESS FULL) trong output
SQL> -- Tao INDEX tren cac cot hay dung trong JOIN/WHERE:
SQL> CREATE INDEX idx_enrollment_classid ON enrollment(classid);

Index created.

SQL> CREATE INDEX idx_enrollment_studentid ON enrollment(studentid);

Index created.

SQL> CREATE INDEX idx_class_courseno ON class(courseno);

Index created.

SQL> CREATE INDEX idx_class_instructorid ON class(instructorid);

Index created.

SQL> -- Chay lai EXPLAIN PLAN sau khi tao INDEX de so sanh
SQL> EXPLAIN PLAN FOR SELECT * FROM vw_course_summary;
EXPLAIN PLAN FOR SELECT * FROM vw_course_summary
                               *
ERROR at line 1:
ORA-00942: table or view does not exist 


SQL> SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
Error: cannot fetch last explain plan from PLAN_TABLE                           

SQL> -- Ket qua mong doi: thay 'TABLE ACCESS FULL' bang 'INDEX RANGE SCAN'
SQL> CREATE OR REPLACE VIEW vw_course_summary AS
  2  SELECT
  3      co.courseno,
  4      co.description,
  5      COUNT(cl.classid) AS so_lop,
  6      COUNT(e.studentid) AS tong_sv
  7  FROM course co
  8  LEFT JOIN class cl ON co.courseno = cl.courseno
  9  LEFT JOIN enrollment e ON cl.classid = e.classid
 10  GROUP BY co.courseno, co.description;

View created.

SQL> -- Xem execution plan cua view
SQL> EXPLAIN PLAN FOR SELECT * FROM vw_course_summary;

Explained.

SQL> SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
Plan hash value: 1597921938                                                     
                                                                                
--------------------------------------------------------------------------------
---------------------                                                           
                                                                                
| Id  | Operation                | Name                     | Rows  | Bytes | Co
st (%CPU)| Time     |                                                           
                                                                                
--------------------------------------------------------------------------------
---------------------                                                           
                                                                                

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
|   0 | SELECT STATEMENT         |                          |    23 |  2116 |   
  9  (12)| 00:00:01 |                                                           
                                                                                
|   1 |  HASH GROUP BY           |                          |    23 |  2116 |   
  9  (12)| 00:00:01 |                                                           
                                                                                
|*  2 |   HASH JOIN OUTER        |                          |    23 |  2116 |   
  8   (0)| 00:00:01 |                                                           
                                                                                
|*  3 |    HASH JOIN OUTER       |                          |    20 |  1320 |   
  6   (0)| 00:00:01 |                                                           

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
                                                                                
|   4 |     TABLE ACCESS FULL    | COURSE                   |    20 |   800 |   
  3   (0)| 00:00:01 |                                                           
                                                                                
|   5 |     TABLE ACCESS FULL    | CLASS                    |    20 |   520 |   
  3   (0)| 00:00:01 |                                                           
                                                                                
|   6 |    VIEW                  | index$_join$_005         |    22 |   572 |   
  2   (0)| 00:00:01 |                                                           
                                                                                
|*  7 |     HASH JOIN            |                          |       |       |   

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
         |          |                                                           
                                                                                
|   8 |      INDEX FAST FULL SCAN| IDX_ENROLLMENT_CLASSID   |    22 |   572 |   
  1   (0)| 00:00:01 |                                                           
                                                                                
|   9 |      INDEX FAST FULL SCAN| IDX_ENROLLMENT_STUDENTID |    22 |   572 |   
  1   (0)| 00:00:01 |                                                           
                                                                                
--------------------------------------------------------------------------------
---------------------                                                           
                                                                                

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
                                                                                
Predicate Information (identified by operation id):                             
---------------------------------------------------                             
                                                                                
   2 - access("CL"."CLASSID"="E"."CLASSID"(+))                                  
   3 - access("CO"."COURSENO"="CL"."COURSENO"(+))                               
   7 - access(ROWID=ROWID)                                                      
                                                                                
Note                                                                            
-----                                                                           
   - dynamic statistics used: dynamic sampling (level=2)                        

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
   - this is an adaptive plan                                                   

28 rows selected.

SQL> -- Tim Full Table Scan (TABLE ACCESS FULL) trong output
SQL> -- Tao INDEX tren cac cot hay dung trong JOIN/WHERE:
SQL> CREATE INDEX idx_enrollment_classid ON enrollment(classid);
CREATE INDEX idx_enrollment_classid ON enrollment(classid)
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> CREATE INDEX idx_enrollment_studentid ON enrollment(studentid);
CREATE INDEX idx_enrollment_studentid ON enrollment(studentid)
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> CREATE INDEX idx_class_courseno ON class(courseno);
CREATE INDEX idx_class_courseno ON class(courseno)
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> CREATE INDEX idx_class_instructorid ON class(instructorid);
CREATE INDEX idx_class_instructorid ON class(instructorid)
             *
ERROR at line 1:
ORA-00955: name is already used by an existing object 


SQL> -- Chay lai EXPLAIN PLAN sau khi tao INDEX de so sanh
SQL> EXPLAIN PLAN FOR SELECT * FROM vw_course_summary;

Explained.

SQL> SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
Plan hash value: 1597921938                                                     
                                                                                
--------------------------------------------------------------------------------
---------------------                                                           
                                                                                
| Id  | Operation                | Name                     | Rows  | Bytes | Co
st (%CPU)| Time     |                                                           
                                                                                
--------------------------------------------------------------------------------
---------------------                                                           
                                                                                

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
|   0 | SELECT STATEMENT         |                          |    23 |  2116 |   
  9  (12)| 00:00:01 |                                                           
                                                                                
|   1 |  HASH GROUP BY           |                          |    23 |  2116 |   
  9  (12)| 00:00:01 |                                                           
                                                                                
|*  2 |   HASH JOIN OUTER        |                          |    23 |  2116 |   
  8   (0)| 00:00:01 |                                                           
                                                                                
|*  3 |    HASH JOIN OUTER       |                          |    20 |  1320 |   
  6   (0)| 00:00:01 |                                                           

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
                                                                                
|   4 |     TABLE ACCESS FULL    | COURSE                   |    20 |   800 |   
  3   (0)| 00:00:01 |                                                           
                                                                                
|   5 |     TABLE ACCESS FULL    | CLASS                    |    20 |   520 |   
  3   (0)| 00:00:01 |                                                           
                                                                                
|   6 |    VIEW                  | index$_join$_005         |    22 |   572 |   
  2   (0)| 00:00:01 |                                                           
                                                                                
|*  7 |     HASH JOIN            |                          |       |       |   

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
         |          |                                                           
                                                                                
|   8 |      INDEX FAST FULL SCAN| IDX_ENROLLMENT_CLASSID   |    22 |   572 |   
  1   (0)| 00:00:01 |                                                           
                                                                                
|   9 |      INDEX FAST FULL SCAN| IDX_ENROLLMENT_STUDENTID |    22 |   572 |   
  1   (0)| 00:00:01 |                                                           
                                                                                
--------------------------------------------------------------------------------
---------------------                                                           
                                                                                

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
                                                                                
Predicate Information (identified by operation id):                             
---------------------------------------------------                             
                                                                                
   2 - access("CL"."CLASSID"="E"."CLASSID"(+))                                  
   3 - access("CO"."COURSENO"="CL"."COURSENO"(+))                               
   7 - access(ROWID=ROWID)                                                      
                                                                                
Note                                                                            
-----                                                                           
   - dynamic statistics used: dynamic sampling (level=2)                        

PLAN_TABLE_OUTPUT                                                               
--------------------------------------------------------------------------------
   - this is an adaptive plan                                                   

28 rows selected.

SQL> -- Ket qua mong doi: thay 'TABLE ACCESS FULL' bang 'INDEX RANGE SCAN'
SQL> CREATE OR REPLACE PROCEDURE report_class_detail_v2
  2  (p_classid IN NUMBER)
  3  IS
  4  TYPE t_rec IS RECORD(
  5  ho_ten VARCHAR2(50),
  6  finalgrade NUMBER
  7  );
  8  TYPE t_recs IS TABLE OF t_rec INDEX BY PLS_INTEGER;
  9  v_data t_recs;
 10  v_stt NUMBER:=0;
 11  BEGIN
 12  -- BULK COLLECT thay vi cursor tung hang
 13  SELECT s.firstname||' '||s.lastname, e.finalgrade
 14  BULK COLLECT INTO v_data
 15  FROM enrollment e JOIN student s ON e.studentid=s.studentid
 16  WHERE e.classid=p_classid
 17  ORDER BY s.lastname;
 18  DBMS_OUTPUT.PUT_LINE('So SV: '||v_data.COUNT);
 19  FOR i IN 1..v_data.COUNT LOOP
 20  v_stt:=v_stt+1;
 21  DBMS_OUTPUT.PUT_LINE(LPAD(v_stt,3)||' '||RPAD(v_data(i).ho_ten,22)
 22  ||LPAD(NVL(TO_CHAR(v_data(i).finalgrade),'--'),6));
 23  END LOOP;
 24  END report_class_detail_v2;
 25  /

Procedure created.

SQL> CREATE OR REPLACE PROCEDURE run_all_tests IS
  2  v_pass NUMBER:=0; v_fail NUMBER:=0;
  3  PROCEDURE assert(p_test VARCHAR2, p_cond BOOLEAN) IS
  4  BEGIN
  5  IF p_cond THEN
  6  v_pass:=v_pass+1;
  7  DBMS_OUTPUT.PUT_LINE('[PASS] '||p_test);
  8  ELSE
  9  v_fail:=v_fail+1;
 10  DBMS_OUTPUT.PUT_LINE('[FAIL] '||p_test);
 11  END IF;
 12  END;
 13  v_cnt NUMBER;
 14  BEGIN
 15  DBMS_OUTPUT.PUT_LINE('=== BAT DAU TEST ===');
 16  -- Test 1: enroll SV ton tai vao lop ton tai
 17  BEGIN
 18  pkg_enrollment_system.do_enroll(102, 2);
 19  SELECT COUNT(*) INTO v_cnt FROM enrollment
 20  WHERE studentid=102 AND classid=2;
 21  assert('Enroll hop le', v_cnt > 0);
 22  ROLLBACK;
 23  EXCEPTION WHEN OTHERS THEN assert('Enroll hop le', FALSE);
 24  END;
 25  -- Test 2: enroll SV khong ton tai -> phai that bai
 26  BEGIN
 27  pkg_enrollment_system.do_enroll(99999, 1);
 28  SELECT COUNT(*) INTO v_cnt FROM enrollment WHERE studentid=99999;
 29  assert('Chon SV khong ton tai', v_cnt = 0);
 30  END;
 31  DBMS_OUTPUT.PUT_LINE('=== KET QUA: PASS='||v_pass||' FAIL='||v_fail||'
 32  ===');
 33  END run_all_tests;
 34  /

Warning: Procedure created with compilation errors.

SQL> BEGIN run_all_tests; END;
  2  /
BEGIN run_all_tests; END;
      *
ERROR at line 1:
ORA-06550: line 1, column 7: 
PLS-00905: object KTHAI.RUN_ALL_TESTS is invalid 
ORA-06550: line 1, column 7: 
PL/SQL: Statement ignored 


SQL> CREATE OR REPLACE PROCEDURE run_all_tests IS
  2      v_pass NUMBER := 0;
  3      v_fail NUMBER := 0;
  4      PROCEDURE assert(p_test VARCHAR2, p_cond BOOLEAN) IS
  5      BEGIN
  6          IF p_cond THEN
  7              v_pass := v_pass + 1;
  8              DBMS_OUTPUT.PUT_LINE('[PASS] ' || p_test);
  9          ELSE
 10              v_fail := v_fail + 1;
 11              DBMS_OUTPUT.PUT_LINE('[FAIL] ' || p_test);
 12          END IF;
 13      END;
 14      v_cnt NUMBER;
 15  BEGIN
 16      DBMS_OUTPUT.PUT_LINE('=== BAT DAU TEST ===');
 17      -- Test 1
 18      BEGIN
 19          pkg_student_mgmt.enroll(102, 2);
 20          SELECT COUNT(*) INTO v_cnt
 21          FROM enrollment
 22          WHERE studentid = 102 AND classid = 2;
 23          assert('Enroll hop le', v_cnt > 0);
 24          ROLLBACK;
 25      EXCEPTION
 26          WHEN OTHERS THEN
 27              assert('Enroll hop le', FALSE);
 28      END;
 29      -- Test 2
 30      BEGIN
 31          pkg_student_mgmt.enroll(99999, 1);
 32          SELECT COUNT(*) INTO v_cnt
 33          FROM enrollment
 34          WHERE studentid = 99999;
 35          assert('Chon SV khong ton tai', v_cnt = 0);
 36      EXCEPTION
 37          WHEN OTHERS THEN
 38              assert('Chon SV khong ton tai', TRUE);
 39      END;
 40      DBMS_OUTPUT.PUT_LINE(
 41          '=== KET QUA: PASS=' || v_pass ||
 42          ' FAIL=' || v_fail || ' ==='
 43      );
 44  END run_all_tests;
 45  /

Warning: Procedure created with compilation errors.

SQL> SPOOL OFF;
